/*******************************************************
  Production configuration
*******************************************************/
const path = require('path');
const webpack = require('webpack');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const ChunkManifestPlugin = require("chunk-manifest-webpack-plugin");
const WebpackChunkHash = require("webpack-chunk-hash");
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ENVIRONMENT = process.env.NODE_ENV || 'staging';

module.exports = {
  entry: {
    'main': './static/js/index.js'
  },
  output: {
    filename: 'main.[chunkhash].js',
    chunkFilename: 'main.[chunkhash].js',
    path: path.join(__dirname, 'deploy', 'static', 'js')
  },
  module: {
    loaders: [
      {
        test: /\.js$/,
        exclude: [/node_modules/],
        loader: 'babel-loader'
      },
      {
        test: /\.styl$/,
        exclude: [/node_modules/],
        loader: 'style-loader!css-loader!stylus-loader'
      }
    ]
  },
  plugins: [
    new webpack.DefinePlugin({
      'process.env.NODE_ENV': JSON.stringify(ENVIRONMENT)
    }),
    new WebpackChunkHash(),
    new webpack.HashedModuleIdsPlugin(),
    new webpack.optimize.UglifyJsPlugin(),
    new webpack.optimize.OccurrenceOrderPlugin(),
    new ChunkManifestPlugin({
      filename: 'chunk-manifest.json',
      manifestVariable: 'webpackManifest',
      inlineManifest: true
    }),
    new HtmlWebpackPlugin({
      title: 'Thirstie Matchmaker',
      chunks: ['main'],
      template: path.join(__dirname, 'static', 'templates') + '/index.ejs',
      filename: path.join(__dirname, 'deploy') + '/index.html'
    }),
    new CopyWebpackPlugin([{
      from: './static/img/**/*.+(jpg|jpeg|png|svg|gif|ico)',
      to: path.join(__dirname, 'deploy', 'static', 'img') + '/[name].[ext]'
    }])
  ]
};
