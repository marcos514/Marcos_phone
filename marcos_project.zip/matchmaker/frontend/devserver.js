/*********************************
Express development server
*********************************/
const path = require('path');
const webpack = require('webpack');
const development = require('./webpack.dev.config');
const compiler = webpack(development);

const express = require('express');
const app = express();
const port = process.env.WEB_PORT || 3030;

// setup hot-reloading
app.use(require('webpack-dev-middleware')(compiler, {
  hot: true,
  stats: { colors: true },
  publicPath: development.output.publicPath
}));
app.use(require('webpack-hot-middleware')(compiler));

// define route(s)
app.get('/*', function(req, res) {
  res.sendFile(path.join(__dirname, 'static', 'html/index.html'));
});

// run-server
app.listen(port, function(error) {
  if (error) {
    console.error(error);
  }
  else {
    console.info("==> 🌎  Listening on port %s. Open up http://localhost:%s/ in your browser.", port, port);
  }
});
