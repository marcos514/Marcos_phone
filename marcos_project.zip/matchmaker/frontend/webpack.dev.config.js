/*******************************************************
  Local development configuration
*******************************************************/
const webpack = require('webpack');
const path = require('path');

module.exports = {
  entry: {
    'main': [
      'react-hot-loader/patch',
      'webpack-hot-middleware/client?reload=true',
      './static/js/index.js'
    ]
  },
  output: {
    filename: 'js/main.js',
    publicPath: '/static/',
    path: path.join(__dirname, './dist')
  },
  devtool: 'inline-source-map',
  module: {
    loaders: [
      {
        test: /\.js$/,
        exclude: [/node_modules/],
        loader: 'babel-loader'
      },
      {
        test: /\.styl$/,
        exclude: [/node_modules/],
        loader: 'style-loader!css-loader!stylus-loader'
      }
    ]
  },
  plugins: [
    new webpack.HotModuleReplacementPlugin(),
    new webpack.NoEmitOnErrorsPlugin()
  ]
};
