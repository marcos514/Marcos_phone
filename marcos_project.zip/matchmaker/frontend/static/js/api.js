/************************************************
API for UI. All network cals live here
************************************************/
import axios from 'axios';
import { prepareFile } from './util';

// environment
const ENVIRONMENT = (process.env.NODE_ENV || 'development').trim();
const route = ENVIRONMENT === 'staging' || ENVIRONMENT === 'development' ? '.next' : '';
let couch_url = 'http://localhost:8887';
if (ENVIRONMENT === 'staging') couch_url = 'https://next.matchmaker.thirstie.com:6984';
else if (ENVIRONMENT === 'production') couch_url = 'https://matchmaker.thirstie.com:6984';

// axios configuration
const proxy = axios.create({ baseURL: process.env.BASE_URL });
const cAPI = axios.create({ baseURL: `https://api${route}.thirstie.com` });
const couch = axios.create({ baseURL: couch_url });

// create && update
export const uploadMasterProductList = file => {
  return proxy.post('/m/products', prepareFile(file));
};

export const uploadRawInventory = (tmk, file) => {
  return proxy.post(`/e/merchant/${tmk}`, prepareFile(file));
};

export const updateMerchant = (merchant, _new=false) => {
  const data = {
    tmk: merchant.tmk,
    name: merchant.name,
    enabled: merchant.enabled
  };
  const route = `/m/merchant/${data.tmk}`;
  return _new ? proxy.post(route, data) : proxy.put(route, data);
};

export const updateMapping = mapping => {
  const route = `/m/merchant/${mapping.tmk}/mappings/${mapping.id}`;
  return proxy.put(route, mapping.enabled);
};

export const updateProductEnabled = product => {
  const route = `/m/product/${product.tpk}`;
  return proxy.put(route, !product.enabled);
};

export const uploadMappingsFile = (tmk, file) => {
  return proxy.post(`/m/merchant/${tmk}/mappings`, prepareFile(file));
};

export const updateOfferings = tmk => proxy.get(`/u/v2/trigger/${tmk}`);

// read
export const downloadNFile = tmk => couch.get(`/n_files/${tmk}/n_file_${tmk}.csv`);
export const getMerchants = () => proxy.get('/m/merchants');
export const generateTMK = () => proxy.get('/m/merchants/generate');
export const getMerchantMetaData = tmks => proxy.get(`/i/ingestions/${tmks}`);
export const getMappingMetaData = tmks => proxy.get(`/m/metadata/${tmks}`);
export const getMerchantInventory = (tmk, isCSV = false) => {
  return proxy.get(`/i/merchant/${tmk}/inventory?csv=${isCSV}`);
};
export const verifyMerchant = tmk => cAPI.get(`/c/v2/merchants?filter[tmk]=${tmk}`);
export const getMerchantMappings = (tmk, isCSV = false) => {
  return proxy.get(`/m/merchant/${tmk}/mappings?csv=${isCSV}`);
};
export const getAllMappings = (isCSV = false) => {
  return proxy.get(`/m/mappings?csv=${isCSV}`);
};

export const getAllProducts = (isCSV = false) => {
  return proxy.get(`/m/products?csv=${isCSV}`);
};
export const getProductData = tpks => cAPI.post('/c/v2/products/data', { tpks });

export const getMerchantsSettings = (merchants, fields = false) => {
  const route = `/e/merchant/${merchants}`;
  return fields ? proxy.get(route+`?fields=${fields}`) : proxy.get(route);
};

export const getFullMappings = (tmks, isCSV = false, master = false) => {
  return proxy.get(`/m/merchants/mappings/${tmks}?csv=${isCSV}&master=${master}`);
};

export const getMerchantIngestions = (tmk, isCSV = false) => {
  return proxy.get(`/i/merchant/${tmk}/ingestions?csv=${isCSV}`);
};

/*
  All endpoint to reports
*/
export const generateAllMappingsFile = () => {
  return proxy.get(`/r/generate/all_mappings`);
};

export const generateMasterNFile = () => {
  return proxy.get(`/r/generate/master_n_file`);
};

export const generateRAWMasterNFile = () => {
  return proxy.get(`/r/generate/raw_master_n_file`);
};

export const deleteReport = (report_id) => {
  return proxy.delete(`/r/report/${report_id}`);
};

export const downloadReport = (report_id) => {
  return proxy.get(`/r/download/${report_id}`);
};

export const getReports = () => {
  return proxy.get(`/r/reports`);
};
