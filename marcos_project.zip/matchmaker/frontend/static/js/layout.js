import React from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import Dashboard from './dashboard';
import Mapping from './mapping';
import Reports from './reports';
import Ingestion from './ingestion';
import MasterProductList from './MasterProductList';
import { AppMenu } from './components';

export default class Layout extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      view:'Dashbord'
    }
    this.handleView = this.handleView.bind(this);
  }

  handleView(currentView){
    if(typeof currentView === 'string' && currentView.toLowerCase() != this.state.view.toLocaleLowerCase()){
      this.setState({
        view: currentView
      });
    }
  }

  render() {
    return (
      <BrowserRouter>
        <AppMenu view={this.state.view}>
          <Switch>
          <Route
            exact
            path='/'
            component={() => <Dashboard
              handleView={this.handleView}
            />}
          />
          <Route
            exact
            path='/mpl'
            component={() => <MasterProductList
              handleView={this.handleView}
            />}
          />
          <Route
            exact
            path='/reports'
            component={() => <Reports
              handleView={this.handleView}
            />}
          />
          <Route
            path='/ingestions/:tmk(\w+)'
            component={(props) => <Ingestion
              {...props}
              handleView={this.handleView}
            />}
          />
          <Route
            path='/:tmk(\w+)'
            component={(props) => <Mapping
              {...props}
              handleView={this.handleView}
            />}
          />
          </Switch>
        </AppMenu>
      </BrowserRouter>
    );
  }
}
