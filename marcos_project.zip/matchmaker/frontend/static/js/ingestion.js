import React from 'react';
import { saveAs } from 'file-saver';
import { Table, Button, Message, Modal, Loader, Dimmer } from 'semantic-ui-react';
import {
  verifyMerchant,
  getMerchantIngestions
} from './api';

import {
  SortableTableHeader,
  SortableTableBody,
  SortableTableFooter
} from './components';

import {handleHeaderCellClick} from './util';

export default class Ingestion extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataList: []
    };
    this.fields = ['data_source', 'run_date', 'unchanged', 'updated', 'inserted', 'deactivated', 'skipped', 'success'];
    this.fetchIngestions = this.fetchIngestions.bind(this);
    this.handleHeaderCellClick = handleHeaderCellClick.bind(this);
  }

  componentDidMount() {
    verifyMerchant(this.props.match.params.tmk).then(response => {
      this.setState({merchant: response.data.items[0].name});
    });
    this.fetchIngestions();
  }


  fetchIngestions() {
    const tmk = this.props.match.params.tmk;
    this.setState({ loading: true });
    getMerchantIngestions(tmk, false).then(response => {
      const dataList = response.data.reverse();
      this.setState({ dataList });
      this.setState({ loading: false });
    }).catch(error => {
      console.error(error);
      this.setState({ loading: false });
    });
  }

  handleIngestionLogsModal(ingestion){
    this.setState({
      show_description_modal: true,
      description:ingestion.description,
      ingestion_id:ingestion.id
    });
  }
    /* Page Export */
  handleGetMerchantIngestions() {
      getMerchantIngestions(this.props.match.params.tmk, true).then(response => {
        const re = /filename="?(.*)"?/gi.exec(response.headers['content-disposition']);
        saveAs(new Blob([response.data], {type: 'text/csv;charset=utf-8'}), re ? re[1] : 'export.csv');
      }).catch(error => {
        console.error(error);
      });
    }

  render() {
    const { dataList, color, message, data_source, run_date, unchanged, updated,
      inserted, deactivated, skipped, success, show_description_modal,
      merchant, loading, description, ingestion_id } = this.state;
    this.props.handleView(merchant);

    return (
      <div style={{height: 'auto', overflow: 'auto', display: 'block'}}>
        <Dimmer inverted active={loading}><Loader content='Loading'/></Dimmer>
        <Message floating color={color} content={message} className='alert-message'
          style={{display: message ? 'inline-block' : 'none'}}/>
        <SortableTableHeader>
          <Table.Row>
            <Table.HeaderCell>ID</Table.HeaderCell>
            <Table.HeaderCell sorted={data_source}
              onClick={e => this.handleHeaderCellClick(this, 'data_source')}>
              Data Source
            </Table.HeaderCell>
            <Table.HeaderCell sorted={run_date}
              onClick={e => this.handleHeaderCellClick(this, 'run_date')}>
              Run Date
            </Table.HeaderCell>
            <Table.HeaderCell sorted={unchanged}
              onClick={e => this.handleHeaderCellClick(this, 'unchanged')}>
              Unchanged
            </Table.HeaderCell>
            <Table.HeaderCell sorted={inserted}
              onClick={e => this.handleHeaderCellClick(this, 'inserted')}>
              Inserted
            </Table.HeaderCell>
            <Table.HeaderCell sorted={updated}
              onClick={e => this.handleHeaderCellClick(this, 'updated')}>
              Updated
            </Table.HeaderCell>
            <Table.HeaderCell sorted={deactivated}
              onClick={e => this.handleHeaderCellClick(this, 'deactivated')}>
              Deactivated
            </Table.HeaderCell>
            <Table.HeaderCell sorted={skipped}
              onClick={e => this.handleHeaderCellClick(this, 'skipped')}>
              Skipped
            </Table.HeaderCell>
            <Table.HeaderCell sorted={success}
              onClick={e => this.handleHeaderCellClick(this, 'success')}>
              Success
            </Table.HeaderCell>
            <Table.HeaderCell className='nonSortable'>Description</Table.HeaderCell>
            <Table.HeaderCell className='table-blank-space nonSortable'></Table.HeaderCell>
          </Table.Row>
        </SortableTableHeader>
        <SortableTableBody>
          {dataList.map(row => (
            <Table.Row key={row.id} style={{backgroundColor: row.success? '' : '#fb08087a' }}>
              <Table.Cell>{row.id}</Table.Cell>
              <Table.Cell>{row.data_source}</Table.Cell>
              <Table.Cell>{row.run_date}</Table.Cell>
              <Table.Cell>{row.unchanged}</Table.Cell>
              <Table.Cell>{row.inserted}</Table.Cell>
              <Table.Cell>{row.updated}</Table.Cell>
              <Table.Cell>{row.deactivated}</Table.Cell>
              <Table.Cell>{row.skipped}</Table.Cell>
              <Table.Cell>{row.success ? 'True': 'False'}</Table.Cell>
              <Table.Cell>
                {
                  !row.success &&
                  <Button
                    fluid content='View' disabled={row.success.toString() == 'true'}
                    onClick={e => this.handleIngestionLogsModal(row)}
                  />
                }
              </Table.Cell>
            </Table.Row>
          ))}
        </SortableTableBody>
        <SortableTableFooter>
          <Table.Row>
            <Table.HeaderCell colSpan={10}>
              <Button content='Export Ingestions' onClick={e => this.handleGetMerchantIngestions()}/>
            </Table.HeaderCell>
          </Table.Row>
        </SortableTableFooter>

        <Modal size='large' open={show_description_modal} onClose={() => this.setState({show_description_modal: false})}>
          <Modal.Header>Ingestion Logs for ID: {ingestion_id}</Modal.Header>
          <Modal.Content><pre>{description}</pre></Modal.Content>
          <Modal.Actions>
            <Button content='Close' onClick={() => this.setState({show_description_modal: false})}/>
          </Modal.Actions>
        </Modal>
      </div>
    );
  }
};
