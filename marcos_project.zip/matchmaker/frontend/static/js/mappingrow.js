import React from 'react';
import { Table, Modal, Button, Checkbox } from 'semantic-ui-react';

import { updateMapping } from './api';


export default class MappingRow extends React.Component {
  constructor(props) {
    super(props);
  }

  shouldComponentUpdate(nextProps, nextState) {
    // check props
    const propItems = ['rank', 'enabled', 'status', 'tpk', 'name', 'index',
                      'type', 'size', 'price', 'quantity', 'mapping_id'];
    return propItems.some(item => this.props[item] !== nextProps[item]);
  }

  handleMappingStatus(mpk) {
    const { tmk, tpk, enabled, update, mapping_id } = this.props;
    const merchant = { id: mapping_id, tmk, tpk, mpk, enabled: !enabled };
    updateMapping(merchant).then(response => {
      // update the props by sending the response up the render tree
      update(merchant);
    }).catch(error => {
      console.error(error);
    });
  }

  render() {
    const { enabled, status, tpk, name, type, size, mpk, price, quantity, index, exists } = this.props;
    return (
      <Table.Row>
        <Table.Cell>{index+1}</Table.Cell>
        <Table.Cell>
          <Checkbox checked={enabled || false} indeterminate={!status} disabled={!mpk || !status}
            onChange={e => this.handleMappingStatus(mpk)}/>
        </Table.Cell>
        <Table.Cell>
          {!status ? 'Disabled in MPL' : enabled ? 'Active' : 'Inactive'}
        </Table.Cell>
        <Table.Cell>{tpk}</Table.Cell>
        <Table.Cell>{name}</Table.Cell>
        <Table.Cell>{type}</Table.Cell>
        <Table.Cell>{size}</Table.Cell>
        <Table.Cell>{mpk}</Table.Cell>
        <Table.Cell>{price}</Table.Cell>
        <Table.Cell>{quantity}</Table.Cell>
        <Table.Cell>
          <Checkbox checked={exists || false} indeterminate={!exists}/>
        </Table.Cell>
      </Table.Row>
    );
  }
};
