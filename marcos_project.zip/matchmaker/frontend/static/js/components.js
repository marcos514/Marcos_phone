import React from 'react';
import { Table } from 'semantic-ui-react';
import { Link } from 'react-router-dom';
import { Icon, Menu, Popup, Button, Sidebar, Segment } from 'semantic-ui-react';

class SortableTableHeader extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div style={{display: 'block'}}>
        <Table sortable fixed>
          <Table.Header>{this.props.children}</Table.Header>
        </Table>
      </div>
    )
  }
};

class SortableTableBody extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { columns } = this.props;
    return (
      <div className='table-body-sort'>
        <Table fixed={columns == undefined} columns={columns || 16} celled>
          <Table.Body>{this.props.children}</Table.Body>
        </Table>
      </div>
    );
  }
}

class SortableTableFooter extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div style={{display: 'block'}}>
        <Table fixed>
          <Table.Footer>{this.props.children}</Table.Footer>
        </Table>
      </div>
    );
  }
}

class AppMenu extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { view } = this.props;
    const independentViews = ['Dashboard', 'Reports', 'Master Product List']
    var needBack =  !independentViews.includes(view);
    const styles = {
      hideBack: {
        display: needBack ? 'block':'none'
      },
      fullWidth: {
        position: 'relative',
        width: '95.5%'
      },
      sideBar: {
        position: 'relative',
        top: '25px'
      }
    };
    return (
      <div>
        <Sidebar.Pushable as={Segment}>
          <Sidebar
            as={Segment}
            animation='push'
            inverted
            vertical
            visible={true}
            width='very thin'
          >
          <div style={styles.sideBar}>
            <Menu.Item as={Link} to={`/`}>
              <Popup
                trigger={<Button fluid basic inverted icon='home'/>}
                content='Dashboard'
              />
            </Menu.Item>
            <Menu.Item as={Link} to={`/reports`}>
              <Popup
                trigger={<Button fluid basic inverted icon='book'/>}
                content='Reports'
              />
            </Menu.Item>
            <Menu.Item as={Link} to={`/mpl`}>
              <Popup
                trigger={<Button fluid basic inverted icon='unordered list'/>}
                content='Master Product List'
              />
            </Menu.Item>
          </div>
          </Sidebar>

          <Sidebar.Pusher>
            <div style={styles.fullWidth}>
              <Menu inverted attached='top'>
                <Menu.Item>
                  {this.props.view}
                </Menu.Item>
                <Menu.Item style={styles.hideBack} position='right' as='a'onClick={e => window.history.back()}>
                  <Popup trigger={<Icon name='arrow left'/>} content='Back' />
                </Menu.Item>
              </Menu>
              {this.props.children}
            </div>
          </Sidebar.Pusher>
        </Sidebar.Pushable>
      </div>
  );
  }
}

export { SortableTableHeader, SortableTableBody, SortableTableFooter, AppMenu }
