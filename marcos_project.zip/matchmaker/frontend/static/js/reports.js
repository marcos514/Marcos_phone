import React from 'react';
import { saveAs } from 'file-saver';
import { Table, Button, Message, Modal } from 'semantic-ui-react';
import {
  generateMasterNFile,
  generateRAWMasterNFile,
  deleteReport,
  downloadReport,
  getReports,
  generateAllMappingsFile
} from './api';

import {
  SortableTableHeader,
  SortableTableBody,
  SortableTableFooter
} from './components';

import { handleHeaderCellClick } from './util';

export default class Reports extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      value: '',
      tmkTxt: '',
      dataList: []
    };
    this.fields = ['filename', 'report_type_name', 'date_generated'];
    this.fetchReports = this.fetchReports.bind(this);
    this.handleHeaderCellClick = handleHeaderCellClick.bind(this);
    this.props.handleView('Reports');
  }

  componentDidMount() {
    this.fetchReports();
  }


  fetchReports() {
    this.setState({refresh:true})
    getReports().then(response => {
      const dataList = response.data.reverse();
      this.setState({ dataList, refresh:false });
    }).catch(error => {
      this.setState({refresh:false})
      console.error(error);
    });
  }

  handleGenerateAllMappings() {
    this.setState({ all_mappings_button: true, generate: true,  file_process: "All Mappings" });
    generateAllMappingsFile().then(response => {
      if(response.data.success){
        this.fetchReports();
      }
    }).catch(error => {
      console.error(error);
    });
  }

  handleGenerateMasterNFile() {
    this.setState({ master_button: true, generate: true,  file_process: "Master N" });
    generateMasterNFile().then(response => {
      if(response.data.success){
        this.fetchReports();
      }
    }).catch(error => {
      console.error(error);
    });
  }

  handleGenerateRAWMasterNFile() {
    this.setState({ raw_master_button: true, generate: true,  file_process: "RAW Master N" });
    generateRAWMasterNFile().then(response => {
      if(response.data.success){
        this.fetchReports();
      }
    }).catch(error => {
      console.error(error);
    });
  }

  handleDeleteReport(id){
    deleteReport(id).then(response => {
        if(response.data.success){
        this.fetchReports();
      }
    }).catch(error => {
      console.error(error);
    });
  }



  handleDownloadReport(id){
    downloadReport(id).then(response => {
      const re = /filename="?(.*)"?/gi.exec(response.headers['content-disposition']);
      saveAs(new Blob([response.data], {type: 'text/csv;charset=utf-8'}), re ? re[1] : 'export_file.csv');
    }).catch(error => {
      this.setState({message:"Cant delete file"})
      console.error(error);
    });
  }


  handleError(error, attr, loader=undefined, color='red', other=undefined) {
    // handles error messaging
    const data = error.response.data;
    let message = 'Looks like there\'s an issue on the server. Try again later';
    if (error.response.status < 500) {
      message = data.message || `No N-File for TMK "${other}"`;
    }
    const changes = loader ? { [attr]: message, [loader]: false, color } : { [attr]: message, color };
    this.setState(changes);
    this.handleAlertDismissal([attr], 4);
  }

  render() {
    const { dataList, file_name, date_added, file_type, color, message,
      file_process, generate, master_button, raw_master_button, all_mappings_button, refresh } = this.state;

    // NOTE: commenting out the search/filter bar for now
    // <Search loading={isLoading} value={value} showNoResults={false}
      // onSearchChange={e => this.handleSearchChange(e)}
      // style={{display: 'inline-block'}}/>

    return (
      <div style={{height: 'auto', overflow: 'auto', display: 'block'}}>
        <Message floating color={color} content={message} className='alert-message'
          style={{display: message ? 'inline-block' : 'none'}}/>
        <SortableTableHeader>
          <Table.Row>
            <Table.HeaderCell>ID</Table.HeaderCell>
            <Table.HeaderCell sorted={file_name}
              onClick={e => this.handleHeaderCellClick(this, 'filename')}>
              Name
            </Table.HeaderCell>
            <Table.HeaderCell sorted={file_type}
              onClick={e => this.handleHeaderCellClick(this, 'report_type_name')}>
              File Type
            </Table.HeaderCell>
            <Table.HeaderCell sorted={date_added}
              onClick={e => this.handleHeaderCellClick(this, 'date_generated')}>
              Date Created
            </Table.HeaderCell>
            <Table.HeaderCell className='nonSortable'>Export</Table.HeaderCell>
            <Table.HeaderCell className='nonSortable'>Delete</Table.HeaderCell>
          </Table.Row>
        </SortableTableHeader>
        <SortableTableBody>
          {dataList.map(row => (
            <Table.Row key={row.id}>
              <Table.Cell>
                {row.id}
              </Table.Cell>
              <Table.Cell>{row.filename}</Table.Cell>
              <Table.Cell>{row.report_type_name}</Table.Cell>
              <Table.Cell>{row.date_generated}</Table.Cell>
              <Table.Cell>
                <Button fluid content='Download' onClick={e => this.handleDownloadReport(row.id)}/>
              </Table.Cell>
              <Table.Cell>
                <Button fluid content='Delete' onClick={e => this.handleDeleteReport(row.id)}/>
              </Table.Cell>
            </Table.Row>
          ))}
        </SortableTableBody>
        <SortableTableFooter>
          <Table.Row>
            <Table.HeaderCell colSpan={5}>
              <Button disabled={all_mappings_button} content='All Mappings' onClick={e => this.handleGenerateAllMappings()}/>
              <Button disabled={master_button} content='Master N-File' onClick={e => this.handleGenerateMasterNFile()}/>
              <Button disabled={raw_master_button} content='RAW Master N-File' onClick={e => this.handleGenerateRAWMasterNFile()}/>
              <div style={{float: 'right'}}>
                <Button loading={refresh} disabled={refresh} content='Refresh' onClick={e => this.fetchReports()}/>
              </div>
            </Table.HeaderCell>
          </Table.Row>
        </SortableTableFooter>
        <Modal size='mini' open={generate} onClose={() => this.setState({generate: false})}>
          <Modal.Header>Generating {file_process} file</Modal.Header>
          <Modal.Content>The file is generating please wait a moment and refresh the page</Modal.Content>
          <Modal.Actions>
            <Button content='Close' onClick={() => this.setState({generate: false})}/>
          </Modal.Actions>
        </Modal>
      </div>
    );
  }
};
