// utility helper functions

export const formatDate = date_obj => {
  // returns a date object in MM/DD/YY format
  if (!date_obj) return undefined;
  const month = `0${date_obj.getMonth()+1}`.slice(-2);
  const day = `0${date_obj.getDate()}`.slice(-2);
  const year = `${date_obj.getFullYear()}`.slice(-2);
  return `${month}/${day}/${year}`;
}

export const prepareFile = file => {
  const data = new FormData();
  data.append('upload', file);
  return data;
}

export const getMerchantState = (merchant) =>{
    if (!merchant.enabled){
        return "Inactive";
    }

    if (merchant.upload_frequency_in_days && merchant.inventory_ingestion.last_ingestion){
        var now = new Date();
        var expected_upload = now.setDate(now.getDate() - merchant.upload_frequency_in_days)
        var last_ingestion = new Date(merchant.inventory_ingestion.last_ingestion)
        if (last_ingestion < expected_upload){
            return "Idle";
        }
    }

    if (merchant.inventory_ingestion.success == '0'){
        return 'Failure'
    }

    return "Active";
}


export const getMerchantColor = (merchant) =>{
    var merchant_status = getMerchantState(merchant);
    if (merchant_status == "Idle"){
        return "#fbbd0878";
    }
    if (merchant_status == "Failure"){
        return "#fb08087a";
    }
    return null;
}

export const handleHeaderCellClick = (data, target) => {
  const { dataList, offset } = data.state;
  const col = data.state[target];
  const result = !col ? 'ascending' : col === 'ascending' ? 'descending' : undefined;
  let copy = dataList.slice();
  if (result) {
    copy.sort((a, b) => {
      let x = a[target], y = b[target];

      if (data.fields.includes(target)) {
        x = a[target], y = b[target];
      }

      if (typeof x === 'string') {
        x = x.toLowerCase();
        y = y.toLowerCase();
      }
      if (x < y) {
        return result === 'ascending' ? -1 : 1;
      }
      else if (x > y) {
        return result === 'ascending' ? 1 : -1;
      }
      return 0;
    });
  }
  else {
    copy.sort((a, b) => {
      const x = parseFloat(a.index);
      const y = parseFloat(b.index);
      return x < y ? -1 : x > y ? 1 : 0;
    })
  }
  data.state = {[target]: result, offset};
  data.setState({[target]: result, dataList: copy, offset});
}
