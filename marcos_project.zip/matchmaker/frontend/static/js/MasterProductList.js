import React from 'react';
import { saveAs } from 'file-saver';
import Dropzone from 'react-dropzone';
import { Table, Button, Message, Checkbox } from 'semantic-ui-react';
import {
  uploadMasterProductList,
  updateProductEnabled,
  getAllProducts
} from './api';

import {
  SortableTableHeader,
  SortableTableBody,
  SortableTableFooter
} from './components';

import { handleHeaderCellClick } from './util';

export default class MasterProductList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataList: []
    };
    this.fields = ['tpk', 'enabled'];
    this.fetchMasterProductList = this.fetchMasterProductList.bind(this);
    this.handleMasterProdUpload = this.handleMasterProdUpload.bind(this);
    this.handleHeaderCellClick = handleHeaderCellClick.bind(this);
    this.props.handleView('Master Product List');
  }

  componentDidMount() {
    this.fetchMasterProductList();
  }


  fetchMasterProductList() {
    getAllProducts(false).then(response => {
      const dataList = response.data.reverse();
      this.setState({ dataList });
    }).catch(error => {
      console.error(error);
    });
  }

  handleMasterProdUpload(files) {
    this.setState({ mpl: true });
    uploadMasterProductList(files[0]).then(response => {
      this.setState({ mpl: false, message: 'Upload successful', color: 'green' });
      this.handleAlertDismissal('message');
    }).catch(error => this.handleError(error, 'message', 'mpl'));
  }

  handleMasterProdDownload() {
    getAllProducts(true).then(response => {
      const re = /filename="?(.*)"?/gi.exec(response.headers['content-disposition']);
      saveAs(new Blob([response.data], {type: 'text/csv;charset=utf-8'}), re ? re[1] : 'export.csv');
    }).catch(error => {
      console.error(error);
    });
  }

  handleProductStatusChange(index) {
    var { dataList } = this.state;
    const product = dataList[index];
    updateProductEnabled(product).then(response => {
      dataList[index].enabled = response.data.enabled;
      this.setState(dataList);
    }).catch(error => {
      console.error(error);
    });
  }

  handleAlertDismissal(attr, seconds=2) {
    setTimeout(() => {
      this.setState({ [attr]: undefined, color: undefined });
    }, seconds * 1000);
  }

  handleError(error, attr, loader=undefined, color='red', other=undefined) {
    // handles error messaging
    const data = error.response.data;
    let message = 'Looks like there\'s an issue on the server. Try again later';
    if (error.response.status < 500) {
      message = data.message || `No N-File for TMK "${other}"`;
    }
    const changes = loader ? { [attr]: message, [loader]: false, color } : { [attr]: message, color };
    this.setState(changes);
    this.handleAlertDismissal([attr], 4);
  }

  render() {
    const { dataList, color, message, mpl, tpk, enabled } = this.state;

    return (
      <div style={{height: 'auto', overflow: 'auto', display: 'block'}}>
        <Message floating color={color} content={message} className='alert-message'
          style={{display: message ? 'inline-block' : 'none'}}/>
        <SortableTableHeader>
          <Table.Row>
            <Table.HeaderCell sorted={enabled}
              onClick={e => this.handleHeaderCellClick(this, 'enabled')}>
              Enabled
            </Table.HeaderCell>
            <Table.HeaderCell sorted={tpk}
              onClick={e => this.handleHeaderCellClick(this, 'tpk')}>
              TPK
            </Table.HeaderCell>
          </Table.Row>
        </SortableTableHeader>
        <SortableTableBody>
          {dataList.map((row, idx) => (
            <Table.Row key={row.tpk}>
              <Table.Cell>
                <Checkbox checked={row.enabled} onClick={e => this.handleProductStatusChange(idx)}/>
              </Table.Cell>
              <Table.Cell>{row.tpk}</Table.Cell>
            </Table.Row>
          ))}
        </SortableTableBody>
        <SortableTableFooter>
          <Table.Row>
            <Table.HeaderCell colSpan={5}>
              <Button as={Dropzone} content='Upload Master Product File'
                loading={mpl} onDrop={e => this.handleMasterProdUpload(e)}/>
              <Button content='Export Master Product File' onClick={e => this.handleMasterProdDownload()}/>
            </Table.HeaderCell>
          </Table.Row>
        </SortableTableFooter>
      </div>
    );
  }
};