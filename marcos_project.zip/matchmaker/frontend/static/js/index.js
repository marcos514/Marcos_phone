/*************************************
  Entry point for the application
*************************************/

import '../css/main.styl';

import React from 'react';
import { render } from 'react-dom';
import { AppContainer } from 'react-hot-loader';

import Layout from './layout';

// render the page
render(
  <AppContainer>
    <Layout/>
  </AppContainer>
, document.getElementById('root'));

// hot-reloading logic lives here
const ENVIRONMENT = process.env.NODE_ENV || 'development';
if (ENVIRONMENT === 'development' && module.hot) {
  module.hot.accept('./layout', () => {
    const NextLayout = require('./layout').default;
    render(
      <AppContainer>
        <NextLayout/>
      </AppContainer>
    , document.getElementById('root'))
  });
}
