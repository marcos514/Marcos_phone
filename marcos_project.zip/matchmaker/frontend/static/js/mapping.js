import React from 'react';
import { saveAs } from 'file-saver';
import { Table, Button, Message, Dimmer, Loader, Header } from 'semantic-ui-react';
import {
  SortableTableHeader,
  SortableTableBody,
  SortableTableFooter
 } from './components';
import MappingRow from './mappingrow';
import Dropzone from 'react-dropzone';
import axios from 'axios';

import {
  getAllProducts,
  getProductData,
  getMerchantMappings,
  getMerchantInventory,
  uploadMappingsFile,
  updateOfferings,
  verifyMerchant
} from './api';


export default class Mapping extends React.Component {
  constructor(props) {
    super(props);
    this.state = { mappings: [], status: 'ascending' };
    this.fetchMappings = this.fetchMappings.bind(this);
    this.handleAlertDismissal = this.handleAlertDismissal.bind(this);
    this.handleUpdateMapping = this.handleUpdateMapping.bind(this);
  }

  componentDidMount() {
    verifyMerchant(this.props.match.params.tmk).then(response => {
      this.setState({merchant: response.data.items[0].name});
    });
    this.fetchMappings(true);
  }

  /* Network calls */
  fetchMappings(initial=false) {
    const tmk = this.props.match.params.tmk;
    this.setState({ loading: true });
    axios.all([
      getAllProducts(false),
      getMerchantMappings(tmk),
      getMerchantInventory(tmk)
    ]).then(axios.spread((r1, r2, r3) => {
      // parse the products
      const products = [];
      r1.data.forEach(product => {
        products.push({ enabled: Boolean(product.enabled), tpk: product.tpk.trim() });
      });

      // parse the merchant mappings
      const mappings = {};
      r2.data.forEach(mapping => {
        mappings[mapping.tpk] = mapping;
      });

      // parse the latest merchant inventory
      const inventory = {};
      r3.data.forEach(quote => {
        inventory[quote.mpk] = quote;
      });

      // get the product metadata
      getProductData(products.map(prod => prod.tpk)).then(response => {
        // parse product metadata
        const meta_data = {};
        response.data.items.forEach(item => {
          meta_data[item.tpk] = item;
        });

        // create the result object
        const result = products.map(product => {
          const prod_data = meta_data[product.tpk] || {};
          const product_line = prod_data.product_line || {};
          const container_size = prod_data.container_size || {};
          const mapping_info = mappings[product.tpk] || {};
          const inventory_info = inventory[mapping_info.mpk] || {};
          return {
            mapping_id: mapping_info.id,
            tpk: product.tpk,
            status: product.enabled,
            mpk: mapping_info.mpk,
            name: product_line.name,
            type: (product_line.product_type || {}).display_name,
            size: container_size.formatted,
            enabled: mapping_info.enabled,
            price: inventory_info.price,
            quantity: inventory_info.quantity,
            exists: Boolean(inventory_info.active)
          };
        });

        // default sort if loading for the first time
        if (initial) {
          result.sort((a, b) => {
            const x = !a.status ? 0 : a.enabled ? 1 : 2;
            const y = !b.status ? 0 : b.enabled ? 1 : 2;
            return x < y ? -1 : x > y ? 1 : 0;
          });
        }
        this.setState({ mappings: result, loading: false });
      }).catch(error => {
        this.setState({ loading: false });
        console.log(error);
      });
    })).catch(error => {
      this.setState({ loading: false });
      console.log(error);
    });
  }

  handleMappingsImport(files) {
    this.setState({ upload: true });
    uploadMappingsFile(this.props.match.params.tmk, files[0]).then(response => {
      this.setState({ upload: false, message: 'Upload successful', color: 'green' });
      this.handleAlertDismissal();
      this.fetchMappings();
    }).catch(error => this.handleError(error));
  }


  handleMappingsExport() {
    getMerchantMappings(this.props.match.params.tmk, true).then(response => {
      const re = /filename="?(.*)"?/gi.exec(response.headers['content-disposition']);
      saveAs(new Blob([response.data], {type: 'text/csv;charset=utf-8'}), re ? re[1] : 'export.csv');
    }).catch(error => {
      console.error(error);
    });
  }

  handleUpdateMapping(new_mapping) {
    // changes the products in state to enable or disable a particular item
    this.setState({mappings: this.state.mappings.map(mapping => {
      if (mapping.mapping_id === new_mapping.id) {
        mapping.enabled = new_mapping.enabled;
      }
      return mapping;
    })});
  }

  handleCreateOfferings() {
    this.setState({syncing: true});
    updateOfferings(this.props.match.params.tmk).then(response => {
      this.setState({ syncing: false, message: 'Upload successful', color: 'green' });
      this.handleAlertDismissal();
    }).catch(error => this.handleError(error, 'red', 'syncing'));
  }

  /* Sort handling */
  handleHeaderCellClick(target) {
    // convert an item to be compared to its base type
    const convert = item => {
      switch (target) {
        case 'status':
          return !item.status ? 0 : item.enabled ? 1 : 2;
        case 'price':
        case 'quantity':
          return parseFloat(item[target] || 0);
        case 'exists':
          return item[target].toString().toLowerCase()
        default:
          return (item[target] || '').toLowerCase();
      }
    };

    // instance variables
    const column = this.state[target];
    const order = !column ? 'ascending' : column === 'ascending' ? 'descending' : undefined;
    const sorted = this.state.mappings.slice();

    // perform sort
    switch (order) {
      case 'ascending':
        sorted.sort((a, b) => {
          let x = convert(a), y = convert(b);
          return x < y ? -1 : x > y ? 1 : 0;
        });
        break;
      case 'descending':
        sorted.sort((a, b) => {
          let x = convert(a), y = convert(b);
          return x < y ? 1 : x > y ? -1 : 0;
        });
        break;
      default:
        // sort by tpk
        sorted.sort((a, b) => {
          let x = a.tpk.toLowerCase(), y = b.tpk.toLowerCase();
          return x < y ? -1 : x > y ? 1 : 0;
        });
    }

    this.setState({ mappings: sorted, [target]: order });
  }

  /* Error handling */
  handleError(error, color='red', loader='upload') {
    // handles error messaging
    let message = 'Looks like there\'s an issue on the server. Try again later';
    if (error.response.status < 500) {
      message = error.response.data.message;
    }
    this.setState({ message, color, [loader]: false });
    this.handleAlertDismissal(4);
  }

  handleAlertDismissal(seconds=2) {
    setTimeout(() => {
      this.setState({ message: undefined, color: undefined });
    }, seconds * 1000);
  }

  /* Page Export */
  handlePageExport() {
    // export the main page to a csv
    const data = [];
    const fieldnames = ['Enabled', 'Status', 'TPK', 'Name', 'Type', 'Size',
                        'MPK', 'Price', 'Quantity', 'Exists'].join();
    data.push(fieldnames);
    this.state.mappings.forEach(mapping => {
      const row = [
        mapping.status,
        !mapping.status ? 'Disabled in MPL' : mapping.enabled ? 'Active' : 'Inactive',
        mapping.tpk || '', mapping.name || '', mapping.type || '', mapping.size || '',
        mapping.mpk || '', mapping.price || '', mapping.quantity || '', mapping.exists
      ].join();
      data.push(row);
    });

    // save the result to disk
    saveAs(new Blob([data.join('\n')], {type: 'text/csv;charset=utf-8'}), 'merchant_mappings.csv');
  }

  render() {
    const { mappings, message, color, upload, loading, syncing } = this.state;
    const { status, tpk, name, type, size, mpk, price, quantity, merchant } = this.state;
    const tmk = this.props.match.params.tmk;
    this.props.handleView(merchant);

    return (
      <div style={{height: 'auto', overflow: 'auto', display: 'block'}}>
        <Dimmer inverted active={loading}><Loader content='Loading'/></Dimmer>
        <Message floating color={color} content={message} className='alert-message'
          style={{display: message ? 'inline-block' : 'none'}}/>
        <SortableTableHeader>
          <Table.Row>
            <Table.HeaderCell className='nonSortable'>Index</Table.HeaderCell>
            <Table.HeaderCell className='nonSortable'>Enabled</Table.HeaderCell>
            <Table.HeaderCell sorted={status} content='Status'
              onClick={e => this.handleHeaderCellClick('status')}/>
            <Table.HeaderCell sorted={tpk} content='TPK'
              onClick={e => this.handleHeaderCellClick('tpk')}/>
            <Table.HeaderCell sorted={name} content='Name'
              onClick={e => this.handleHeaderCellClick('name')}/>
            <Table.HeaderCell sorted={type} content='Type'
              onClick={e => this.handleHeaderCellClick('type')}/>
            <Table.HeaderCell sorted={size} content='Size'
              onClick={e => this.handleHeaderCellClick('size')}/>
            <Table.HeaderCell sorted={mpk} content='MPK'
              onClick={e => this.handleHeaderCellClick('mpk')}/>
            <Table.HeaderCell sorted={price} content='Price'
              onClick={e => this.handleHeaderCellClick('price')}/>
            <Table.HeaderCell sorted={quantity} content='Quantity'
              onClick={e => this.handleHeaderCellClick('quantity')}/>
            <Table.HeaderCell sorted={quantity} content='Exists'
              onClick={e => this.handleHeaderCellClick('exists')}/>
            <Table.HeaderCell className='table-blank-space nonSortable'></Table.HeaderCell>
          </Table.Row>
        </SortableTableHeader>
        <SortableTableBody>
          {mappings.map((row, idx) => (
            <MappingRow key={row.tpk} index={idx} tmk={tmk} update={this.handleUpdateMapping} exists={row.exists} {...row}/>
          ))}
        </SortableTableBody>
        <SortableTableFooter>
          <Table.Row>
            <Table.HeaderCell colSpan={10}>
              <Button as={Dropzone} content='Import Mappings File' loading={upload}
                onDrop={e => this.handleMappingsImport(e)}/>
              <Button content='Export Mappings File' onClick={e => this.handleMappingsExport()}/>
              <div style={{float: 'right'}}>
                <Button loading={syncing} content='Sync Offerings' onClick={e => this.handleCreateOfferings()}/>
                <Button content='Export List' onClick={e => this.handlePageExport()}/>
              </div>
            </Table.HeaderCell>
          </Table.Row>
        </SortableTableFooter>
      </div>
    );
  }
};
