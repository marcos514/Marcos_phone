import React from 'react';
import { saveAs } from 'file-saver';
import { Link } from 'react-router-dom';
import Dropzone from 'react-dropzone';
import { Table, Icon, Input, Button, Checkbox, Search, Modal,
  Message, Dropdown } from 'semantic-ui-react';

import axios from 'axios';
import {
  uploadMasterProductList,
  uploadRawInventory,
  getAllProducts,
  getMerchants,
  generateTMK,
  getMappingMetaData,
  verifyMerchant,
  updateMerchant,
  getMerchantMetaData,
  downloadNFile,
  getMerchantsSettings
} from './api';

import {
  SortableTableHeader,
  SortableTableBody,
  SortableTableFooter
} from './components';

import { formatDate, getMerchantState, getMerchantColor, handleHeaderCellClick } from './util';


export default class Dashboard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      value: '',
      tmkTxt: '',
      dataList: [],
    };
    this.fields = ['source', 'last_ingestion', 'first_ingestion'];
    this.fetchMerchants = this.fetchMerchants.bind(this);
    this.handleAlertDismissal = this.handleAlertDismissal.bind(this);
    this.handleHeaderCellClick = handleHeaderCellClick.bind(this);
    this.props.handleView('Dashboard');
  }

  componentDidMount() {
    this.fetchMerchants();
  }

  fetchMerchants() {
    getMerchants().then(response => {
      // get ingestion data
      const tmks = response.data.map(merchant => merchant.tmk).join();
      const merchants = response.data.map(merchant => {
        return {
          enabled: merchant.enabled,
          tmk: merchant.tmk,
          name: merchant.name,
          inventory_ingestion: {}
        };
      });
      axios.all([getMerchantMetaData(tmks), getMappingMetaData(tmks), getMerchantsSettings(tmks, "upload_frequency_in_days")]).then(axios.spread((r1, r2, r3) => {
        // combine the three results to create the object needed for rendering
        const inventory_ingestion = {};
        r1.data.forEach(item => {
          inventory_ingestion[item.tmk] = item;
        });
        const dataList = merchants.map((merchant, index) => {
          const metadata = inventory_ingestion[merchant.tmk] || {};
          const date = metadata.run_date && formatDate(new Date(metadata.run_date));
          const upload_frequency_in_days = r3.data[merchant.tmk] ? r3.data[merchant.tmk].upload_frequency_in_days : null;
          merchant.upload_frequency_in_days = upload_frequency_in_days
          merchant.inventory_ingestion.last_ingestion = date;
          merchant.inventory_ingestion.success = metadata.success;
          merchant.raw_quotes = parseInt(metadata.inventory_count || 0);
          merchant.active_mappings = parseInt(r2.data.active_mappings[merchant.tmk] || 0);
          merchant.total_mappings = parseInt(r2.data.total_mappings[merchant.tmk] || 0);
          merchant.index = index;
          return merchant;
        });
        this.setState({ dataList });
      })).catch(error => {
        // we've got some ingestion errors. There could be no ingestions, which is ok
        if (error.response.status == 404) {
          this.setState({
            dataList: merchants.map(merchant => {
              merchant.inventory_ingestion = {};
              return merchant;
            })
          });
        }
        else {
          // server error
          console.error(error);
        }
      });
    }).catch(error => {
      console.error(error);
    });
  }

  handleSearchChange(e) {
    this.setState({ isLoading: true, value: e.target.value });

    window.setTimeout(value => {
      let results = [];
      if (value.length >= 1) {
        // filters the table data
        results = this.state.results.filter(obj => obj.name.toLowerCase().includes(value));
        this.setState({ isLoading: false, results });
      }
      else {
        axios.get(`/c/v2/merchants`).then(response => {
          this.setState({ isLoading: false, results: response.data.items});
        }).catch(error => {
          this.setState({ isLoading: false });
          console.log(error);
        });
      }
    }, 500, e.target.value);
  }


  handleFindNewMerchant(tmk) {
    if (tmk) {
      // step 1: verify that this TMK exists in the catalog
      verifyMerchant(tmk).then(res => {
        // step 2: create the merchant object in the mapping DB
        if (!res.data.items[0]) {
          // tmk DNE
          this.setState({ tmk404: `TMK "${tmk}" not found` });
          this.handleAlertDismissal('tmk404');
        }
        else {
          updateMerchant(res.data.items[0], true).then(response => {
            this.setState({isModalOpen: false, tmkTxt: ''});
            this.fetchMerchants();
          }).catch(error => {
            this.setState({ tmkTxt: '' });
          });
        }
      }).catch(error => {
        this.setState({ tmkTxt: '' });
      });
    }
  }

  handleMasterProdDownload() {
    getAllProducts(true).then(response => {
      const re = /filename="?(.*)"?/gi.exec(response.headers['content-disposition']);
      saveAs(new Blob([response.data], {type: 'text/csv;charset=utf-8'}), re ? re[1] : 'export.csv');
    }).catch(error => {
      console.error(error);
    });
  }

  handleNFileDownload(tmk){
    downloadNFile(tmk).then(response => {
      const name = `n_file_${tmk}.csv`;
      saveAs(new Blob([response.data], {type: 'text/csv;charset=utf-8'}), name);
    }).catch(error => this.handleError(error, 'message', undefined, 'red', tmk));
  }

  handleMasterProdUpload(files) {
    this.setState({ mpl: true });
    uploadMasterProductList(files[0]).then(response => {
      this.setState({ mpl: false, message: 'Upload successful', color: 'green' });
      this.handleAlertDismissal('message');
    }).catch(error => this.handleError(error, 'message', 'mpl'));
  }

  handleRawInvUpload(files, tmk) {
    // upload inventory by tmk to db
    this.setState({ [tmk]: true });
    uploadRawInventory(tmk, files[0]).then(response => {
      this.setState({ [tmk]: false, message: 'Upload successful', color: 'green' });
      this.handleAlertDismissal('message');
      this.fetchMerchants();
    }).catch(error => this.handleError(error, 'message', tmk));
  }

  handleExport() {
    // export the main page to a csv
    const data = [];
    const fieldnames = ['Enabled', 'Status', 'TMK', 'Name', 'Last Upload',
                        'Source', 'RAW Quotes'].join();
    data.push(fieldnames);
    this.state.dataList.forEach(merchant => {
      const row = [
        merchant.enabled.toString().toUpperCase(),
        merchant.enabled ? 'Active' : 'Inactive',
        merchant.tmk, merchant.name, merchant.inventory_ingestion.last_ingestion || 'N/A',
        merchant.inventory_ingestion.source || 'N/A', merchant.raw_quotes || '0'
      ].join();
      data.push(row);
    });

    // save the result to disk
    saveAs(new Blob([data.join('\n')], {type: 'text/csv;charset=utf-8'}), 'merchant_inventories.csv');
  }

  handleGenerateTMK() {
    generateTMK().then(response => {
      this.setState({generate: true, newtmk: response.data.tmk});
    });
  }

  handleMerchantStatusChange(row) {
    const merchant = { tmk: row.tmk, name: row.name, enabled: !row.enabled };
    updateMerchant(merchant).then(response => {
      const results = this.state.results.map(obj => {
        if (obj.tmk === row.tmk) {
          obj.enabled = !row.enabled;
        }
        return obj;
      });
      this.setState({ results });
    }).catch(error => {
      console.error(error);
    });
  }

  handleDropdownOpen(merchant){
    const dropdownRect = document.getElementById(merchant.tmk).getBoundingClientRect();
    const spaceAtTheBottom =
      document.documentElement.clientHeight - dropdownRect.top - dropdownRect.height;
    const spaceAtTheTop = dropdownRect.top;
    const upward = spaceAtTheBottom > 0 && spaceAtTheTop > spaceAtTheBottom;
    this.setState({upward:upward});
  }

  handleViewSettings(merchant){
    const tmk = merchant.tmk;
    const errorMessage = 'The merchant ' + tmk + ' has not matchmaker settings yet';
    getMerchantsSettings(tmk).then(response => {
      if(response.data[tmk]){
        var merchantSettings = JSON.stringify(response.data[tmk], null, 2);
        this.setState({ showSettings: true, merchantSettings: merchantSettings, tmkTxt: tmk })
      }
      else{
        this.setState({color : 'red', 'message': errorMessage});
        this.handleAlertDismissal('message', 4);
      }
    }).catch(error => {
      console.error(error);
    });
  }

  handleAlertDismissal(attr, seconds=2) {
    setTimeout(() => {
      this.setState({ [attr]: undefined, color: undefined });
    }, seconds * 1000);
  }

  handleError(error, attr, loader=undefined, color='red', other=undefined) {
    // handles error messaging
    const data = error.response.data;
    let message = 'Looks like there\'s an issue on the server. Try again later';
    if (error.response.status < 500) {
      message = data.message || `No N-File for TMK "${other}"`;
    }
    const changes = loader ? { [attr]: message, [loader]: false, color } : { [attr]: message, color };
    this.setState(changes);
    this.handleAlertDismissal([attr], 4);
  }

  render() {
    const { name, description, value, isLoading, dataList, last_ingestion,
      enabled, active, total, raw_quotes, isModalOpen, tmk, color, message, mpl,
      tmk404, tmkTxt, generate, newtmk, upload_frequency_in_days, merchantSettings,
      showSettings, upward } = this.state;

    const styles = {
      mdl_message: {
        position: 'absolute',
        zIndex: 1000,
        display: tmk404 ? 'inline-block' : 'none'
      }
    };

    // NOTE: commenting out the search/filter bar for now
    // <Search loading={isLoading} value={value} showNoResults={false}
      // onSearchChange={e => this.handleSearchChange(e)}
      // style={{display: 'inline-block'}}/>

    return (
      <div style={{height: 'auto', overflow: 'auto', display: 'block'}}>
        <Message floating color={color} content={message} className='alert-message'
          style={{display: message ? 'inline-block' : 'none'}}/>
        <SortableTableHeader>
          <Table.Row>
            <Table.HeaderCell className='nonSortable'>Enabled</Table.HeaderCell>
            <Table.HeaderCell sorted={enabled}
              onClick={e => this.handleHeaderCellClick(this, 'enabled')}>
              Status
            </Table.HeaderCell>
            <Table.HeaderCell sorted={tmk}
              onClick={e => this.handleHeaderCellClick(this, 'tmk')}>
              TMK
            </Table.HeaderCell>
            <Table.HeaderCell sorted={name}
              onClick={e => this.handleHeaderCellClick(this, 'name')}>
              Name
            </Table.HeaderCell>
            <Table.HeaderCell sorted={last_ingestion}
              onClick={e => this.handleHeaderCellClick(this, 'last_ingestion')}>
              Last Upload
            </Table.HeaderCell>
            <Table.HeaderCell sorted={upload_frequency_in_days}
              onClick={e => this.handleHeaderCellClick(this, 'upload_frequency_in_days')}>
              Upload Frequency in days
            </Table.HeaderCell>
            <Table.HeaderCell sorted={active}
              onClick={e => this.handleHeaderCellClick(this, 'active')}>
              Active Mappings
            </Table.HeaderCell>
            <Table.HeaderCell sorted={total}
              onClick={e => this.handleHeaderCellClick(this, 'total')}>
              Total Mappings
            </Table.HeaderCell>
            <Table.HeaderCell sorted={raw_quotes}
              onClick={e => this.handleHeaderCellClick(this, 'raw_quotes')}>
              Raw Quotes
            </Table.HeaderCell>
            <Table.HeaderCell className='nonSortable'></Table.HeaderCell>
            <Table.HeaderCell className='table-blank-space nonSortable'></Table.HeaderCell>
          </Table.Row>
        </SortableTableHeader>
        <SortableTableBody columns={10}>
          {dataList.map(row => (
            <Table.Row key={row.tmk} style={{backgroundColor: getMerchantColor(row) }}>
              <Table.Cell>
                <Checkbox checked={row.enabled}
                  onClick={e => this.handleMerchantStatusChange(row)}/>
              </Table.Cell>
              <Table.Cell>{getMerchantState(row)}</Table.Cell>
              <Table.Cell>{row.tmk}</Table.Cell>
              <Table.Cell>{row.name}</Table.Cell>
              <Table.Cell>{row.inventory_ingestion.last_ingestion || 'N/A'}</Table.Cell>
              <Table.Cell>{row.upload_frequency_in_days || 'N/A'}</Table.Cell>
              <Table.Cell>{row.active_mappings || 0}</Table.Cell>
              <Table.Cell>{row.total_mappings || 0}</Table.Cell>
              <Table.Cell>{row.raw_quotes || 0}</Table.Cell>
              <Table.Cell>
                <Dropdown text='Actions' id={row.tmk} upward={upward} onClick={() => this.handleDropdownOpen(row)}>
                  <Dropdown.Menu className='left'>
                    <Dropdown.Item as={Dropzone} content='Upload Inventory File' loading={this.state[row.tmk]}
                        onDrop={e => this.handleRawInvUpload(e, row.tmk)}/>
                    <Dropdown.Item content='Download N file' onClick={e => this.handleNFileDownload(row.tmk)}/>
                    <Dropdown.Item content='View Mappings' as={Link} to={`/${row.tmk}`}/>
                    <Dropdown.Item content='View Ingestions' as={Link} to={`/ingestions/${row.tmk}`}/>
                    <Dropdown.Item content='View Settings' onClick={() => this.handleViewSettings(row)}/>
                  </Dropdown.Menu>
                </Dropdown>
              </Table.Cell>
            </Table.Row>
          ))}
        </SortableTableBody>
        <SortableTableFooter>
          <Table.Row>
            <Table.HeaderCell colSpan={10}>
              <Button content='New Merchant' onClick={e => this.setState({isModalOpen: true})}/>
              <Button content='Generate TMK' onClick={e => this.handleGenerateTMK()}/>
              <div style={{float: 'right'}}>
                <Button content='Export List' onClick={e => this.handleExport()}/>
              </div>
            </Table.HeaderCell>
          </Table.Row>
        </SortableTableFooter>
        <Modal size='mini' open={isModalOpen} onClose={() => this.setState({isModalOpen: false})}>
          <Message style={styles.mdl_message} color='yellow'>{tmk404}</Message>
          <Modal.Header>New Merchant</Modal.Header>
          <Modal.Content>
            <Input label='TMK:' value={tmkTxt} onChange={e => this.setState({tmkTxt: e.target.value})}/>
          </Modal.Content>
          <Modal.Actions>
            <Button content='Cancel' onClick={() => this.setState({isModalOpen: false})}/>
            <Button primary content='Create' onClick={e => this.handleFindNewMerchant(tmkTxt)}/>
          </Modal.Actions>
        </Modal>
        <Modal size='mini' open={generate} onClose={() => this.setState({generate: false})}>
          <Modal.Header>Test TMK</Modal.Header>
          <Modal.Content>{newtmk}</Modal.Content>
          <Modal.Actions>
            <Button content='Close' onClick={() => this.setState({generate: false})}/>
          </Modal.Actions>
        </Modal>
        <Modal size='small' open={showSettings} onClose={() => this.setState({showSettings: false})}>
          <Modal.Header>Matchmaker Settings for {tmkTxt}</Modal.Header>
          <Modal.Content><pre>{merchantSettings}</pre></Modal.Content>
          <Modal.Actions>
            <Button content='Close' onClick={() => this.setState({showSettings: false})}/>
          </Modal.Actions>
        </Modal>
      </div>
    );
  }
};
