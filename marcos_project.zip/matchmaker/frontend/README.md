# Uploader UI

To run locally outside of Docker, simply run `npm run start`.

You can also develop locally in the container using `docker-compose up`.
