# Inventory Service

The inventory service manages standardized mechant inventory and a historical record of merchant inventory data.

## Integration

The service provides the following http routes:

| Route | Method | Parameters  |Description |
--------|--------|---------------|---|
|/merchant/{tmk}/inventory|GET|{limit(optional): int, offset(optional):int}|Get a list of the merchant's inventory, returns in json format|
|/merchant/{tmk}/inventory|POST|{'upload':csv_file}|Post a merchant inventory csv|
|/merchant/{tmk}/quote/{mpk}|GET | |Get a quote for a particular merchant sku, returns in json format|

## Development

A Makefile is provided for documentation and for easily running useful tasks. Please see the Makefile for information about the underlying process.

| Commands | Description|
--------------------|-------------
|`make new_migration (-e name="my migration")`|Creates a new migration, optionally supply a short name for the migration|
|`make apply_migrations`| Applies the migrations to the standard and testing database. The docker database must have been brought up at least once for the databases to exist. Note: the python docker-container will apply migrations on startup|
|`make test`| Runs all the tests|
