'''
Transform the inventory object for the response.
'''
from distutils.util import strtobool


def inventory_transform(data_dict):
    # transforms the inventory object to the result
    # here, we only change the active key to a boolean
    data_dict['active'] = bool(strtobool(data_dict.get('active', 'false')))
    data_dict['evergreen'] = None if data_dict['evergreen'] == 'None' else bool(strtobool(data_dict['evergreen']))
    data_dict['msku'] = None if data_dict['msku'] == 'None' else data_dict['msku']
    data_dict['vintage'] = None if data_dict['vintage'] == 'None' else data_dict['vintage']
    data_dict['upc'] = None if data_dict['upc'] == 'None' else data_dict['upc']
    data_dict['brand'] = None if data_dict['brand'] == 'None' else data_dict['brand']
    data_dict['name'] = None if data_dict['name'] == 'None' else data_dict['name']
    return data_dict


def ingestion_transform(data_dict):
    data_dict['success'] = bool(strtobool(data_dict.get('success', 'false')))
    return data_dict
