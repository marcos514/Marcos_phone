import csv
import io
import json
import re
from datetime import datetime

import MySQLdb
from MySQLdb import DatabaseError
from tornado import gen
from tornado.httpclient import AsyncHTTPClient
from tornado.web import RequestHandler

import config
import services
from db import Database
from transforms import inventory_transform, ingestion_transform


class BaseRequestHandler(RequestHandler):
    def prepare(self):
        super(BaseRequestHandler, self).prepare()


class JsonApplicationRequestHandler(BaseRequestHandler):
    """
    Our json request handler extends tornado's Request handler and does some basic things specific to json endpoints
    """

    def prepare(self):

        super(JsonApplicationRequestHandler, self).prepare()

        content_type = self.request.headers.get('Content-Type', '')

        allowed_types = [
            'application/json; charset=utf-8',
            'application/json;charset=utf-8',
            'application/json'
        ]

        if str(content_type).lower() in allowed_types and self.request.body:
            self.json_body = json.loads(self.request.body.decode('utf-8'))
        else:
            self.json_body = None

        self.set_default_headers()

    def set_default_headers(self):
        self.add_header('Content-Type', 'application/json; charset=UTF-8')
        self.add_header('Access-Control-Allow-Origin', '*')

    def write_error(self, status_code, **kwargs):
        self.set_status(status_code)
        reason = kwargs['reason'] if 'reason' in kwargs else self._reason
        self.finish({"code": status_code, "message": reason})

    def write_json(self, chunk):
        self.set_header('Content-Type', 'application/json; charset=UTF-8')
        super(JsonApplicationRequestHandler, self).write(json.dumps(chunk, sort_keys=True))


class CSVWriter(object):

    @gen.coroutine
    def write_csv(self, items, fieldnames=[]):
        csv_stream = io.StringIO()
        writer = csv.DictWriter(csv_stream, fieldnames=fieldnames)

        if fieldnames:
            writer.writeheader()
            csv_stream.seek(0)
            self.write(csv_stream.read())
            yield self.flush()
            csv_stream.truncate(0)
            csv_stream.seek(0)

        for item in items:
            writer.writerow(item)
            csv_stream.seek(0)
            self.write(csv_stream.read())
            csv_stream.truncate(0)
            csv_stream.seek(0)
        yield self.flush()
        self.finish()


class MerchantInventoryHandler(JsonApplicationRequestHandler, CSVWriter):

    @gen.coroutine
    @Database
    def get(self, tmk, db):

        sql = "SELECT * FROM merchant_inventory WHERE tmk = %s"

        limit, offset = self.get_query_argument('limit', None), self.get_query_argument('offset', None)
        if limit or offset:
            sql += f" LIMIT {int(limit) if limit else 18446744073709551610}  OFFSET {int(offset) if offset else 0}"

        cursor = db.execute(sql, [tmk])
        response = []
        fieldnames = []
        for row in cursor.fetchall():
            if not fieldnames:
                fieldnames = list(row.keys())
            formatted = {k: str(value) for k, value in row.items()}
            response.append(inventory_transform(formatted))
        csv = self.get_query_argument('csv', 'false').lower() == 'true'
        if not csv:
            self.write_json(response)
        else:
            date = '{:%Y-%m-%dT%H_%M}'.format(datetime.now())
            filename = 'attachment; filename={0}_inv_{1}.csv'
            self.set_header('Content-Type', 'text/csv')
            self.set_header('Content-Disposition', filename.format(tmk, date))
            self.write_csv(response, fieldnames)

    @gen.coroutine
    @Database
    def post(self, tmk, db):
        # get json body
        if self.json_body:
            # having a json body means that extraction failed
            description = self.json_body['description']
            lines = ""
            success = 0
        else:
            # get the file from the request
            files = self.request.files.get('upload', None)
            success = 1
            description = ""
            if not files or len(files) < 1 or not re.search(r"\.csv$", files[0]['filename'], re.IGNORECASE):
                self.set_status(400)
                self.write_json({'message': 'Please supply a .csv file'})
                return
            try:
                lines = str(files[0]['body'], 'utf-8').replace('\ufeff', '').splitlines()
            except UnicodeDecodeError:
                try:
                    lines = str(files[0]['body'], 'latin-1').splitlines()
                except:
                    self.set_status(400)
                    self.write_json({"message": "Invalid csv file, encoding not recognized. Please use utf 8."})
                    return
            except:
                self.set_status(400)
                self.write_json({"message": "Invalid csv file, could not decode."})
                return

        data = csv.DictReader(lines)
        # for now, the only possible data source id is 1 (file upload)
        data_source_id = 1

        try:
            ingestion = services.MerchantInventoryIngestion(data, db.connection)
            result = ingestion.run(tmk, data_source_id, success, description)
        except services.ValidationException as e:
            self.set_status(400)
            self.write_json({"message": e.args[0]})
            return
        except  DatabaseError as e:
            self.set_status(400)
            self.write_json({"message": e.args[1]})
            return
        client = AsyncHTTPClient()
        client.fetch('{0}/{1}'.format(config.INVENTORY_TRIGGER, tmk), raise_error=False) #trigger the uploader, don't wait for response
        self.write_json(result)


class MerchantQuoteHandler(JsonApplicationRequestHandler):
    @gen.coroutine
    @Database
    def get(self, tmk, mpk, db):
        data = db.fetchone("SELECT * FROM merchant_inventory WHERE tmk = %s and mpk = %s;", [tmk, mpk])
        if not data:
            return self.write_error(404, reason=f'mpk {mpk} for merchant {tmk} not found')
        response = {k: str(value) for k, value in data.items()}
        self.write_json(inventory_transform(response))

    @gen.coroutine
    @Database
    def put(self, tmk, mpk, db):
        # change the status of an inventory row
        quote = db.fetchone("SELECT * FROM merchant_inventory WHERE tmk = %s and mpk = %s;", [tmk, mpk])
        if not quote:
            return self.write_error(404, reason=f'mpk {mpk} for merchant {tmk} not found')
        quote = inventory_transform({k: str(value) for k, value in quote.items()})

        # get request data, update the quote, and return it if sucessful
        request_data = self.json_body
        if not request_data:
            return self.write_error(400, reason='No JSON body given')
        quote['active'] = int(request_data.get('active', False))
        db.execute('UPDATE merchant_inventory SET active = %s WHERE tmk = %s AND mpk = %s;', [quote['active'], tmk, mpk])
        self.write_json(quote)


class IngestionsHandler(JsonApplicationRequestHandler):
    @gen.coroutine
    @Database
    def get(self, tmks, db):
        tmks = tmks.split(",")
        q_marks = ('%s ,' * len(tmks))[0:-2]
        data = db.fetchall(f"""SELECT inventory_ingestion.*,
            inventory_data_source.name data_source,
            COALESCE(inventory.inventory_count, 0) inventory_count
            FROM inventory_ingestion
            INNER JOIN (
                SELECT max(id) last_id, tmk
                FROM inventory_ingestion
                GROUP BY tmk
            ) AS max_ingestion ON max_ingestion.last_id = inventory_ingestion.id
            LEFT JOIN (
                SELECT count(*) inventory_count, tmk
                FROM merchant_inventory
                WHERE active = 1
                GROUP BY tmk
            ) AS inventory
                ON inventory.tmk = inventory_ingestion.tmk
            INNER JOIN inventory_data_source
                ON inventory_data_source.id = inventory_ingestion.data_source_id
            WHERE inventory_ingestion.tmk IN ({q_marks})
            ORDER BY inventory_ingestion.id;""", tmks)
        if not data:
            return self.write_error(404, reason=f'No data found for given tmks{tmks}')
        response = []
        for row in data:
            response.append({k: str(value) for k, value in row.items()})
        self.write_json(response)


class MerchantInventoryMultHandler(JsonApplicationRequestHandler):

    @gen.coroutine
    @Database
    def get(self, tmks, db):
        merchants = tmks.split(",")
        sql = "SELECT * FROM merchant_inventory WHERE tmk in %s"

        limit, offset = self.get_query_argument('limit', None), self.get_query_argument('offset', None)
        if limit or offset:
            sql += f" LIMIT {int(limit) if limit else 18446744073709551610}  OFFSET {int(offset) if offset else 0}"

        cursor = db.fetchall(sql, [merchants])

        response = []
        for inventory in cursor:
            formatted = {key: str(value) for key, value in inventory.items()}
            response.append(inventory_transform(formatted))

        self.write_json(response)


class MerchantIngestionHandler(JsonApplicationRequestHandler, CSVWriter):

    @gen.coroutine
    @Database
    def get(self, tmk, db):
        sql = '''SELECT inventory_ingestion.id, inventory_ingestion.run_date, inventory_ingestion.tmk,
            inventory_ingestion.unchanged, inventory_ingestion.inserted, inventory_ingestion.updated,
            inventory_ingestion.deactivated, inventory_ingestion.skipped, inventory_ingestion.success, inventory_ingestion.description,
            data_source.name data_source
            FROM inventory_ingestion
            LEFT JOIN inventory_data_source AS data_source
                ON data_source.id = inventory_ingestion.data_source_id
            WHERE inventory_ingestion.tmk = %s'''
        cursor = db.fetchall(sql, [tmk])
        response = []
        fieldnames = []

        for row in cursor:
            if not fieldnames:
                fieldnames = list(row.keys())
            formatted = {k: str(value) for k, value in row.items()}
            response.append(ingestion_transform(formatted))

        csv = self.get_query_argument('csv', 'false').lower() == 'true'
        if not csv:
            self.write_json(response)
        else:
            date = '{:%Y-%m-%dT%H_%M}'.format(datetime.now())
            filename = 'attachment; filename={0}_extraction_logs_{1}.csv'
            self.set_header('Content-Type', 'text/csv')
            self.set_header('Content-Disposition', filename.format(tmk, date))
            self.write_csv(response, fieldnames)

