import os
from distutils.util import strtobool

'''
All Configs use os.environ.get with sensible default values specified.

The default values are meant for local development, while any production instance should have an appropriately provisioned server.

Using environment variables for configs is recommended by https://12factor.net/config

'''

#TORNADO CONFIGURATIONS
TORNADO_LISTEN_PORT = int(os.environ.get('TORNADO_LISTEN_PORT', 8888))
TORNADO_DEBUG       = bool(strtobool(os.environ.get('TORNADO_DEBUG', 'False')))

#DATABASE CONFIGURATIONS
DB_NAME = os.environ.get('DB_NAME', 'inventory_db')
DB_HOST = os.environ.get('DB_HOST', '127.0.0.1')
DB_PORT = int(os.environ.get('DB_PORT', 3307))
DB_USER = os.environ.get('DB_USER', 'root')
DB_PASS = os.environ.get('DB_PASS', 'root')

#for triggering the inventory uploader
INVENTORY_TRIGGER = os.environ.get('INVENTORY_TRIGGER', 'http://localhost/u/v2/trigger/')
