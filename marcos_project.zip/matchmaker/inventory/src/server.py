import sys
import tornado.ioloop
import tornado.options as options
from tornado.web import RequestHandler

import config
from handlers import (
  MerchantInventoryHandler,
  MerchantQuoteHandler,
  IngestionsHandler,
  MerchantInventoryMultHandler,
  MerchantIngestionHandler
)

inventory_ascii = r"""
                 ___         ___          ___          ___       ___          ___          ___       ___
      ___       /\__\       /\__\        /\  \        /\__\     /\  \        /\  \        /\  \     |\__\
     /\  \     /::|  |     /:/  /       /::\  \      /::|  |    \:\  \      /::\  \      /::\  \    |:|  |
     \:\  \   /:|:|  |    /:/  /       /:/\:\  \    /:|:|  |     \:\  \    /:/\:\  \    /:/\:\  \   |:|  |
     /::\__\ /:/|:|  |__ /:/__/  ___  /::\~\:\  \  /:/|:|  |__   /::\  \  /:/  \:\  \  /::\~\:\  \  |:|__|__
  __/:/\/__//:/ |:| /\__\|:|  | /\__\/:/\:\ \:\__\/:/ |:| /\__\ /:/\:\__\/:/__/ \:\__\/:/\:\ \:\__\ /::::\__\
 /\/:/  /   \/__|:|/:/  /|:|  |/:/  /\:\~\:\ \/__/\/__|:|/:/  //:/  \/__/\:\  \ /:/  /\/_|::\/:/  //:/~~/~
 \::/__/        |:/:/  / |:|__/:/  /  \:\ \:\__\      |:/:/  //:/  /      \:\  /:/  /    |:|::/  //:/  /
  \:\__\        |::/  /   \::::/__/    \:\ \/__/      |::/  / \/__/        \:\/:/  /     |:|\/__/ \/__/
   \/__/        /:/  /     ~~~~         \:\__\        /:/  /                \::/  /      |:|  |
                \/__/                    \/__/        \/__/                  \/__/        \|__|

       ___          ___
     /\  \        /\  \         ___
    /::\  \      /::\  \       /\  \
   /:/\:\  \    /:/\:\  \      \:\  \
  /::\~\:\  \  /::\~\:\  \     /::\__\
 /:/\:\ \:\__\/:/\:\ \:\__\ __/:/\/__/
 \/__\:\/:/  /\/__\:\/:/  //\/:/  /
      \::/  /      \::/  / \::/__/
      /:/  /        \/__/   \:\__\
     /:/  /                  \/__/
     \/__/
"""

class HelloWorld(RequestHandler):
    def get(self):
        self.write(f"<pre>{inventory_ascii}</pre>")


routes = [
    (r'/?', HelloWorld),
    (r"/merchant/(?P<tmk>[\w]+)/inventory/?", MerchantInventoryHandler),
    (r"/merchant/(?P<tmk>[\w]+)/quote/(?P<mpk>[\w]+)/?", MerchantQuoteHandler),
    (r"/ingestions/(?P<tmks>[\w,]+)/?", IngestionsHandler),
    (r"/merchant/(?P<tmk>[\w,]+)/ingestions/?", MerchantIngestionHandler),
    (r"/merchants/(?P<tmks>[\w,]+)/inventory/?", MerchantInventoryMultHandler),
]

def make_app(debug=False):
    return tornado.web.Application(routes, debug=debug)

if __name__ == "__main__":
    # enable pretty logging
    options.parse_command_line()

    app = make_app(config.TORNADO_DEBUG)
    app.listen(config.TORNADO_LISTEN_PORT)
    print(inventory_ascii, file=sys.stderr)
    print(f"Running on port {config.TORNADO_LISTEN_PORT}", file=sys.stderr)
    tornado.ioloop.IOLoop.current().start()
