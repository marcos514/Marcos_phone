"""
Add indexes for inventory_ingestion and merchant_inventory tables
"""

from yoyo import step

__depends__ = {'20180604_01_k5XR6-add-merchant-sku'}

steps = [
    step("""
        ALTER TABLE inventory_ingestion ADD INDEX idx_inventory_ingestion_id_tmk (id, tmk);
        ALTER TABLE merchant_inventory ADD INDEX idx_merchant_inventory_tmk (tmk);
        ALTER TABLE merchant_inventory ADD INDEX idx_merchant_inventory_tmk_active (tmk, active);
    """)
]
