"""
Add columns success and description to inventory_ingestion
"""

from yoyo import step

__depends__ = {'20180810_01_qv4bq-add-indexes-for-inventory-ingestion-and-merchant-inventory-tables'}

steps = [
    step("""
    ALTER TABLE `inventory_ingestion`
    ADD COLUMN `description` TEXT,
    ADD COLUMN `success` tinyint(4) UNSIGNED NOT NULL DEFAULT 1;
    """)
]
