"""
Initial db structure
"""

from yoyo import step

__depends__ = {}



steps = [

    step("""   
-- ----------------------------
-- Table structure for inventory_data_source
-- ----------------------------

CREATE TABLE IF NOT EXISTS `inventory_data_source` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `inventory_data_source` (`name`) VALUES ('file_upload');

-- ----------------------------
-- Table structure for inventory_ingestion
-- ----------------------------

CREATE TABLE IF NOT EXISTS `inventory_ingestion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_source_id` int(11) NOT NULL,
  `run_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tmk` char(9) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `data_source` (`data_source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for inventory_row_raw
-- ----------------------------

CREATE TABLE IF NOT EXISTS `inventory_row_raw` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ingestion_id` int(11) NOT NULL,
  `data` json NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ingestion_id` (`ingestion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  
-- ----------------------------
-- Table structure for merchant_inventory
-- ----------------------------

CREATE TABLE IF NOT EXISTS `merchant_inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tmk` char(6) NOT NULL,
  `mpk` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mpk` (`mpk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    
"""),

]


