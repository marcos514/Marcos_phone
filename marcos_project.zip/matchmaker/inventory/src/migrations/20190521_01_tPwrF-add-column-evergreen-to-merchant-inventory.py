"""
Add column evergreen to merchant inventory
"""

from yoyo import step

__depends__ = {'20190228_01_2g60L-add-brand-name-and-vintage-columns-to-merchant-inventory-table'}

steps = [
    step("""
        ALTER TABLE `merchant_inventory`
        ADD COLUMN `evergreen` tinyint(4) DEFAULT NULL;
    """)
]
