"""
update_inventory_ingestion_table
"""

from yoyo import step

__depends__ = {'20170821_01_A27Lf-initial-db-structure'}

steps = [
    step("""
    ALTER TABLE `inventory_ingestion`
    ADD COLUMN `unchanged` int(11) UNSIGNED NOT NULL DEFAULT 0,
    ADD COLUMN `inserted` int(11) UNSIGNED NOT NULL DEFAULT 0,
    ADD COLUMN `updated` int(11) UNSIGNED NOT NULL DEFAULT 0,
    ADD COLUMN `deactivated` int(11) UNSIGNED NOT NULL DEFAULT 0;

    ALTER TABLE `merchant_inventory` ADD COLUMN `last_ingestion_id` int(11) NOT NULL DEFAULT 0;
    """,

         )
]
