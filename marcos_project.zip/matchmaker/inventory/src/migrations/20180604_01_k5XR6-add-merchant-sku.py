"""
add-merchant-sku
"""

from yoyo import step

__depends__ = {'20170921_01_ObqK7'}

steps = [
    step('''
        ALTER TABLE `merchant_inventory` ADD COLUMN `msku` varchar(50) DEFAULT NULL AFTER `quantity`;
    ''')
]
