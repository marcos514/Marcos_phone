"""

"""

from yoyo import step

__depends__ = {'20170828_01_vsva7-update-inventory-ingestion-table'}

steps = [
    step("""
ALTER TABLE `merchant_inventory` DROP INDEX `mpk`;
ALTER TABLE `merchant_inventory` ADD UNIQUE INDEX `mpk-tpk`(`mpk`, `tmk`) USING BTREE;
""")
]
