"""
Add column skipped to inventory ingestions
"""

from yoyo import step

__depends__ = {'20181018_01_rNVtp-add-columns-success-and-description-to-inventory-ingestion'}

steps = [
    step("""
    ALTER TABLE `inventory_ingestion`
    ADD COLUMN `skipped` int(11) UNSIGNED NOT NULL DEFAULT 0;
    """)
]
