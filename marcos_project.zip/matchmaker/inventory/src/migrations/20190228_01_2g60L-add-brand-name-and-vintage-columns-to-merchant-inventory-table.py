"""
Add brand, name and vintage columns to merchant_inventory table
"""

from yoyo import step

__depends__ = {'20190226_01_XvS6g-add-column-skipped-to-inventory-ingestions'}

steps = [
    step("""
        ALTER TABLE `merchant_inventory`
        ADD COLUMN `name` varchar(200) DEFAULT NULL,
        ADD COLUMN `vintage` varchar(20) DEFAULT NULL,
        ADD COLUMN `brand` varchar(50) DEFAULT NULL,
        ADD COLUMN `upc` varchar(50) DEFAULT NULL;
    """)
]
