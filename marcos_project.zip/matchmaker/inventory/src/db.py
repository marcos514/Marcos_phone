import MySQLdb
import config

class Database(object):

    def __init__(self, f=None):
        self.f = f


    """docstring for DataBase. This is a database wrapper. This will be used
    with the `with` python syntax handler"""

    def __enter__(self):
        configuration = {
            'host': config.DB_HOST,
            'port': config.DB_PORT,
            'user': config.DB_USER,
            'passwd': config.DB_PASS,
            'db': config.DB_NAME,
            'autocommit': True,
            'charset': 'utf8'
        }

        self.conn = MySQLdb.connect(**configuration)
        self.cursor = self.conn.cursor(MySQLdb.cursors.DictCursor)
        return self

    def execute(self, *args, **kwargs):
        '''
        Passes the execute command on to the cursor
        :param args:
        :param kwargs:
        :return: MYSQLdb.cursor
        '''
        self.cursor.execute(*args, **kwargs)
        return self.cursor

    def __call__(self, *args, **kwargs):

        if self.f is None:
            raise Exception("Not instantiated as a decorator")
        '''
        Injects a database instance using with
        :param args:
        :param kwargs:
        :return: Database
        '''
        with Database() as db:
            kwargs['db'] = db
            self.f(*args, **kwargs)

    @property
    def connection(self)-> MySQLdb.connection:
        return self.conn

    def fetchone(self, *args, **kwargs):
        self.cursor.execute(*args, **kwargs)
        return self.cursor.fetchone()

    def fetchall(self, *args, **kwargs):
        self.cursor.execute(*args, **kwargs)
        return self.cursor.fetchall()

    def __exit__(self, unused_type, unused_value, unused_traceback):
        self.cursor.close()
        self.conn.close()
