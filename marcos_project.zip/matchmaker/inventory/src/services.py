
import MySQLdb
import csv
import json
from operator import add
from collections import OrderedDict

class ValidationException(Exception):
    pass


class MerchantInventoryIngestion:

    def __init__(self, m_csv: csv.DictReader, db: MySQLdb.connection):
        self.csv = m_csv
        self.db = db

    def validate_row(self, row, tmk):

        required_fields = set(('tmk', 'mpk', 'price', 'quantity'))
        missing_fields = required_fields - (required_fields & set(row))

        if missing_fields:
            raise ValidationException(f"CSV is missing the required fields: {str(missing_fields)}")

        if row['tmk'] != tmk:
            raise ValidationException(f"Row validation failed: TMK {row['tmk']} does not match {tmk}")


    #@todo document return
    def run(self, tmk: str, data_source_id: int, success: int, description: str):
        """
        Runs the ingestion process. Goes row by row through lines in csv and updates / inserts into
        snapshot of merchant's inventory.

        Inventory not found in current ingestion is deactivated.

        The the original line is dumped into a json field for historical records.

        The whole ingestion runs in a transaction

        :param tmk: The tmk we are ingesting for, if it does not match will throw an exception
        :param data_source_id: The source of the ingestion

        :return: {unchanged, inserted, updated, deactivated, skipped, ingestion_id}
        """
        auto_commit_value = self.db.get_autocommit()
        self.db.autocommit(False)

        cursor = self.db.cursor()

        # Take last ingestion id and clear inventory_row_raw
        cursor.execute("SELECT id from inventory_ingestion where tmk = %s order by id desc limit 1", [tmk])
        ingestion_rows = cursor.fetchall()
        if len(ingestion_rows) > 0:
            last_ingestion_id = ingestion_rows[0][0]
            cursor.execute("DELETE from inventory_row_raw where ingestion_id=%s", [last_ingestion_id])

        # Insert new ingestion on inventory_ingestion
        cursor.execute("INSERT INTO inventory_ingestion (tmk, data_source_id, success, description) VALUES (%s, %s, %s, %s);", (tmk, data_source_id, success, description))
        ingestion_id = int(cursor.lastrowid)

        results = [0,0,0]
        skipped = 0
        # Insert new rows on inventory_row_raw and update merchant_inventory
        for row in self.csv:
            try:
                self.validate_row(row, tmk)
                json_data = json.dumps(row)
                sql = "INSERT INTO inventory_row_raw (ingestion_id, data) VALUES (%s, %s);"
                cursor.execute(sql, (ingestion_id, json_data))
                results = map(add, results, self.update_inventory(tmk, row, cursor))
                cursor.execute("UPDATE merchant_inventory SET last_ingestion_id = %s WHERE tmk = %s AND mpk = %s", [ingestion_id, tmk, row["mpk"]])
            except ValidationException as ex:
                # Skip row if validation failes - this is to add more
                # flexibilty in the upload process, is pretty common
                # to have inventory files with structural errors
                skipped += 1
                pass

        deactivated = cursor.execute("UPDATE merchant_inventory SET active = 0, last_ingestion_id = %s WHERE active = 1 AND last_ingestion_id != %s AND tmk = %s",
                       [ingestion_id, ingestion_id, tmk])


        results = list(results)
        results.append(deactivated)
        results.append(skipped)
        results.append(ingestion_id)
        cursor.execute("UPDATE inventory_ingestion SET unchanged=%s, inserted=%s, updated=%s, deactivated=%s, skipped=%s WHERE id=%s", results)


        self.db.commit()
        self.db.autocommit(auto_commit_value)

        results = zip(['unchanged', 'inserted', 'updated', 'deactivated', 'skipped', 'ingestion_id'], results)
        return OrderedDict(results)

    def update_inventory(self, tmk, row, cursor) -> list:
        qry = '''
            INSERT INTO merchant_inventory (tmk, mpk, price, quantity, name, vintage, brand, upc, msku, evergreen, active)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 1) ON DUPLICATE KEY UPDATE price=VALUES(price),
            quantity=VALUES(quantity), active=VALUES(active), msku=VALUES(msku), evergreen=VALUES(evergreen)
        '''
        result = cursor.execute(qry, (
            tmk, row['mpk'], row['price'], row['quantity'], row['mname'],
            row['mvintage'], row['mbrand'], row['mupc'], row['msku'], row['evergreen'] or None
        ))
        return_values = [0,0,0] # unchanged, inserted, update
        return_values[result] = 1
        return return_values
