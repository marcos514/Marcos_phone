import os
import csv
import unittest
from collections import OrderedDict

import config
from db import Database
from services import MerchantInventoryIngestion, ValidationException


class MerchantServiceTestCase(unittest.TestCase):

    def setUp(self):
        """
        our setup has a sanity check for _test in the self.db.name so we don't accidentally do something bad
        :return:
        """
        if config.DB_NAME.find("_test") < 0:
            config.DB_NAME += "_test"

        self.db = Database().__enter__()
        database = self.db.fetchone("select database() as db")
        self.assertTrue("_test" in database['db'], 'Attempted to use application database in test!!!!!')

        self.truncate_db()

    def ingest_file(self, name):
        """
        ingests a file for testing
        :param name: the file name to ingest
        :return:
        """
        file = os.path.dirname(os.path.abspath(__file__))
        path = file + "/files/" + name
        with open(path, 'r', encoding='utf-8-sig') as f:
            merchant_csv = csv.DictReader(f)
            ingestionProcess = MerchantInventoryIngestion(merchant_csv, self.db.connection)
            result = ingestionProcess.run('MCNFGE', 1, 1, "")
            return result

    def truncate_db(self):
        self.db.execute("TRUNCATE TABLE merchant_inventory")
        self.db.execute("TRUNCATE TABLE inventory_ingestion")
        self.db.execute("TRUNCATE TABLE inventory_row_raw")


    def test_ingesting_file(self):
        """
        Ingests the same file of 84 items twice
        Might not be necessary with some of the other tests but serves as a sanity check w/ more rows
        :return:
        """
        result = self.ingest_file("merchant_inventory.csv")
        self.assertEqual(result['inserted'], 84) # all these should have been inserts

        merchant_inventory = self.db.fetchall("SELECT * FROM merchant_inventory")
        self.assertEqual(len(merchant_inventory), 84)
        inventory_ingestion = self.db.fetchall("SELECT * FROM inventory_ingestion")
        self.assertEqual(len(inventory_ingestion), 1)
        inventory_row_raw = self.db.fetchall("SELECT * FROM inventory_row_raw")
        self.assertEqual(len(inventory_row_raw), 84)

        result = self.ingest_file("merchant_inventory.csv")
        self.assertEqual(result['unchanged'], 84) # no action should have occured on any of these

        merchant_inventory = self.db.fetchall("SELECT * FROM merchant_inventory")
        self.assertEqual(len(merchant_inventory), 84)
        inventory_ingestion = self.db.fetchall("SELECT * FROM inventory_ingestion")
        self.assertEqual(len(inventory_ingestion), 2)
        inventory_row_raw = self.db.fetchall("SELECT * FROM inventory_row_raw")
        self.assertEqual(len(inventory_row_raw), 84)

    def test_inventory_insert_update_deactivate(self):
        """
        Test some more advanced features, updates, inserts and deactivations
        :return:
        """
        self.db.execute("TRUNCATE TABLE merchant_inventory")
        self.db.execute("TRUNCATE TABLE inventory_ingestion")
        self.db.execute("TRUNCATE TABLE inventory_row_raw")

        result = self.ingest_file("inventory_insert.csv")
        self.assertEqual(list(result.values()), [0, 13, 0, 0, 0, 1]) #13 inserted

        result = self.ingest_file("inventory_deactivate.csv") #lets deactivate 3, the FIRST 3 in the file is missing
        self.assertEqual(list(result.values()), [10, 0, 0, 3, 0, 2]) #10 inserted, 3 deactivated

        result = self.ingest_file("inventory_update.csv")  # lets update 2, changing quantities
        self.assertEqual(list(result.values()), [8, 0, 2, 0, 0, 3])  # 8 unchanged, 2 updated

        result = self.ingest_file("inventory_insert.csv") #lets reinsert the original, we should now have all active... 5 updates
        self.assertEqual(list(result.values()), [8, 0, 5, 0, 0, 4])  # 13 inserted


    def get_mock_ingestion(self)-> MerchantInventoryIngestion:
        class MockIngestion(MerchantInventoryIngestion):
            def __init__(self):
                pass
        return MockIngestion()

    def test_insert_inventory_then_update(self):
        """
        Test updating and individual row in the inventory
        :return:
        """
        ingestionProcess = self.get_mock_ingestion()
        row =  OrderedDict([('mpk', '301032'), ('price', '13.99'), ('quantity', '32.0'), ('id', '301032'),
                     ('name', 'Tilia - Malbec 2014 Argentina'), ('container_name_str', ''),
                     ('barcode', '0098709670150'), ('blid', 'qdht8tpil72e'), ('department', 'Red Argentina'),
                     ('department_id', '38958'), ('image_url',
                                                  'https://s3.amazonaws.com/bindo-images/product_graphics/324169/medium/product_graphic.jpg?1418490902'),
                     ('is_parent', 'False'), ('secondary_barcode', ''), ('storefront_allow_negative_quantity', 'True'),
                     ('tax_rate', '0.08875'), ('track_quantity', 'True'), ('updated_at', '2017-08-08T02:10:34.000Z'),
                     ('web_price', ''), ('mvintage', ''), ('msku', ''), ('mbrand', ''), ('mname', ''), ('mupc',''), ('evergreen', '0')])

        cursor = self.db.connection.cursor()

        result = ingestionProcess.update_inventory('MCNFGE', row,cursor)

        self.assertEqual(result, [0,1,0])

        result = ingestionProcess.update_inventory('MCNFGE', row, cursor)

        self.assertEqual(result, [1,0,0])

        row['quantity'] = "20"

        result = ingestionProcess.update_inventory('MCNFGE', row, cursor)

        self.assertEqual(result, [0,0,1])

        all_rows = self.db.fetchall("SELECT * FROM merchant_inventory")

        self.assertTrue(len(all_rows), 1)

    def test_validation(self):
        i = self.get_mock_ingestion()
        try:
            i.validate_row({'mpk':'ABCDEFGHI',"price": 1, "quantity": 1}, "ABCDEF")
            self.assertTrue(False, 'This should have failed validation')
        except ValidationException as e:
            pass

        try:
            i.validate_row({'tmk': 'BBCDEF','mpk':'ABCDEFGHI',"price": 1, "quantity": 1}, "ABCDEF")
            self.assertTrue(False, 'This should have failed validation')
        except ValidationException as e:
            pass

        result = self.ingest_file('wrong_merchant.csv')
        self.assertEqual(list(result.values()),  [0, 9, 0, 0, 1, 1]) # 1 skipped


if __name__ == '__main__':
    unittest.main()
