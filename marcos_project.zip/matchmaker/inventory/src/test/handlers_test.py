import json
import config
import tornado.testing
from server import make_app
from db import Database
import unittest


class WebTestCase(tornado.testing.AsyncHTTPTestCase):

    def setUp(self):
        super(WebTestCase, self).setUp()
        if config.DB_NAME.find("_test") < 0:
            config.DB_NAME += "_test"

        self.db = Database().__enter__()
        database = self.db.fetchone("select database() as db")
        self.assertTrue("_test" in database['db'], 'Attempted to use application database in test!!!!!')


    def get_app(self):
        return make_app(False)

class TestMerchantQuote(WebTestCase):

    def test_get_merchant_quote(self):
        self.db.execute("TRUNCATE TABLE `merchant_inventory`")
        self.db.execute(
            "INSERT INTO `merchant_inventory` (tmk,mpk,price,quantity,active) VALUES(%s,%s,%s,%s,%s)",
            ['MCNFGE', '301032', 20.00, 100, 1]
        )
        response = self.fetch('/merchant/MCNFGE/quote/301032')
        self.assertEqual(response.code, 200)
        body = json.loads(response.body.decode('utf-8'))
        self.assertEqual(body["tmk"], "MCNFGE")
        self.assertEqual(body["mpk"], "301032")
        self.assertEqual(body["price"], '20.00')
        self.assertEqual(body["quantity"], '100')

    def test_get_merchant_quote_not_found(self):
        self.db.execute("TRUNCATE TABLE `merchant_inventory`")
        response = self.fetch('/merchant/MCNFGE/quote/301032')
        self.assertEqual(response.code, 404)
        self.assertEqual(json.loads(response.body.decode('utf-8')),{"code": 404, "message": "mpk 301032 for merchant MCNFGE not found"})


class TestMerchantInventory(WebTestCase):

    def test_get_merchant_inventory_not_found(self):
        self.db.execute("TRUNCATE TABLE `merchant_inventory`")
        response = self.fetch('/merchant/MCNFGE/inventory')
        self.assertEqual(response.code, 200)
        body = json.loads(response.body.decode('utf-8'))
        self.assertEqual(body, [])

    def test_get_merchant_inventory(self):
        self.db.execute("TRUNCATE TABLE `merchant_inventory`")
        self.db.execute(
            "INSERT INTO `merchant_inventory` (tmk,mpk,price,quantity,active) VALUES(%s,%s,%s,%s,%s)",
            ['MCNFGE', '301032', 20.00, 100, 1]
        )
        self.db.execute(
            "INSERT INTO `merchant_inventory` (tmk,mpk,price,quantity,active) VALUES(%s,%s,%s,%s,%s)",
            ['MCNFGE', '301033', 20.00, 100, 1]
        )
        self.db.execute(
            "INSERT INTO `merchant_inventory` (tmk,mpk,price,quantity,active) VALUES(%s,%s,%s,%s,%s)",
            ['MCNFGE', '301034', 20.00, 100, 1]
        )
        self.db.execute(
            "INSERT INTO `merchant_inventory` (tmk,mpk,price,quantity,active) VALUES(%s,%s,%s,%s,%s)",
            ['MCNFGE', '301035', 20.00, 100, 1]
        )


        response = self.fetch('/merchant/MCNFGE/inventory')
        self.assertEqual(response.code, 200)
        body = json.loads(response.body.decode('utf-8'))
        self.assertEqual(body[0]["tmk"], "MCNFGE")
        self.assertEqual(body[0]["mpk"], "301032")
        self.assertEqual(body[0]["price"], '20.00')
        self.assertEqual(body[0]["quantity"], '100')

        self.assertEqual(body[1]["tmk"], "MCNFGE")
        self.assertEqual(body[1]["mpk"], "301033")
        self.assertEqual(body[1]["price"], '20.00')
        self.assertEqual(body[1]["quantity"], '100')

        self.assertEqual(len(body), 4)

        response = self.fetch('/merchant/MCNFGE/inventory?limit=2')
        body = json.loads(response.body.decode('utf-8'))
        self.assertEqual(len(body), 2)

        response = self.fetch('/merchant/MCNFGE/inventory?offset=3')
        body = json.loads(response.body.decode('utf-8'))
        self.assertEqual(len(body), 1)

        response = self.fetch('/merchant/MCNFGE/inventory?limit=2&offset=1')
        body = json.loads(response.body.decode('utf-8'))
        self.assertEqual(len(body), 2)


class TestIngestionsHandler(WebTestCase):
    def test_get_ingestions(self):
        self.db.execute("TRUNCATE TABLE `inventory_ingestion`")
        self.db.execute("TRUNCATE TABLE `merchant_inventory`")
        self.db.execute("INSERT INTO `inventory_ingestion` (tmk,data_source_id) VALUES ('ABCDEF',1)")
        self.db.execute("INSERT INTO `inventory_ingestion` (tmk,data_source_id) VALUES ('FEDCBA',1)")
        self.db.execute("INSERT INTO `inventory_ingestion` (tmk,data_source_id) VALUES ('ABCDEF',1)")
        self.db.execute(
            "INSERT INTO `merchant_inventory` (tmk,mpk,price,quantity,active) VALUES(%s,%s,%s,%s,%s)",
            ['ABCDEF', '301033', 20.00, 100, 1]
        )
        self.db.execute(
            "INSERT INTO `merchant_inventory` (tmk,mpk,price,quantity,active) VALUES(%s,%s,%s,%s,%s)",
            ['ABCDEF', '301032', 20.00, 100, 1]
        )
        self.db.execute(
            "INSERT INTO `merchant_inventory` (tmk,mpk,price,quantity,active) VALUES(%s,%s,%s,%s,%s)",
            ['FEDCBA', '301033', 20.00, 100, 1]
        )
        response = self.fetch('/ingestions/ABCDEF,FEDCBA')
        self.assertEqual(response.code, 200)
        body = json.loads(response.body.decode('utf-8'))
        self.assertEqual(len(body), 2)

    def test_post_ingestion(self):
        response = self.fetch('/merchant/FEDCBA/inventory', method='POST', body="ddfdf")
        self.assertEqual(response.code, 400) #this is just a sanity check to make sure the endpoint is hit correctly, it hsould fail though



if __name__ == '__main__':
    unittest.main()
