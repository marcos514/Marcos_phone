#!/usr/bin/env bash

DB_USER=root
DB_PASSWORD=root
DB_HOST=inventory_db
DB_NAME=inventory_db
MIGRATIONS_DIRECTORY=/src/migrations



cd /
./wait-for-it.sh $DB_HOST:3306 -t 0
cd "$MIGRATIONS_DIRECTORY"
yoyo apply --database mysql+mysqldb://$DB_USER:$DB_PASSWORD@$DB_HOST/$DB_NAME
yoyo apply --database mysql+mysqldb://$DB_USER:$DB_PASSWORD@$DB_HOST/"$DB_NAME"_test
python /src/server.py