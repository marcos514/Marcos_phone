# This is the new Matchmaker v2.0.0


## Development Setup

1. Clone the repo:

    `git clone https://github.com/ThirstieAdmin/matchmaker.git`

2. Change to the directory you cloned the repo in:

    `cd matchmaker`

3. Build the containers:

    `docker-compose build`

4. Test the containers:

    `make test`

5. Launch the services:

    `docker-compose up`

6. Navigate to http://localhost:8885 in your web browser

## Authentication

For the mapping serivice, access is allowed through the following un/pw:

un: `ops`

pw: `i am very thirstie`


---

## Deployments

For production, from root directory, launch with:

`docker-compose -f docker-compose.yml -f docker-compose.prod.yml up`

more documentation to come.
