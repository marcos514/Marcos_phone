import os
from csv import DictWriter


import scrapy

from models import MerchantInventoryItem, MerchantInventoryItemFormatter


FILE_NAME = os.environ.get("OUTPUT_FILE", 'test.csv')
# FILE = open(FILE_NAME, "w", encoding='utf-8')
# writer = DictWriter(FILE, MerchantInventoryItem().keys())
# writer.writeheader()

class InventoryExtractor:

    override_key_map = {
        'Item No.': 'Sku',
        'District/ Appellation': 'Subregion',
        'Varietal(s)': 'Varietal'
    }

    def __getattr__(self, name):
        return self.Defaut


    def Vintage(self, selector):
        return selector.css('.prodlink::text').extract()[0]

    def Country(self, selector):
        return selector.css('.prodlink::text').extract()[0]

    def Region(self, selector):
        return selector.css('.prodlink ::text').extract()[0]

    def Producer(self, selector):
        return selector.css('.prodlink span::text').extract()[0]

    def Defaut(self, selector):
        return selector.css('.prodata_txt::text').extract()[0]

    def Name(self, selector):
        return selector.css('[itemprop^="name"] h1').css('::text').extract()[0]

    def Quantity(self, selector):
        qnt = selector.xpath("//script[contains(text(),'nomoreqty')]").extract()[0]
        return qnt.split("We currently only have ")[1].split(" ")[0]


    def Price(self, selector):
        try:
            price = selector.css('[property^="og:price:amount"]::attr(content)').extract()[0]
            return price
        except Exception:
            exit("PRICE NOT FOUND")
        return price

    def Document(self, response):

        item = MerchantInventoryItem()

        item['Name'] = self.Name(response)
        item['Quantity'] = self.Quantity(response)
        item['Price'] = self.Price(response)
        item['URL'] = response.meta['url']
        item['Type'] = response.meta['item_type']

        product_data = response.css('#prodata tr')

        for prod in product_data:
            try:
                category = prod.css('.prodata_cat::text').extract()[0].strip()
            except IndexError as e:
                print(e)
                continue
                pass  # we will get an extra row every time, safe to ignor
            except Exception as e:
                print(e)
                continue


            try:
                item[category] = getattr(self, category)(prod)
            except KeyError:
                print('Missing category ' + category)
            except AttributeError as e:
                print('Attribute not supported')
                print(e)
            except Exception as e:
                print('Exception parsing ' + category)
                print(e)

        return item


class Knightsbridge(scrapy.Spider):

    name = "Knightsbridge"

    base_url = "https://www.knightsbridgewine.com"

    custom_settings = {
        'DOWNLOAD_DELAY': .25,
        'CLOSESPIDER_ERRORCOUNT': 5,
        'LOG_LEVEL': 'WARNING'
    }

    def start_requests(self):
        for i in range(1, 17):  # 17
            url = f'{self.base_url}/wines/?page={i}&sortby=sort_item_order&l=100&item_type=wine'
            yield scrapy.Request(url=url, callback=self.parse_list_page, meta={'item_type': 'wine'})


        for i in range(1, 2):#3
            url = f'{self.base_url}/spirits/?page={i}&sortby=sort_item_order&l=100&item_type=spirits'
            yield scrapy.Request(url=url, callback=self.parse_list_page, meta={'item_type': 'spirit'})

    def parse_list_page(self, response):
        products = response.css('.search_wrap')
        for product in products:
            url = product.css('.drtitle a').xpath('@href').extract()[0]
            url = f'{self.base_url}{url}'
            #item_size = product.css('.product-unit::text').extract()[0]
            yield scrapy.Request(url=url, callback=self.parse_item, meta={'url': url, 'item_type': response.meta['item_type'] })



    def parse_item(self, response):

        item = InventoryExtractor().Document(response)
        writer.writerow(item)


if __name__ == '__main__':

    from scrapy.crawler import CrawlerProcess

    process = CrawlerProcess({
        'USER_AGENT': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)'
    })

    print('Begin scraping of Knightsbridge....')

    with open(FILE_NAME, 'w', encoding='utf-8') as file:
        writer = DictWriter(file, fieldnames=MerchantInventoryItem().keys())
        writer.writeheader()

        process.crawl(Knightsbridge)
        process.start()
    #FILE.close()
