#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import atexit
import os
import re
import codecs

from csv import DictWriter, reader
from pathlib import Path
from urllib import request


from models import *

NAME_OF_PAGE = "flickinger"
CSV_FILENAME = '/out/MPAMM9_RAW.csv'

output_csv_file = Path(CSV_FILENAME).open(mode='w')
CSV_DICTWRITER = DictWriter(output_csv_file, MerchantInventoryItem().keys())
CSV_DICTWRITER.writeheader()
atexit.register(output_csv_file.close)  # Force auto-close the file at exit.


def main():
    usock = request.urlopen('https://www.flickingerwines.com/admin/create-thirstie-datafeed.aspx')
    
    cr = reader(codecs.iterdecode(usock, 'utf-8'), delimiter='\t')

    itercr = iter(cr)
    next(itercr)
    for row in itercr:
        price = re.sub('[$]', '', row[5])

        merchant_inventory_data = MerchantInventoryItem()
        merchant_inventory_data['Sku'] = row[0]
        merchant_inventory_data['Quantity'] = row[1]
        merchant_inventory_data['Name'] = row[2]
        merchant_inventory_data['Vintage'] = row[3]
        merchant_inventory_data['Size'] = row[4]
        merchant_inventory_data['Price'] = price
        
        CSV_DICTWRITER.writerow(merchant_inventory_data)
        
    return

if __name__ in '__main__':
    main()
