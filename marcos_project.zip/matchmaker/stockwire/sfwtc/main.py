from collections import OrderedDict
from csv import DictWriter
import shutil, os

import scrapy

from models import MerchantInventoryItem, MerchantInventoryItemFormatter



FILE_NAME = '/out/MER4P3_RAW.csv'

FILE = open('/tmp/tmp.csv', "w", encoding='utf-8')
writer = DictWriter(FILE, MerchantInventoryItem().keys())
writer.writeheader()


class SFWT(scrapy.Spider):

    name = "sfwt"

    base_url = "https://www.sfwtc.com"

    custom_settings = {
        'DOWNLOAD_DELAY': .25,
        'LOG_LEVEL': 'WARNING'
    }

    def start_requests(self):

        for i in range(1, 8): #8
            url = f'https://www.sfwtc.com/spirits/?page={i}&sortby=winery&l=100'
            yield scrapy.Request(url=url, callback=self.parse_list_page, meta={'item_type': 'spirit'})

        for i in range(1,13):
            url = f'https://www.sfwtc.com/wines/?page={i}&sortby=winery&l=100&item_type=wine'
            yield scrapy.Request(url=url, callback=self.parse_list_page, meta={'item_type': 'wine'})

    def parse_list_page(self, response):
        urls = response.css('.product-list .drtitle a.rtitle').xpath('@href').extract()
        for url in urls:
            url = f"{self.base_url}{url}"
            yield scrapy.Request(url=url, callback=self.parse_item, meta={'url': url})


    def parse_item(self, response):

        data = MerchantInventoryItem()

        data['Name'] = response.css('.prod_detail .detail_sec h1.colr').css('::text').extract()[0]

        product_data = response.css('#prodata tr')

        data['Price'] = response.css('span[itemprop="price"]').css('::text').extract()[0]
        data['URL']      = response.meta['url']


        category_parsers = {
            'Producer': lambda selector: selector.css('.prodata_txt span::text').extract()[0],
            'Country': lambda selector: selector.css('.prodata_txt::text').extract()[0],
            'Region': lambda selector: selector.css('.prodata_txt::text').extract()[0],
            'Subregion': lambda selector: selector.css('.prodata_txt::text').extract()[0],
            'Varietal': lambda selector: selector.css('.prodata_txt::text').extract()[0],
            'Vintage': lambda selector: selector.css('.prodata_txt a::text').extract()[0],
            'Sku': lambda selector: selector.css('.prodata_txt::text').extract()[0],
            'Size': lambda selector: selector.css('.prodata_txt::text').extract()[0],
            'Style': lambda selector: selector.css('.prodata_txt::text').extract()[0],
            'ABV': lambda selector: selector.css('.prodata_txt::text').extract()[0]
        }

        for prod in product_data:
            try:
                category = prod.css('.prodata_cat::text').extract()[0].strip()
            except IndexError:
                continue
                pass #we will get an extra row every time, safe to ignor
            except Exception as e:
                print(e)
                continue
            try:
                data[category] = category_parsers[category](prod).strip()
            except KeyError:
                print('Missing category ' + category)
            except Exception as e:
                print('Exception parsing ' + category)
                print(e)


        data['Quantity'] = response.css('#qtyinstock::text').extract()[0].strip()

        formatter = MerchantInventoryItemFormatter()
        for key in data.keys():
            if data[key] is not None:
                data[key] = getattr(formatter, key)(data[key])

        writer.writerow(data)


if __name__ == '__main__':

    from scrapy.crawler import CrawlerProcess

    print('Begin scraping of SFWTC....')


    process = CrawlerProcess({
        'USER_AGENT': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)'
    })


    process.crawl(SFWT)
    process.start()
    FILE.close()

    shutil.move('/tmp/tmp.csv', FILE_NAME)


