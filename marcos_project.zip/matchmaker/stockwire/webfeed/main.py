import requests
import os


FEED_URL = os.environ.get('FEED_URL', False)

if not FEED_URL:
    raise Exception('MUST SPECIFY FEED URL')


OUTPUT_FILENAME = os.environ.get('OUTPUT_FILENAME', False)

if not OUTPUT_FILENAME:
    raise Exception('MUST SPECIFY FILENAME')


write_file_to = '/out/' + OUTPUT_FILENAME

response = requests.get(FEED_URL, stream=True)
response.raise_for_status()  # Throw an error for bad status codes

with open(write_file_to, 'wb') as handle:
    for block in response.iter_content(1024):
        handle.write(block)
