import csv
import os

from distutils.util import strtobool
import gspread
from oauth2client.service_account import ServiceAccountCredentials

SCOPES = ['https://spreadsheets.google.com/feeds']
IGNORE_FIRST_ROW = bool(strtobool(os.environ.get('IGNORE_FIRST_ROW', 'False')))

GOOGLE_SHEET_ID = os.environ.get('GOOGLE_SHEET_ID', False)
if not GOOGLE_SHEET_ID:
    raise Exception('MUST SPECIFY GOOGLE_SHEET_ID')

OUTPUT_FILENAME = os.environ.get('OUTPUT_FILENAME', False)
if not OUTPUT_FILENAME:
    raise Exception('MUST SPECIFY OUTPUT_FILENAME')

# spreadsheet must be shared with our client email: stockwire@matchmaker-229616.iam.gserviceaccount.com
creds = ServiceAccountCredentials.from_json_keyfile_name('/src/credentials.json', SCOPES)
client = gspread.authorize(creds)

# take first sheet
sheet = client.open_by_key(GOOGLE_SHEET_ID).sheet1
values = sheet.get_all_values()

if IGNORE_FIRST_ROW:
    del values[0]

output_location = '/out/' + OUTPUT_FILENAME

# write output file with sheet content
with open(output_location, 'w') as output:
    writer = csv.writer(output)
    for row in values:
        writer.writerow(row)
