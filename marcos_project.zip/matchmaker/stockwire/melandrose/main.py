import re
import csv
import requests
from bs4 import BeautifulSoup
from models import MerchantInventoryItem, MerchantInventoryItemFormatter


api_base_url = 'http://www.melandrose.com'
pagination_querystr = '&sortby=&numperpage=999&pos=0'

OUTPUT_FILENAME = '/out/MAKEC7_RAW.csv'


category_urls = [
    # Beer
    ('Domestic Beer', '/istar.asp?a=3&dept=2&class=2'),
    ('Imported Beer', '/istar.asp?a=3&dept=2&class=3'),

    # Champagne and Sparkling
    ('Champagne', '/istar.asp?a=3&dept=3&class=1'),
    ('Sparkling Wine', '/istar.asp?a=3&dept=3&class=3'),

    # Sake, Soju, Plum Wine
    ('Plum Wine', '/istar.asp?a=3&dept=30&class=3'),
    ('Sake', '/istar.asp?a=3&dept=30&class=1'),
    ('Soju', '/istar.asp?a=3&dept=30&class=2'),

    # Absinthe
    ('Absinthe', '/istar.asp?a=3&dept=10&class=13'),

    # Apertif
    ('Apertif', '/istar.asp?a=3&dept=10&class=1'),

    #Armagnac
    ('Armagnac', '/istar.asp?a=3&dept=10&class=2'),

    # Brandy
    ('Brandy', '/istar.asp?a=3&dept=10&class=4'),

    # Cognac
    ('VS Cognac', '/istar.asp?a=3&dept=10&class=6&subclass=15'),
    ('VSOP Cognac', '/istar.asp?a=3&dept=10&class=6&subclass=16'),
    ('XO Cognac', '/istar.asp?a=3&dept=10&class=6&subclass=17'),
    ('Cognac', '/istar.asp?a=3&dept=10&class=6'),

    # Gin
    ('Gin', '/istar.asp?a=3&dept=10&class=7'),

    # Grappa
    ('Grappa', '/istar.asp?a=3&dept=10&class=8'),

    # Liqueurs and Cordials
    ('Anise Liqueur', '/istar.asp?a=3&dept=10&class=12&subclass=8'),
    ('Chocolate Liqueur', '/istar.asp?a=3&dept=10&class=12&subclass=12'),
    ('Coffee Liqueur', '/istar.asp?a=3&dept=10&class=12&subclass=5'),
    ('Cream Liqueur', '/istar.asp?a=3&dept=10&class=12&subclass=13'),
    ('Fruit Liqueur', '/istar.asp?a=3&dept=10&class=12&subclass=6'),
    ('Herbal Liqueur', '/istar.asp?a=3&dept=10&class=12&subclass=9'),
    ('Honey Liqueur', '/istar.asp?a=3&dept=10&class=12&subclass=39'),
    ('Nut Flavored Liqueur', '/istar.asp?a=3&dept=10&class=12&subclass=7'),
    ('Schnapps', '/istar.asp?a=3&dept=10&class=12&subclass=11'),
    ('Liqueurs and Cordials', '/istar.asp?a=3&dept=10&class=12'),

    # Whiskey, Scotch, Bourbon
    ('Canadian Whiskey', '/istar.asp?a=3&dept=10&class=26&subclass=2'),
    ('Corn Whiskey', '/istar.asp?a=3&dept=10&class=26&subclass=7'),
    ('Irish Whiskey', '/istar.asp?a=3&dept=10&class=26&subclass=1'),
    ('Japanese Whiskey', '/istar.asp?a=3&dept=10&class=26&subclass=6'),
    ('Rye Whiskey', '/istar.asp?a=3&dept=10&class=26&subclass=4'),
    ('Tennessee Whiskey', '/istar.asp?a=3&dept=10&class=26&subclass=3'),
    ('Wheat Whiskey', '/istar.asp?a=3&dept=10&class=26&subclass=5'),
    ('White Whiskey', '/istar.asp?a=3&dept=10&class=26&subclass=21'),
    ('Bourbon', '/istar.asp?a=3&dept=10&class=3'),
    ('Scotch', '/istar.asp?a=3&dept=10&class=19'),
    ('Single Malt', '/istar.asp?a=3&dept=10&class=22'),

    # Tequila and Mezcal
    ('Aged Tequila', '/istar.asp?a=3&dept=10&class=23&subclass=1'),
    ('Anejo Tequila', '/istar.asp?a=3&dept=10&class=23&subclass=5'),
    ('Extra Anejo Tequila', '/istar.asp?a=3&dept=10&class=23&subclass=15'),
    ('Mezcal', '/istar.asp?a=3&dept=10&class=20'),
    ('Platinum Tequila', '/istar.asp?a=3&dept=10&class=23&subclass=11'),
    ('Resposado Tequila', '/istar.asp?a=3&dept=10&class=23&subclass=13'),
    ('Silver Tequila', '/istar.asp?a=3&dept=10&class=23&subclass=14'),
    ('Special Tequila', '/istar.asp?a=3&dept=10&class=23&subclass=3'),

    # Rum
    ('Aged Rum', '/istar.asp?a=3&dept=10&class=17&subclass=3'),
    ('Cachaca', '/istar.asp?a=3&dept=10&class=17&subclass=5'),
    ('Dark Rum', '/istar.asp?a=3&dept=10&class=17&subclass=2'),
    ('Flavored Rum', '/istar.asp?a=3&dept=10&class=17&subclass=4'),
    ('Light Rum', '/istar.asp?a=3&dept=10&class=17&subclass=1'),
    ('Spiced Rum', '/istar.asp?a=3&dept=10&class=17&subclass=6'),
    ('Rum', '/istar.asp?a=3&dept=10&class=17'),

    # Vermouth
    ('Vermouth', '/istar.asp?a=3&dept=10&class=24'),
    # Vodka
    ('Flavored Vodka', '/istar.asp?a=3&dept=10&class=25&subclass=1'),
    ('Vodka', '/istar.asp?a=3&dept=10&class=25&subclass=2'),

    # Wines
    ('Argentinian Wine', '/istar.asp?a=3&dept=14&class=174'),
    ('Australian Wine', '/istar.asp?a=3&dept=14&class=59'),
    ('Austrian Wine', '/istar.asp?a=3&dept=14&class=169'),
    ('Canadian Wine', '/istar.asp?a=3&dept=14&class=51'),
    ('Chilean Wine', '/istar.asp?a=3&dept=14&class=173'),
    ('Domestic Wine', '/istar.asp?a=3&dept=14&class=168'),
    ('French Wine', '/istar.asp?a=3&dept=14&class=1'),
    ('German Wine', '/istar.asp?a=3&dept=14&class=172'),
    ('Greek Wine', '/istar.asp?a=3&dept=14&class=75'),
    ('Italian Wine', '/istar.asp?a=3&dept=14&class=5'),
    ('Kosher Wine', '/istar.asp?a=3&dept=14&class=7'),
    # ('Madeira', '/istar.asp?a=3&dept=14&class=102'),
    ('New Zealand Wine', '/istar.asp?a=3&dept=14&class=171'),
    ('Other Wine', '/istar.asp?a=3&dept=14&class=170'),
    ('Port', '/istar.asp?a=3&dept=14&class=104'),
    ('Sherry', '/istar.asp?a=3&dept=14&class=4'),
    ('South African Wine', '/istar.asp?a=3&dept=14&class=3'),
    ('Spanish Wine', '/istar.asp?a=3&dept=14&class=26'),

    # Missing from this taxonomy:
    # Limited Edition
    # Luxury Collection
    # Old & Rare Wines
]


headers = MerchantInventoryItem().keys()
rows = []

processed_products = set()

with open(OUTPUT_FILENAME, 'w', newline='') as csvfile:
    prod_writer = csv.writer(csvfile, delimiter='|')
    prod_writer.writerow(headers)
    categories_len = len(category_urls)

    for idx, category_url in enumerate(sorted(category_urls)):
        category, url = category_url
        print(f'{idx + 1}/{categories_len} Fetching {category}...')
        page = requests.get(f'{api_base_url}{url}{pagination_querystr}')
        doc = BeautifulSoup(page.text, 'html.parser')
        product_links = set()

        for a in doc.find_all('a', href=re.compile(r'^/istar.asp\?a=\d+&id=\d+$')):
            if a['href'] not in processed_products:
                processed_products.add(a['href'])
                product_links.add(a['href'])

        for link in product_links:
            # print(f'Fetching {link}...')
            product_detail_url = f'{api_base_url}{link}'
            product_page = requests.get(product_detail_url)
            product_doc = BeautifulSoup(product_page.text, 'html.parser')

            # *****************************************************************
            # The code from here to the next starred comment line is an attempt
            # to extract product size from the description text in the page
            # source. If this is creating problems with the raw inventories,
            # replace the code with the following line:
            # p_descr_heading, p_descr, p_descr_size = '', '', ''
            if len(product_doc.select('div.extendedDescription')) > 0:
                descr = product_doc.select('div.extendedDescription')[0].find_all(string=True)
                descr_strings = list(filter(lambda s: len(s), (x.string.strip('\r\n\t') for x in descr)))
                if len(descr_strings) >= 3:
                    p_descr_heading = descr_strings[0]
                    p_descr = '\n'.join(descr_strings[1:-1])
                    p_descr_size = descr_strings[-1]
                else:
                    p_descr_heading, p_descr, p_descr_size = '', '\n'.join(descr_strings), ''
            else:
                p_descr_heading, p_descr, p_descr_size = '', '', ''
            # *****************************************************************

            # product_doc.find_all('script', string=re.compile('product = new Product'))
            for script in filter(lambda x: x.string, product_doc.find_all('script')):
                if 'product = new Product' in script.string:
                    script_src = script.string
                    p_id_name_match = re.search(r"new Product\('(\d+)', '(.*)'\);", script_src)
                    p_price_match = re.search(r"product\.price = '\$(\d+\.\d+)'", script_src)
                    p_qty_match = re.search(r"product\.inStockQuantity = '(\d+)'", script_src)

                    if p_id_name_match and p_price_match and p_qty_match:
                        prod_groups = p_id_name_match.groups()
                        row = MerchantInventoryItem()

                        row['Sku']   = prod_groups[0]
                        row['Name']  = prod_groups[1]
                        row['Size']  = p_descr_size
                        row['Type']  = category
                        row['Price'] = p_price_match.groups()[0]
                        row['Quantity'] = p_qty_match.groups()[0]
                        row['URL'] = product_detail_url

                        #not taking heading or description for now
                        #  p_descr_heading,
                        #  p_descr

                        row = MerchantInventoryItemFormatter.format(row)
                        prod_writer.writerow(row.values())
                    else:
                        print('No match for ', p_id_name_match, p_price_match, p_qty_match )

        csvfile.flush()
