import re
from collections import OrderedDict

class MerchantInventoryItem(OrderedDict):
    """
    The MerchantInventoryItem contains all necessary keys for producing a merchant inventory csv file. It will
    also prevent the addition of unsupported keys.
    """
    
    _keys = [
        'Name',
        'Type',
        'Producer',
        'Country',
        'Region',
        'Subregion',
        'Varietal',
        'Vintage',
        'Sku',
        'Size',
        'Quantity',
        'Style',
        'ABV',
        'Price',
        'Designation',
        'Color',
        'Vineyard',
        'URL',
    ]
        
    def __init__(self):
        super(MerchantInventoryItem, self).__init__()
        for i in self._keys:
            self[i] = None
        self['Quantity'] = '0'


    def __setitem__(self, key, value):
        if key not in self._keys:
            raise Exception('Attempting to set a field that does not exist on MerchantInventoryItem')
        super(MerchantInventoryItem, self).__setitem__(key, value)

class MerchantInventoryItemFormatter:

    def __getattr__(self, item):
        return self.Default

    @staticmethod
    def format(item):
        """The MerchantInventoryItemFormatter is a convenient way of formatting MerchantInventoryItems."""
        formatter = MerchantInventoryItemFormatter()
        for key in item.keys():
            if item[key] is not None:
                item[key] = getattr(formatter, key)(item[key])
        return item


    def Default(self, string):
        return string.strip().replace('\r\n', '').replace('\n', '').replace('\t', '')


    def Price(self, price):
        p = price.replace("$", "").replace(",","")
        return self.Default(p)

    def Quantity(self, q):
        q = str(q)
        q = re.sub(r"\D","",q)
        if not q:
            q = '0'
        return self.Default(q)



