import os
from csv import DictWriter
from io import open

from models import MerchantInventoryItem, MerchantInventoryItemFormatter

#####################################################
#  SAMPLE CODE
#####################################################

OUTPUT_DIR = os.path.dirname(os.path.realpath(__file__)) + "/output"
OUTPUT_FILE_NAME = 'MerchantInventory.csv'

items = []
item = MerchantInventoryItem()
item['Name'] = 'Jose Quervo'
item['Quantity'] = '25'
item['Price'] = '$50'
item['Size'] = '750 ml'
item['Sku'] = 'A125'
MerchantInventoryItemFormatter.format(item)
items.append(item)

item = MerchantInventoryItem()
item['Name'] = 'Jack Daniels'
item['Quantity'] = '13'
item['Price'] = '$25'
item['Size'] = '750 ml'
item['Sku'] = 'A130'
MerchantInventoryItemFormatter.format(item)
items.append(item)

with open(OUTPUT_DIR + '/' + OUTPUT_FILE_NAME, 'w', encoding='utf-8') as file:
    writer = DictWriter(file, fieldnames=MerchantInventoryItem().keys())
    writer.writeheader()
    writer.writerows(items)


