import re
from collections import OrderedDict


class MerchantInventoryItem(OrderedDict):
    def __init__(self):
        super(OrderedDict, self).__init__()
        self['Name'] = None
        self['Type'] = None
        self['Producer'] = None
        self['Country'] = None
        self['Region'] = None
        self['Subregion'] = None
        self['Varietal'] = None
        self['Vintage'] = None
        self['Sku'] = None
        self['Size'] = None
        self['Quantity'] = '0'
        self['Style'] = None
        self['ABV'] = None
        self['Price'] = None
        self['Designation'] = None
        self['Color'] = None
        self['Vineyard'] = None
        self['URL'] = None


class MerchantInventoryItemFormatter:

    def __getattr__(self, item):
        return self.Default

    @staticmethod
    def format(item: MerchantInventoryItem):
        formatter = MerchantInventoryItemFormatter()
        for key in item.keys():
            if item[key] is not None:
                item[key] = getattr(formatter, key)(item[key])
        return item


    def Default(self, string):
        return string.strip().replace('\r\n', '').replace('\n', '').replace('\t', '')


    def Price(self, price):
        p = price.replace("$", "").replace(",","")
        return self.Default(p)

    def Quantity(self, q):
        q = re.sub(r"\D","",q)
        if not q:
            q = '0'
        return self.Default(q)



