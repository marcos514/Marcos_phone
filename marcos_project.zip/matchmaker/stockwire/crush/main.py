from collections import OrderedDict
from csv import DictWriter

import scrapy

from models import MerchantInventoryItem, MerchantInventoryItemFormatter


FILE_NAME = '/out/MW7VE3_RAW.csv'
FILE = open(FILE_NAME, "w", encoding='utf-8')
writer = DictWriter(FILE, MerchantInventoryItem().keys())
writer.writeheader()

class CrushInventoryExtractor:

    override_key_map = {
        'Item No.': 'Sku',
        'District/ Appellation': 'Subregion',
        'Varietal(s)': 'Varietal'
    }

    def __getattr__(self, name):
        return self.Defaut

    def Defaut(self, selector):
        return selector.css('.data').css('::text').extract()[0]

    def Name(self, selector):
        return selector.css('.product-name h1').css('::text').extract()[0]

    def Quantity(self, selector):
        return selector.css('.availability .value').css('::text').extract()[0]

    def Price(self, selector):
        try:
            price = selector.css('.regular-price .price').css('::text').extract()[0]
        except Exception:
            try:
                price = selector.css('.special-price .price').css('::text').extract()[0]
            except:
                print("PRICE NOT FOUND")
        return price

    def Document(self, response):

        item = MerchantInventoryItem()
        item['Name']     =  self.Name(response)
        item['Quantity'] =  self.Quantity(response)
        item['Price']    =  self.Price(response)
        item['Size']     = response.meta['item_size']
        item['URL']      = response.meta['url']

        for selector in response.css('.attribute-tab'):

            type = selector.css('.label').css('::text').extract()[0].strip()

            if type in self.override_key_map.keys():
                type = self.override_key_map[type]

            value = getattr(self, type)(selector)

            if type not in item.keys():
                print(f'KEY NOT FOUND {type}')
            else:
                item[type] = value

        formatter = MerchantInventoryItemFormatter()
        for key in item.keys():
            if item[key] is not None:
                item[key] = getattr(formatter, key)(item[key])

        return item


class Crush(scrapy.Spider):

    name = "crush"

    base_url = "https://www.crushwineco.com/"

    custom_settings = {
        'DOWNLOAD_DELAY': .25,
        'CLOSESPIDER_ERRORCOUNT': 1,
        'LOG_LEVEL': 'WARNING'
    }

    def start_requests(self):
        for i in range(1, 10):  # 10
             url = f'{self.base_url}wine-1.html?dir=asc&limit=200&order=crush_short_description&p={i}'
             yield scrapy.Request(url=url, callback=self.parse_list_page, meta={'item_type': 'wine'})

        for i in range(1, 3):#3
            url = f'{self.base_url}spirits-1.html?limit=200&p={i}'
            yield scrapy.Request(url=url, callback=self.parse_list_page, meta={'item_type': 'spirit'})

    def parse_list_page(self, response):
        products = response.css('.product-info-container')
        for product in products:
            url = product.css('h2.product-name a').xpath('@href').extract()[0]
            url = f"{url}"
            item_size = product.css('.product-unit::text').extract()[0]
            yield scrapy.Request(url=url, callback=self.parse_item, meta={'url': url, 'item_size': item_size})


    def parse_item(self, response):

        item = CrushInventoryExtractor().Document(response)
        writer.writerow(item)


if __name__ == '__main__':

    from scrapy.crawler import CrawlerProcess

    process = CrawlerProcess({
        'USER_AGENT': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)'
    })

    print('Begin scraping of Crush....')

    with open(FILE_NAME, 'w', encoding='utf-8') as file:
        writer = DictWriter(file, fieldnames=MerchantInventoryItem().keys())
        writer.writeheader()

    process.crawl(Crush)
    process.start()
    FILE.close()
