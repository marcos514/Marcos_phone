import time
from ftplib import FTP
import os
import logging

FTP_URL      = os.environ.get('FTP_URL', False)
FTP_USER     = os.environ.get('FTP_USER', False)
FTP_PASSWORD = os.environ.get('FTP_PASSWORD', False)

INPUT_DIR = os.environ.get('INPUT_DIR', False)
OUTPUT_DIR  = '/out'

OUTPUT_FILENAME =  os.environ.get('OUTPUT_FILENAME', False)

if not (FTP_URL and FTP_USER and FTP_PASSWORD and INPUT_DIR and OUTPUT_DIR and OUTPUT_FILENAME):
    raise Exception('Not fully configured, please check required environment variable')


FORMAT = '%(asctime)-15s %(name)s %(filename)s:%(lineno)d - %(levelname)s - %(message)s'
logging.basicConfig(format=FORMAT, level=logging.INFO)
l = logging.getLogger()

def is_valid_file(filename):
    # Exclude invalid references such as .. and .
    return filename not in ['..', '.']

def ftp_get_latest_file(ftp, path):
    ftp.cwd(path)
    data = []
    file_dict = {}
    ftp.dir(data.append)
    for line in data:
        col_list = line.split()
        date_str = ' '.join(line.split()[5:8])
        filename = col_list[8]
        if is_valid_file(filename):
            file_dict[time.strptime(date_str, '%b %d %H:%M')] = filename
    date_list = list([key for key, value in file_dict.items()])
    return file_dict[max(date_list)]

def ftp_download(ftp, source_filename, destination_dir):
    retr_cmd = 'RETR {0}'.format(source_filename)
    name, ext = os.path.splitext(source_filename)
    destination_filepath = '{0}/{1}'.format(destination_dir,OUTPUT_FILENAME + ext)
    with open(destination_filepath, 'wb') as f:
        ftp.retrbinary(retr_cmd, f.write)


if __name__ == '__main__':

    l.info(f'searching for files over ftp in dir: {INPUT_DIR}')

    with FTP(FTP_URL) as ftp:  # connect to host, default port
        ftp.login(FTP_USER, FTP_PASSWORD)
        filename = ftp_get_latest_file(ftp, INPUT_DIR)
        l.info(f'found file: {filename} in dir: {INPUT_DIR} saving to : {OUTPUT_DIR}')
        ftp_download(ftp, filename, OUTPUT_DIR)

