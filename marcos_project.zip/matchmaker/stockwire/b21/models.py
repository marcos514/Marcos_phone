#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import re
from collections import OrderedDict, namedtuple
from datetime import datetime
from html.parser import HTMLParser


__all__ = ("MerchantInventoryItem", "MerchantInventoryItemFormatter",
           "HTML2AnchorList", "HTML2dict")


class MerchantInventoryItem(OrderedDict):
    _keys = (
        'Name',
        'Type',
        'Producer',
        'Country',
        'Region',
        'Subregion',
        'Varietal',
        'Vintage',
        'Sku',
        'Size',
        'Quantity',
        'Style',
        'ABV',
        'Price',
        'Designation',
        'Color',
        'Vineyard',
        'URL',
    )

    def __init__(self):
        super(MerchantInventoryItem, self).__init__()
        for i in self._keys:
            self[i] = None
        self['Quantity'] = '0'

    def __setitem__(self, key, value):
        if key not in self._keys:
            raise Exception('Attempting to set a field that does not exist.')
        super(MerchantInventoryItem, self).__setitem__(key, value)


class MerchantInventoryItemFormatter:

    def __getattr__(self, item):
        return self.Default

    @staticmethod
    def format(item):
        formatter = MerchantInventoryItemFormatter()
        for key in item.keys():
            if item[key] is not None:
                item[key] = getattr(formatter, key)(item[key])
        return item

    def Default(self, string):
        return string.strip().replace('\r\n', '').replace('\n', '').replace('\t', '')

    def Price(self, price):
        p = price.replace("$", "").replace(",", "").replace("(", "").replace(")", "")
        return self.Default(p)

    def Quantity(self, q):
        q = str(q)
        q = re.sub(r"\D","",q)
        if not q:
            q = '0'
        return self.Default(q)


##############################################################################


class HTML2AnchorList(HTMLParser):

    """Parse only Anchor Links,ignores the rest,returns list of namedtuples."""
    links, current, url_domain, __slots__ = [], None, "", ()
    reserved = ("class", "id", "for", "type", "min", "max", "dir")

    def handle_starttag(self, tag, attrs):
        if tag.lower() == 'a':
            self.current = {
                k.upper() if k in self.reserved else k.replace("-", "_"):
                self.url_domain + v.strip()
                if k == "href" and not v.startswith("http") and self.url_domain
                else v.strip()
                for k, v in attrs if k and v.strip()
            }
            line_number, column = self.getpos()
            self.current.update({"lineno": line_number, "column": column})
        else:
            self.current = None  # Not an Anchor Link.

    def handle_data(self, data):
        if self.current and data:
            self.current.update({"text": data.strip()})

    def handle_endtag(self, tag):
        if tag.lower() == 'a' and self.current:
            self.links.append(namedtuple("A", self.current.keys())(
                *self.current.values()))
            self.current = None

    def feed(self, *args, **kwargs):
        self.links = []
        super().feed(*args, **kwargs)
        return self.links

    def __iter__(self):
        return iter(self.links)


class HTML2dict(HTMLParser):

    """Parse all elements,use 1 blacklist,returns 1 dict of namedtuples."""
    elements, current, url_domain, __slots__ = {}, None, "", ()
    reserved = ("class", "id", "for", "type", "min", "max", "dir")
    backlist = (  # All HTML elements to Ignore to focus on data on the rest.
        "meta", "link", "script", "style", "noscript", "object", "embed",
        "canvas", "svg", "template", "dialog", "marquee", "blink", "br",
        "datalist", "keygen","optgroup", "acronym", "applet", "basefont",
         "dir", "figure", "kbd", "noframes", "video", "audio", "wbr", "xmp",
        "nobr", "figcaption")

    def handle_starttag(self, tag, attrs):
        tag = tag.lower().strip()
        if not tag in self.backlist:
            if not self.current or not self.current.get(tag):
                self.current = {tag: {}}
            lineno, colu = self.getpos()
            self.current[tag].update({"lineno": lineno, "column": colu})
            if tag == 'a':  # Appends url_domain.
                self.current[tag].update({
                    k.replace("-", "_").upper()
                    if k in self.reserved else k.replace("-", "_"):
                    self.url_domain + v.strip()
                    if k == "href" and not v.startswith(
                        "http") and self.url_domain
                    else v.strip()
                    for k, v in attrs if k and v.strip()
                })
            else:
                self.current[tag].update({
                    k.replace("-", "_").upper()
                    if k in self.reserved else k.replace("-", "_"):
                    v.strip() for k, v in attrs if k and v
                })
        else:
            self.current = None  # Not an Element we are interested in.

    def handle_data(self, data):
        if self.current and data:
            tag = tuple(self.current.keys())[0]  # Adds text contents.
            self.current[tag].update({"text": data.strip()})

    def handle_endtag(self, tag):
        tag = tag.lower().strip()
        if not tag in self.backlist and self.current is not None:
            if self.current.get(tag):
                if list(self.current[tag].keys()) != ['lineno', 'column']:
                    if not self.elements.get(tag):
                        self.elements[tag] = []
                    self.elements[tag].append(namedtuple(
                        tag.upper(), self.current[tag].keys())(
                        *self.current[tag].values()))
                    self.current = None

    def feed(self, *args, **kwargs):
        self.elements = {}
        super().feed(*args, **kwargs)
        return self.elements

    def __iter__(self):
        return iter(self.elements.items())
