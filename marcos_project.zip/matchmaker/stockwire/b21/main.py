#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import atexit
import os
import re

from csv import DictWriter
from datetime import datetime
from pathlib import Path
from urllib import request

import xml.etree.ElementTree as ET

from models import *

NAME_OF_PAGE = "b21"
#CSV_FILENAME = Path(__file__).parent / f'{NAME_OF_PAGE}.csv'
CSV_FILENAME = '/out/M1FQGB_RAW.csv'

output_csv_file = Path(CSV_FILENAME).open(mode='w')
CSV_DICTWRITER = DictWriter(output_csv_file, MerchantInventoryItem().keys())
CSV_DICTWRITER.writeheader()
atexit.register(output_csv_file.close)  # Force auto-close the file at exit.


def main():
    usock = request.urlopen('https://www.b-21.com/feed/thirstie.asp?guid=nrna9pjqjem8gjdmf6f8k3wqz3e9r237')
    xmldoc = ET.parse(usock)
    root = xmldoc.getroot()

    for child in root:
        price = child.find('price').text.replace(",", "") if child.find('price').text else ""
        
        merchant_inventory_data = MerchantInventoryItem()  # Set key:value pairs
        merchant_inventory_data['Name'] = child.find('product-name').text
        merchant_inventory_data['Country'] = child.find('country').text
        merchant_inventory_data['Sku'] = child.find('product-id').text
        merchant_inventory_data['Size'] = child.find('bottle-size').text
        merchant_inventory_data['URL'] = child.find('link').text
        merchant_inventory_data['Price'] = price
        merchant_inventory_data['Quantity'] = child.find('inventory-count').text
        merchant_inventory_data['Producer'] = child.find('producer').text
        merchant_inventory_data['Designation'] = child.find('appellation').text
        merchant_inventory_data['Varietal'] = child.find('varietal').text
        merchant_inventory_data['Vintage'] = child.find('vintage').text
        merchant_inventory_data['ABV'] = child.find('alcohol').text

        CSV_DICTWRITER.writerow(merchant_inventory_data)
    
    return

if __name__ in '__main__':
    main()
