#!/usr/bin/env bash

set -e

touch /var/log/cron.log

printenv > /etc/default/locale

echo "${SCHEDULE} /cron-wrapper.sh python /src/main.py  >>  /var/log/cron.log 2>&1" > /tmp/crontab
crontab /tmp/crontab

service cron start && echo "Started cron" && tail -f /var/log/cron.log
