#!/usr/bin/env sh

set -e

touch /var/log/cron.log
mkdir -p /mnt/exavault

cp /key/mm_key /key/mm_key_internal
chown -R root:root /key/mm_key_internal
chmod -R 400 /key/mm_key_internal


sshfs "$EXAVAULT_USER"@thirstie-inventory.exavault.com:/ /mnt/exavault -o IdentityFile=/key/mm_key_internal -o StrictHostKeyChecking=no -o reconnect,ServerAliveInterval=15,ServerAliveCountMax=3

crontab /cron-sync

/usr/sbin/crond && echo "Started cron" && tail -f /var/log/cron.log


