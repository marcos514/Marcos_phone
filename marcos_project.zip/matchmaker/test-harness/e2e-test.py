import base64
import json
import os
import random
import string
import unittest
import requests

'''
This is an end to end test that is designed to run locally. It calls the endpoints through the proxy and asserts proper functionality.
It assumes that the environment is up.

'''

PROXY_URL = os.environ.get('PROXY_URL', "http://localhost:8885")

USER = "ops"
PASSWORD = "i am very thirstie"

TOKEN = base64.b64encode(b'ops:i am very thirstie').decode('UTF-8')

TMK = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

TPK_1 = ''.join(random.choices(string.ascii_uppercase + string.digits, k=9))
TPK_2 = ''.join(random.choices(string.ascii_uppercase + string.digits, k=9))

MPK_1 = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
MPK_2 = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))

MASTER_PRODUCT_LIST = {
    'upload': (
        "upload.csv",
        f"""enabled,tpk\nTRUE,{TPK_1}\nTRUE,{TPK_2}"""
    )
}

N3_FILE = {
    'upload': (
        "upload.csv",
        f"""tmk,mpk,price,quantity,active,astore,avail_id,availqty,bclass,bdesc,beerstyle1,beerstyle2,beerstyle3,beerstyle4,bestprice,bm_categ,bm_catname,bm_lwbn,botpercase,botperpkg,bstyle,case_only,casecost,cat_name,classif,closure,color,cost,country,descript,dessert,dqty_1,dqty_2,estate,fortified,freetax,fullcase,grapes,inv_type,item_size,kosher,limit,lwbn,organic,packaging,packtype,price_1,price_2,price_3,price_4,price_5,price_d1,price_d2,prod_id,producer,proof,reg_text,region,size,sku,skus,sparkling,st_descr,st_vint,stocku,style,sub_reg,univ_cat,univ_prod,upc,vintage,wholelist,wine_desc,mbrand,mname,msku,mvintage,mupc,evergreen\n{TMK},{MPK_1},819.0000,1,A,1,,1,,d'Oliveira Madeira Malvasia,,,,,819.00,670,Madeira,W,12,1,,,0.00,Madeira,,,White,599.98,Portugal,d'Oliveira Malvasia Madeira 1907 750ML,,0,0,,Y,,,Madeira Blend,,750ML,,0,W,,,,0.0000,819.0000,0.0000,0.0000,0.0000,0.0000,0.0000,1985508,d'Oliveira,,681101,Terras Madeirenses,750,1000182,,,D'oliveira Malvasia Madeira 1907 750ml,1907,1,,Madeira - Madeirense,24032,94425,,1907,,,,,,,,0\n{TMK},{MPK_2},1200.0000,108,A,1,,108,38,Chateau Lafite Rothschild Pauillac,,,,,1200.00,595,French Still Wine,W,12,1,,,0.00,Red Bordeaux First Growt,First Growth,,Red,900.00,France,Lafite Rothschild Pauillac 1998 750ML *,,0,0,Pauillac,,,,Bordeaux,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,0"""
    )
}


MAPPING_FILE = {
    'upload': (
        "upload.csv",
        f"""enabled,tpk,mpk,tmk\nTRUE,{TPK_1},{MPK_1},{TMK}\nTRUE,{TPK_2},{MPK_2},{TMK}"""
    )
}

auth_header = {"Authorization": "Basic {}".format(TOKEN)}

class EndToEndTest(unittest.TestCase):

    def test_unauthorized_access(self):
        r = requests.get(PROXY_URL)
        self.assertEqual(r.status_code, 401, 'Unauthorized request should fail')

    def test_authorized_access(self):
        r = requests.get(PROXY_URL, headers=auth_header)
        self.assertEqual(r.status_code, 200, 'Authorized request should pass')

    def test_end_to_end(self):
        self.add_merchant()
        self.add_master_products()
        self.add_merchant_inventory()
        self.add_mappings()
        self.trigger_uploader_preview()

    def add_merchant(self):
        r = requests.post(f"{PROXY_URL}/m/merchant/{TMK}", headers=auth_header,
                          data=json.dumps({"tmk": TMK, "name": "A test merchant", "enabled": "True"}))
        self.assertEqual(200, r.status_code)

        r = requests.get(f"{PROXY_URL}/m/merchant/{TMK}", headers=auth_header)
        data = r.json()
        self.assertEqual(200, r.status_code)
        self.assertEqual(data['tmk'], TMK)
        self.assertEqual(data['enabled'], True)

    def add_master_products(self):
        r = requests.post(f"{PROXY_URL}/m/products", headers=auth_header, files=MASTER_PRODUCT_LIST)
        self.assertEqual(r.status_code, 200)

        r = requests.get(f"{PROXY_URL}/m/products", headers=auth_header)
        self.assertEqual(r.status_code, 200)

        matching = [product['tpk'] for product in r.json() if product['tpk'] == TPK_1 or product['tpk'] == TPK_2]
        self.assertEqual(len(matching), 2)
        self.assertEqual(len(set(matching)), 2)

    def add_merchant_inventory(self):
        r = requests.post(f"{PROXY_URL}/i/merchant/{TMK}/inventory", headers=auth_header, files=N3_FILE)
        self.assertEqual(r.status_code, 200)
        body = r.json()
        self.assertEqual(body['deactivated'], 0)
        self.assertEqual(body['inserted'], 2)
        self.assertEqual(body['unchanged'], 0)
        self.assertEqual(body['updated'], 0)


        r = requests.get(f"{PROXY_URL}/i/merchant/{TMK}/inventory", headers=auth_header)
        self.assertEqual(r.status_code, 200)
        body = r.json()
        self.assertEqual(len(body), 2)
        self.assertEqual(body[0]['mpk'], MPK_1)
        self.assertEqual(body[1]['mpk'], MPK_2)

    def add_mappings(self):
        r = requests.post(f"{PROXY_URL}/m/merchant/{TMK}/mappings", headers=auth_header, files=MAPPING_FILE)
        self.assertEqual(r.status_code, 200)

        r = requests.get(f"{PROXY_URL}/m/merchant/{TMK}/mappings", headers=auth_header)
        self.assertEqual(r.status_code, 200)

        body = r.json()
        self.assertEqual(len(body), 2)
        for row in body:
            if row['mpk'] == MPK_1:
                self.assertEqual(row['tpk'], TPK_1)
            elif row['mpk'] == MPK_2:
                self.assertEqual(row['tpk'], TPK_2)
            else:
                self.assertTrue(False, 'Incorrect mappings')

    def trigger_uploader_preview(self):
        r = requests.get(f"{PROXY_URL}/u/v2/trigger/{TMK}?preview=true", headers=auth_header)
        body = r.json()
        self.assertTrue(len(body), 2)
        self.assertTrue(next(b for b in body if b["tpk"] == TPK_1))
        self.assertTrue(next(b for b in body if b["tpk"] == TPK_2))

if __name__ == '__main__':
    unittest.main()
