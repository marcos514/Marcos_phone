from datetime import datetime, timedelta
from glob import glob
import logging

import csv
import os
import struct
import tarfile
import traceback

import click
from inventory_generators import (
    inventory_generator_factory, InvalidInventoryFileException, extra_columns_to_pull
)
from inventory_archivers import inventory_archiver_factory

from data import get_catalog_from_couch, update_couch_db_settings, upload_file_to_s3
from settings import ENVIRONMENT_NAME, MERCHANT_BACKUPS_DIR
import pprint as pp
from utils import get_logger, log_event_to_slack
from pandas.errors import EmptyDataError, ParserError

catalog = get_catalog_from_couch()


@click.group()
def cli():
    pass


@click.argument('tmk')
@cli.command(help='Run the normalized inventory generator for the given TMK')
@click.option('--mute', is_flag=True, default=False, help='If supplied, mutes logging to slack')
def generate(tmk, mute=False):

    l = get_logger(name='extractor-main', skip_slack=mute)
    l.info(f'Begin generating N file for tmk: {tmk}')

    try:
        generator = inventory_generator_factory(tmk, catalog=catalog)
        generator.generate()
        l.info(f'N file generated successfully for tmk: {tmk}')

    except KeyError as e:
        l.error(f'The tmk {tmk} does not exist in the configuration or it is misconfigured')
        l.error(e)
    except FileNotFoundError:
        l.info(f'There is no new inventory for {tmk} to transform')
    #except Exception as e:
    #    l.error(f'There was an error generating the n file for {tmk}')
    #    l.error(e)


@cli.command(help='Lists all the TMKs and their configurations')
@click.option('--tmk')
@click.option('--mute', is_flag=True, default=False, help='If supplied, mutes logging to slack')
def list(tmk=None, mute=False):
    try:
        if tmk:
            pp.pprint(catalog[tmk])
            return
        pp.pprint(catalog)
    except KeyError:
        get_logger(name='extractor-main', skip_slack=mute).error(f'The tmk {tmk} does not exist in the configuration')

@cli.command(help='Scan for new inventories in the folders')
@click.option('--tmk', help='If supplied only scans given merchant')
@click.option('--generate', is_flag=True, default=False, help='If supplied, runs the generate process for all files in inventory')
@click.option('--mute', is_flag=True, default=False, help='If supplied, mutes logging to slack')
def scan(tmk=None, generate=False, mute=False):

    l = get_logger(name='extractor-main', skip_slack=mute)

    l.info('Beginning to scan for new raw inventories')

    # applied to every merchant with a configuration
    def scan_merchant(merchant):
        try:
            extractor = inventory_archiver_factory(merchant["tmk"], catalog=catalog)
        except Exception as e:
            l.error('There was a problem getting the extractor for the given merchant config')
            l.error(type(e))
            l.error(e)
        try:
            if extractor.has_new_data():
                return True
        except FileNotFoundError:
            l.error(f'Merchant {merchant["tmk"]} is not set up correctly, check the ftp directory structure')
            return False
        except Exception as e:
            l.error(f'Error checking for new data for {merchant["tmk"]}')
            l.error(e)
            return False
        return False
    try:
        tmks = {tmk: catalog[tmk]} if tmk else catalog
    except KeyError:
        l.error(f'The tmk {tmk} does not exist in the configuration')
        exit(1)


    # get merchants with updated inventories
    tmks_with_new_files = [tmk for tmk, merchant in tmks.items() if scan_merchant(merchant)]

    if generate:
        if tmks_with_new_files:
            l.info(f'The following tmks have new inventory and will generate N files:  {",".join(tmks_with_new_files)}')
        else:
            l.info(f'No new inventories found')

        for tmk in tmks_with_new_files:
            merchant = catalog[tmk]

            if 'exclude_from_auto' in merchant.keys() and merchant['exclude_from_auto']:
                l.info(f'Excluding {tmk} based on exclude flag')
                continue

            generator = inventory_generator_factory(merchant["tmk"], catalog=catalog)

            try:
                generator.generate()
            except (InvalidInventoryFileException, EmptyDataError, ParserError, struct.error) as e:
                traceback_log = traceback.format_exc()
                generator.archive_invalid_raw(traceback_log)
                l.error(
                    "An error occurred for TMK {0} on generation process: {1}. "
                    "Please check Failures folder".format(
                        tmk, e
                    )
                )
            except Exception as e:
                l.error(
                    'There was a problem generating inventory for TMK {0}. Message: {1}'.format(
                        tmk, e
                    )
                )

        l.info('End generating inventories')

@cli.command(help='Create directories for merchants specified in data.py')
def create_dirs():
    for _,m in catalog.items():
        os.makedirs(m["input_file_dir"], exist_ok=True)
        os.makedirs(m["input_file_dir"] + "/Archive", exist_ok=True)
        os.makedirs(m["output_file_dir"], exist_ok=True)
        os.makedirs(m["output_file_dir"] + "/Archive", exist_ok=True)


@cli.command(help='Create directories for merchants specified in data.py')
@click.option('--csv-location', help='CSV file location. Mandatory ', required=True)
@click.option('--delimiter', help="CSV file delimiter, default is ','", default=',')
def couchdb_settings_mass_update(csv_location, delimiter):
    '''
     Couch DB settings mass update. The purpose of this tool is to make easier a mass update of merchant settings,
     in this case oriented to merchant's extra columns pulling defined in extra_columns_to_pull in
     extractor.inventory_generators.
     Expects a csv file location, should contain the next format (values of raw files column names):
     ---
     tmk,msku,mupc,mvintage,mbrand,mname
     MSSAAA,Sku,UPC,Vintage,Brand,Description
     ...
     ----
     Rows values are optional. Empty values won't be updated
    '''
    l = get_logger(name='couchdb_settings_mass_update', skip_slack=True, log_level=logging.INFO)
    with open(csv_location, 'r') as mappings:
        reader = csv.DictReader(mappings, delimiter=delimiter)
        for row in reader:
            tmk = row['tmk']
            l.info('Reading tmk {0}'.format(tmk))
            if tmk in catalog:
                settings = catalog[tmk]
                for _c, _s in extra_columns_to_pull:
                    if row.get(_c):
                        l.info('Mapping {0} <> {1} found, adding to merchant settings'.format(_c, row[_c]))
                        settings[_s] = row[_c]
                l.info('Sending new settings to couchdb, preview: {0}'.format(settings))
                response = update_couch_db_settings(tmk, settings)
                if response.status_code != 201:
                    l.info('TMK {0} settings update failed on couch! Message: {1}'.format(tmk, response.json()))
                    break


@cli.command(help="Remove merchant's input files older than [days] value")
@click.option('--days', default=5, help='Days back of files to remove, default is 5')
def clean_input_dirs(days):
    l = get_logger(name='clean_input_dirs', skip_slack=True, log_level=logging.INFO)
    l.info('Beginning clean input dirs process, days back {0}'.format(days))
    now = datetime.now()
    for _, m in catalog.items():
        if m['nig'] != 'mirror':
            l.info('Looking merchant {0} [{1}]'.format(m['merchant_name'], m['tmk']))
            input_dir = m["input_file_dir"]
            lookup_dir = f'{input_dir}/Archive/*'
            l.info('Looking dir {0}'.format(lookup_dir))
            for i in glob(lookup_dir, recursive=False):
                last_modified_date = datetime.fromtimestamp(os.path.getmtime(i))
                if (now - last_modified_date) > timedelta(days=days):
                    l.info('Removing file {0}, last modified date: {1}'.format(i, last_modified_date))
                    os.remove(i)

    # Slack notification
    log_event_to_slack('Clean input dirs finished succesfully. Days back: {0}. Started in {1}'.format(days, now))

@cli.command(help="Remove merchant's output files older than [days] value")
@click.option('--days', default=5, help='Days back of files to remove, default is 5')
def clean_output_dirs(days):
    l = get_logger(name='clean_output_dirs', skip_slack=True, log_level=logging.INFO)
    l.info('Beginning output dirs clean up process, days back {0}'.format(days))
    now = datetime.now()
    for _, m in catalog.items():
        if m['nig'] != 'mirror':
            l.info('Looking merchant {0} [{1}]'.format(m['merchant_name'], m['tmk']))
            output_dir = m["output_file_dir"]
            lookup_dir = f'{output_dir}/**/*.csv'
            l.info('Looking dir {0}'.format(lookup_dir))
            for i in glob(lookup_dir, recursive=True):
                last_modified_date = datetime.fromtimestamp(os.path.getmtime(i))
                if (now - last_modified_date) > timedelta(days=days):
                    l.info('Removing file {0}, last modified date: {1}'.format(i, last_modified_date))
                    os.remove(i)

    # Slack notification
    log_event_to_slack('Clean output dirs finished succesfully. Days back: {0}. Started in {1}'.format(days, now))


@cli.command(help="Backup merchant's inventory files older than [days] value")
@click.option('--days', default=5, help='Days back of files to backup, default is 5')
def backup_input_dirs(days):
    l = get_logger(name='backup_input_dirs', skip_slack=True, log_level=logging.INFO)
    l.info('Beginning backup input dirs process, days back {0}'.format(days))
    now = datetime.now()
    backup_name = 'backup-{0}-{1}.tar.gz'.format(
        ENVIRONMENT_NAME,
        now.strftime('%Y%m%d')
    )
    backup_destination = '/'.join([MERCHANT_BACKUPS_DIR, backup_name])
    try:
        with tarfile.open(backup_destination, "w") as backup:
            for _, m in catalog.items():
                if m['nig'] != 'mirror':
                    l.info('Looking merchant {0} [{1}]'.format(m['merchant_name'], m['tmk']))
                    input_dir = m["input_file_dir"]
                    lookup_dir = f'{input_dir}/Archive/*'
                    l.info('Looking dir {0}'.format(lookup_dir))
                    backed_up = []
                    for i in glob(lookup_dir, recursive=False):
                        last_modified_date = datetime.fromtimestamp(os.path.getmtime(i))
                        if (now - last_modified_date) > timedelta(days=days):
                            if os.path.getsize(i) > 0:
                                l.info('Backing up file {0}, last modified date: {1}'.format(i, last_modified_date))
                                backup.add(i)
                            backed_up.append(i)
        l.info('Backup finished - uploading backup to S3...')

        # Upload backup to S3
        upload_file_to_s3(backup_destination)

        # Clean backup up files
        l.info('Removing backed up files..')
        for b in backed_up:
            l.info('Removing {0}..'.format(b))
            os.remove(b)
        l.info('Finished! Sending slack notification')
        timespent = datetime.now() - now

        # Slack notification
        log_event_to_slack('Exavault backup finished succesfully. Days back: {days}. Started in {now}, time spent {timespent}')
    except Exception as e:
        timespent = datetime.now() - now
        message = f'An error has ocurred during backup process! Started in {now}, days back {days}, time spent {timespent}. Exception: {e}'
        l.exception(message)
        log_event_to_slack(message)
    finally:
        # Finally remove backup file from the local system
        l.info('Removing backed up files..')
        os.remove(backup_destination)

if __name__ == '__main__':
    cli()
