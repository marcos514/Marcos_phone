'''
Flask server that pushes N4 files to inventory service
'''

import re
import os
import sys
import functools
from distutils.util import strtobool

from flask import Flask, request, jsonify, Response, abort, make_response

from data import get_catalog_from_couch
from inventory_generators import DirectInventoryGenerator
from inventory_archivers import DirectArchiver

app = Flask(__name__)

# constants
INVENTORY_API = os.environ.get('INVENTORY_API', 'http://localhost/i')
FLASK_PORT   = int(os.environ.get('FLASK_PORT', 5000))
FLASK_DEBUG  = bool(strtobool(os.environ.get('FLASK_DEBUG', 'False')))

# JSON Response and CORS handling
def json_writer(f):
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        response = jsonify(f(*args, **kwargs))
        response.headers['Access-Control-Allow-Origin'] = '*'
        return response
    return wrapper

# take in raw inventory and send N4 file to inventory service
@app.route('/merchant/<tmk>', methods=['POST'])
@json_writer
def post_normalized_inventory(tmk):
    # get merchant config
    catalog = get_catalog_from_couch()
    config = catalog.get(tmk, None)
    if not config:
        abort(make_response(jsonify(message=f'No extractor configuration for merchant "{tmk}"'), 404))

    # get file from request
    raw_file = request.files.get('upload', None)
    if not raw_file:
        abort(make_response(jsonify(message='Please supply a file to import'), 400))

    # initialize generator
    raw_file.save(f'/tmp/{raw_file.filename}')
    archiver = DirectArchiver(config, f'/tmp/{raw_file.filename}')
    nig = DirectInventoryGenerator(archiver, **config)

    # make sure there are proper column names for bevsites
    if config['nig'] == 'bevsites':
        nig.mpk_column_names = ['sku', 'size', 'item_size', 'botpercase']
        nig.price_column_name = ['price_1', 'price_2']
        nig.quantity_column_name = 'stocku'

    # make sure the file extension matches
    extension = nig.input_file_extension
    if not re.search(r"\{0}$".format(extension), raw_file.filename, re.IGNORECASE):
        message = f'Merchant "{tmk}" requires a file with extension "{extension}"'
        abort(make_response(jsonify(message=message), 400))

    # generate csv and archive to exavault
    nig.generate()

    return {'message': 'inventory uploaded'}

@app.route('/merchant/<tmks>')
@json_writer
def get_merchants_couch_settings(tmks):
    # get merchant config
    merchants = tmks.split(',')
    query_fields = request.args.get('fields', None)
    fields = query_fields.split(',') if query_fields else None
    catalog = get_catalog_from_couch()
    merchants_config = {}
    if fields:
        for tmk in merchants:
            merchants_config[tmk] = {field: values.get(field, None) for (
                tmk_conf, values) in catalog.items() for field in fields if tmk == tmk_conf}
    else:
        merchants_config = {tmk: values for (
            tmk, values) in catalog.items() if tmk in merchants}

    return merchants_config


if __name__ == '__main__':
    print('''

███████╗██╗  ██╗████████╗██████╗  █████╗  ██████╗████████╗ ██████╗ ██████╗
██╔════╝╚██╗██╔╝╚══██╔══╝██╔══██╗██╔══██╗██╔════╝╚══██╔══╝██╔═══██╗██╔══██╗
█████╗   ╚███╔╝    ██║   ██████╔╝███████║██║        ██║   ██║   ██║██████╔╝
██╔══╝   ██╔██╗    ██║   ██╔══██╗██╔══██║██║        ██║   ██║   ██║██╔══██╗
███████╗██╔╝ ██╗   ██║   ██║  ██║██║  ██║╚██████╗   ██║   ╚██████╔╝██║  ██║
╚══════╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝

    ''', file=sys.stderr)
    app.run(port=FLASK_PORT, host='0.0.0.0', debug=FLASK_DEBUG)
