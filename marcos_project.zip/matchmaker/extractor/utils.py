import datetime
import hashlib
import json
import logging
import os
import shutil
import time
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor


import pandas as pd
import requests
import settings


class RowValidator():
    def __init__(self, _types):
        self._types = _types

    def validate(self, value):
        is_valid = True
        try:
            for _type in self._types:
                value = _type(value)
        except ValueError:
            is_valid = False
        return is_valid


class LogErrorsToSlackHandler(logging.Handler):

    def emit(self, record):
        try:
            log_event_to_slack(str(record.msg), record.levelname)
        except Exception as e:
            get_logger(skip_slack=True).error("There was an exception logging to slack")
            print(e)

def get_logger(name="", skip_slack=False, log_level=logging.ERROR):
    FORMAT = '%(asctime)-15s %(name)s %(filename)s:%(lineno)d - %(levelname)s - %(message)s'
    logging.basicConfig(format=FORMAT, level=log_level)
    logger = logging.getLogger(name)

    if not skip_slack and settings.LOG_TO_SLACK and not logger.handlers:
        logger.addHandler(LogErrorsToSlackHandler())

    logger.setLevel(log_level)

    return logger

def df_to_excel(output_file_location, df):
    writer = pd.ExcelWriter(output_file_location)
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()

def to_excel(output_file_location, objects):
    df = pd.DataFrame(objects)
    df_to_excel(output_file_location, df)

def save_as_json(output_file_location, data):
    with open(output_file_location, 'w') as outfile:
        json.dump(data, outfile, indent=4, sort_keys=True)

def read_json(input_file_location):
    with open(input_file_location, 'r') as json_file:
        data = json.load(json_file)
        return data

def create_regex_values(text_value):
    if text_value.find('.') > -1:
        value_rep = str(float(text_value))
        return '({0:}|{0:}0)'.format(value_rep)
    else:
        try:
            value_rep = str(int(text_value))
            return '({0:}|{0:}.|{0:}.0)'.format(value_rep)
        except (ValueError, TypeError):
            return text_value


def generate_mpk(s, length=32):
    s = s.encode('utf-8')
    return hashlib.md5(s).hexdigest()[0:length].upper()

def get_files_with_extension(extract_home, filename_part=None, extensions=None):
    filepaths = []
    for filepath in os.listdir(extract_home):
        filename, file_extension  = os.path.splitext(filepath)
        if file_extension and file_extension in extensions and filename_part in filename:
            filepaths.append(filepath)
    return filepaths

def archive_extract(extract_home, archive_home, filename, add_ts=True, data=None):
    source_file = '{0}/{1}'.format(extract_home,filename)
    if add_ts:
        filename, file_extension = os.path.splitext(filename)
        ts = datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")
        destination_filename = '{0}-{1}{2}'.format(filename, ts, file_extension)
    else:
        destination_filename = filename
    destination_file = f'{archive_home}/{destination_filename}'
    if hasattr(data, 'read'):
        with open(destination_file, 'wb') as context:
            context.write(data.read())
            data.seek(0)
    elif isinstance(data, str):
        with open(destination_file, 'w') as context:
            context.write(data)
    else:
        shutil.move(source_file, destination_file)

def ftp_get_latest_file(ftp, path):
    ftp.cwd(path)
    data = []
    file_dict = {}
    ftp.dir(data.append)
    for line in data:
        col_list = line.split()
        date_str = ' '.join(line.split()[5:8])
        file_dict[time.strptime(date_str, '%b %d %H:%M')] = col_list[8]
        date_list = list([key for key, value in file_dict.items()])
    return file_dict[max(date_list)]

def ftp_download(ftp, source_filename, destination_dir):
    retr_cmd = 'RETR {0}'.format(source_filename)
    destination_filepath = '{0}/{1}'.format(destination_dir,source_filename)
    with open(destination_filepath, 'wb') as f:
        ftp.retrbinary(retr_cmd, f.write)

def convert_bevsites_xml_to_df(input_file_location):
    tree = ET.parse(input_file_location)
    root = tree.getroot()

    quotes = []

    for quote_record in root:
        # print quote_record.tag
        quote = {}
        for quote_attribute in quote_record:
            # print quote_attribute.tag, quote_attribute.attrib, quote_attribute.text
            quote[quote_attribute.tag] = quote_attribute.text
            # if quote_attribute.text != None:
                # attribut_counter[quote_attribute.tag] += 1
        quotes.append(quote)
    df = pd.DataFrame(quotes)
    return df

def convert_xml_to_df(input_file_location):
    tree = ET.parse(input_file_location)
    root = tree.getroot()

    quotes = []

    for quote_record in root:
        for quote_attribute in quote_record:
            quotes.append(get_xml_child(quote_attribute))

    df = pd.DataFrame(quotes)
    return df

def get_xml_child(father):
    quotes = {}
    for f in father:
        quote = {}
        if f.getchildren():
            quote = get_xml_child(f)
        else:
            quote[f.tag] = f.text
        quotes = dict(quotes, **quote)
    return quotes

def is_new_file(input_file_path: str, checksum_file_path: str):
    '''
    Returns true if 1) checksum doesn't exist 2)checksum and input file exist but don't match
    Returns false if 1) input file doesn't exist 2) check sum of file matches the existing check sum
    :param input_file_path: str
    :param checksum_file_path: str
    :return: void
    '''
    try:
        with open(input_file_path, 'rb') as i:
            try:
                with open(checksum_file_path, 'r') as f:
                    last_processed = f.read()
                    current = hashlib.md5(i.read()).hexdigest()
                    if last_processed == current:
                        return False
                    return True
            except FileNotFoundError:
                return True
    except FileNotFoundError:
        return False


def save_checksum(input_file_path: str, output_file_path: str):
    '''
    Saves a checksum of the given input file to the given output file
    :param input_file_path: str
    :param output_file_path: str
    :return: void
    '''
    with open(input_file_path, 'rb') as i:
        # If checksum file exists, we delete it to prevent errors
        if os.path.isfile(output_file_path):
            os.remove(output_file_path)
        with open(output_file_path, 'w') as c:
            c.write(hashlib.md5(i.read()).hexdigest())


def log_event_to_slack(message='', message_type='success', executor=ThreadPoolExecutor(max_workers=10)):
    # log an event to Slack
    color_map = {'success': '#26c13b', 'error': '#ba1414', 'warning': '#f7dc11'}


    json = { "attachments":[{
        'title': f'Extractor {settings.ENVIRONMENT_NAME.title()}',
        'color': color_map.get(message_type.lower(), '#91918e'),
        'text': message,
        'fallback': message
    }]}

    executor.submit(lambda: requests.post(settings.SLACK_URL, json=json))


def ensure_couchdb_db(name):
    requests.put(f'{settings.COUCH_URL}/{name}')

def get_couch_n_file_revision(tmk):
    ensure_couchdb_db('n_files')
    r = requests.get(f'{settings.COUCH_URL}/n_files/{tmk}?')

    if r.status_code == 200:
        revision = r.json()['_rev']
        return revision

def post_n_file_to_couch(tmk, _file):
    revision = get_couch_n_file_revision(tmk)
    headers = {
        'content-type': 'text/csv',
        'If-Match': revision
    }
    requests.put(f'{settings.COUCH_URL}/n_files/{tmk}/n_file_{tmk}.csv', data=_file, headers=headers)


def post_persisted_n_file_to_couch(tmk, link_to_file):
    with open(link_to_file, 'rb') as _file:
        post_n_file_to_couch(tmk, _file)
