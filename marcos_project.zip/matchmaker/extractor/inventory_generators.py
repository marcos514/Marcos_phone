import datetime
import os
import re
import requests
import sys
import utils
import zipfile

import numpy as np
import pandas as pd

from data import get_catalog_from_couch
from functools import singledispatch
import inventory_archivers as ia
import settings


class InvalidInventoryFileException(Exception):
    pass


validation_schema = {
    'price': [float],
    'quantity': [float, int]
}

extra_columns_to_pull = [
    ('mupc', 'upc_column_name'),
    ('mname', 'name_column_name'),
    ('mvintage', 'vintage_column_name'),
    ('mbrand', 'brand_column_name'),
    ('msku', 'sku_column_name')
]


@singledispatch
def get_price(col, df):
    pass


@get_price.register(str)
def _(col, df):
    return df[col]


@get_price.register(list)
def _(col, df):
    return df[col].max(axis=1)


class NormalizedInventoryGenerator(object):
    """docstring for NormalizedInventoryGeneratorBase"""

    def __init__(self, extractor: ia.MerchantInventoryArchiver, **kwargs):
        self.extractor = extractor
        self.logger = utils.get_logger('nig-l1-base')
        self.csvs_written = []
        for key, value in kwargs.items():
            setattr(self, key, value)

    def validate_df(self):
        """Validates df rows by parsing price and quantity columns, if an error
        is found filter those rows on main df and generates a new df
        (invalid_rows_df) with all invalid rows"""
        validation_arr = np.array([True for x in range(len(self.df.index))])
        for row, _types in validation_schema.items():
            row_validator = utils.RowValidator(_types)
            validation_arr = validation_arr & self.df[row].apply(row_validator.validate)
        self.invalid_rows_df = self.df[~validation_arr]
        self.df = self.df[validation_arr]

    def prepare_df(self):
        """Prepare df for validation by adding price and quantity columns"""
        # If take_n_rows is enabled, skip rows
        if hasattr(self, 'take_n_rows'):
            self.df = self.df.iloc[0:self.take_n_rows]

        # Add price column and filter null values.
        # Raise InvalidInventoryFileException
        # if get_price fails (column doesn't exist)
        try:
            self.df['price'] = get_price(self.price_column_name, self.df)
        except Exception as e:
            raise InvalidInventoryFileException("Column price {0} couldn’t been found".format(e))

        self.df = self.df[self.df['price'].notnull()]
        if hasattr(self, 'clear_price_by_regex'):
            regex = self.clear_price_by_regex
            self.df['price'] = self.df['price'].map(lambda price, sub=re.sub, regex=regex: sub(regex, '', str(price)))

        # Add quantity column
        # Raise InvalidInventoryFileException
        # if quantity column is not found
        try:
            self.df['quantity'] = self.df[self.quantity_column_name]
        except KeyError as e:
            raise InvalidInventoryFileException("Column quantity {0} couldn’t been found".format(e))

        # Add evergreen indicator - change quantity to 0 if evergreen to avoid issues
        evergreen_column_indicator = getattr(self, 'evergreen_column_indicator', None)
        if evergreen_column_indicator:
            evergreen_column_indicator_value = getattr(self, 'evergreen_column_indicator_value')
            for _idx, _row in self.df.iterrows():
                evergreen_value = '1' if _row[evergreen_column_indicator] == evergreen_column_indicator_value else '0'
                self.df.at[_idx, 'evergreen'] = evergreen_value
                if evergreen_value == '1':
                    self.df.at[_idx, 'quantity'] = 0
        else:
            self.df['evergreen'] = np.array([None for x in range(len(self.df.index))])

        # Filter null quantities
        self.df = self.df[self.df['quantity'].notnull()]

    def transform_df(self):
        # Transform price if merchant_price_markup is enabled
        if hasattr(self, 'merchant_price_markup'):
            self.df['price'] = self.df['price'] + self.df['price'] * self.merchant_price_markup

        # Convert price to float and round it
        self.df['price'] = self.df['price'].astype(float).round(2).astype(str)
        self.df = self.df[self.df['price'].notnull()]

        # Convert negative quantities into 0 (catalog service fails with such values)
        self.df['quantity'] = self.df['quantity'].astype(float).astype(int).clip(lower=0)

        # Create hmpk based on mpk_column_names
        self.df['hmpk'] = np.array(['hmpk' for x in range(len(self.df.index))])
        for column_name in self.mpk_column_names:
            self.df['hmpk'] = self.df['hmpk'].map(str) + '_' + self.df[column_name].map(str)

        # Add tmk column
        self.df['tmk'] = np.array([self.tmk for x in range(len(self.df.index))])

        # Add extra columns
        for n_file_column, column_setting_name in extra_columns_to_pull:
            _attr = getattr(self, column_setting_name, None)
            if _attr:
                self.df[n_file_column] = self.df[_attr]
            else:
                self.df[n_file_column] = np.array([None for x in range(len(self.df.index))])

    def persist_df(self):
        self.df['mpk'] = self.df['hmpk'].map(utils.generate_mpk)
        new_columns = ['tmk', 'mpk', 'price', 'quantity', 'hmpk', 'msku']
        rows, columns = self.df.shape
        unique_mpks = self.df.mpk.unique().shape[0]
        if rows == unique_mpks:
            self.logger.debug('MPKs are unique. rows({0}) =  unique_mpks({1})'.format(rows, unique_mpks))
        else:
            self.logger.error('[{2}] MPKs are not unique. rows({0}) <> unique_mpks({1})'.format(
                rows, unique_mpks, self.tmk
            ))
            df1 = self.df.mpk.value_counts()
            self.logger.error('[{1}] duplicated MPKs {0}'.format(df1[df1 > 1], self.tmk))

        new_columns += [c for c in self.df.columns if c not in new_columns]

        self.df = self.df[new_columns]
        self.nfile_timestamp = datetime.datetime.now().strftime('%Y-%m-%d-%H:%M:%S')
        self.csv_output_filename = '{0}-{1}-{2}.{3}'.format('N5', self.tmk, self.nfile_timestamp, 'csv')
        csv_output_file_location = '{0}/{1}'.format(self.output_file_dir, self.csv_output_filename)
        self.df.to_csv(csv_output_file_location, encoding='utf-8', index=False, quotechar='"')
        self.csvs_written.append(csv_output_file_location)

    def persist_invalid_rows_df(self):
        self.logger.error(
            'Some invalid rows ({0}) were found for {1}, '
            'generating output csv'.format(
                len(self.invalid_rows_df.index),
                self.tmk
            )
        )
        invalid_rows_csv_output_filename = '{0}-{1}-{2}.{3}'.format(
                self.tmk, self.nfile_timestamp, 'INVALID-ROWS', 'csv'
        )
        invalid_rows_csv_output_file_location = '{0}/{1}'.format(
            self.output_file_dir, invalid_rows_csv_output_filename
        )
        self.invalid_rows_df.to_csv(
            invalid_rows_csv_output_file_location,
            encoding='utf-8',
            index=False,
            quotechar='"'
        )
        self.csvs_written.append(invalid_rows_csv_output_file_location)


    def upload_generated_inventory_file(self):
        csv_output_file_location = '{0}/{1}'.format(self.output_file_dir, self.csv_output_filename)
        with open(csv_output_file_location, 'rb') as _file:
            self.upload_inventory_file(self.tmk, _file)

    def upload_inventory_file(self, tmk, _file):
        try:
            url = f'{settings.MATCHMAKER_URL}/i/merchant/{tmk}/inventory'
            files = {'upload': _file}
            response = requests.post(
                url,
                auth=requests.auth.HTTPBasicAuth(
                    settings.MATCHMAKER_USERNAME,
                    settings.MATCHMAKER_PASSWORD
                ),
                files=files
            )
            if response.status_code == requests.codes.OK:
                self.logger.debug('Inventory uploaded.')
            else:
                self.logger.error('Inventory upload failed. {0}'.format(response.text))
        except Exception as e:
            self.logger.error('Inventory upload failed.')
            self.logger.error(e)

    def upload_inventory_failure(self, tmk, description):
        try:
            url = f'{settings.MATCHMAKER_URL}/i/merchant/{tmk}/inventory'
            response = requests.post(
                url,
                auth=requests.auth.HTTPBasicAuth(
                    settings.MATCHMAKER_USERNAME,
                    settings.MATCHMAKER_PASSWORD
                ),
                json={"description": description}
            )
            if response.status_code == requests.codes.OK:
                self.logger.debug('Inventory uploaded.')
            else:
                self.logger.error('Inventory upload failed. {0}'.format(response.text))
        except Exception as e:
            self.logger.error('Inventory upload failed.')
            self.logger.error(e)

    def archive_N(self):
        archive_dir = '{0}/Archive'.format(self.output_file_dir)
        utils.post_persisted_n_file_to_couch(self.tmk, f'{self.output_file_dir}/{self.csv_output_filename}')
        utils.archive_extract(self.output_file_dir, archive_dir, self.csv_output_filename)
        self.logger.debug('archived {0}'.format(self.csv_output_filename))

    def archive_invalid_raw(self, error_log):
        raw_input_filename = os.path.basename(self.extractor.get_input_file())
        failures_dir = '{0}/Failures'.format(self.input_file_dir)

        # If Failures directory doesn't exists, we create it
        if not os.path.isdir(failures_dir):
            os.makedirs(failures_dir)

        # Move raw file to Failures directory
        utils.archive_extract(
            self.input_file_dir,
            failures_dir,
            raw_input_filename
        )

        # Create log file
        error_log_filename = raw_input_filename.replace(
            self.input_file_extension,
            '.log'
        )
        utils.archive_extract(
            self.input_file_dir,
            failures_dir,
            error_log_filename,
            data=error_log
        )
        self.logger.debug(
            'moved inventory file to Failures folder {0}'.format(
                raw_input_filename
            )
        )

        # Upload inventory extraction as failure
        self.upload_inventory_failure(self.tmk, description=error_log)

    def generate(self):
        self.df = self.extractor.extract()
        self.prepare_df()
        self.validate_df()
        self.transform_df()
        self.persist_df()

        # If invalid rows df is not empty, create invalid rows output csv
        if not self.invalid_rows_df.empty:
            self.persist_invalid_rows_df()

        if hasattr(self, 'test') and self.test:
            return self.csvs_written

        self.upload_generated_inventory_file()

        self.extractor.archive()
        self.archive_N()

        if hasattr(self, 'reflect_to'):
            for mirror_tmk in self.reflect_to:
                self.reflect_to_mirror_stores(mirror_tmk)

        return self.csvs_written


    def reflect_to_mirror_stores(self, tmk):
        mirror_df = self.df.copy()
        mirror_df['tmk'] = np.array([tmk for x in range(len(self.df.index))])
        inventory_file = mirror_df.to_csv(encoding='utf-8', index=False, quotechar='"')
        filename = f'{tmk}.csv'
        self.upload_inventory_file(tmk, (filename, inventory_file))
        utils.post_n_file_to_couch(tmk, inventory_file)


    # generates csv files as strings
    def generate_csv(self):
        self.df = self.extractor.extract()
        self.transform_df()

        self.df['mpk'] = self.df['hmpk'].map(utils.generate_mpk)
        new_columns = ['tmk', 'mpk', 'price', 'quantity', 'hmpk']

        (rows, columns) = self.df.shape
        unique_mpks = self.df.mpk.unique().shape[0]
        if rows == unique_mpks:
            self.logger.debug('MPKs are unique. rows({0}) =  unique_mpks({1})'.format(rows, unique_mpks))
        else:
            self.logger.error('MPKs are not unique. rows({0}) <> unique_mpks({1})'.format(rows, unique_mpks))
            df1 = self.df.mpk.value_counts()
            self.logger.error('duplicated MPKs {0}'.format(df1[df1 > 1]))

        _columns = self.df.columns
        for column in _columns:
            if column not in new_columns:
                new_columns.append(column)

        self.df = self.df[new_columns]
        self.csv_output_filename = 'N5-{0}-{1}.{2}'.format(self.tmk, datetime.datetime.now().strftime('%Y-%m-%d-%H:%M:%S'), 'csv')
        return self.df.to_csv(encoding='utf-8', index=False, quotechar='"')


class DirectInventoryGenerator(NormalizedInventoryGenerator):
    def __init__(self, *args, **kwargs):
        super(DirectInventoryGenerator, self).__init__(*args, **kwargs)
        self.logger.debug = lambda m: print(m, file=sys.stderr)
        self.logger.error = lambda m: print(m, file=sys.stderr)


def inventory_generator_factory(tmk: str, archiver: ia.MerchantInventoryArchiver = None, catalog=None ) -> NormalizedInventoryGenerator:

    if catalog is None:
        catalog = get_catalog_from_couch()

    config = catalog[tmk]
    _type = config['nig']

    if _type == 'mirror':
        mirrored_tmk = config['depends_on']
        return inventory_generator_factory(mirrored_tmk, catalog=catalog)

    archiver = archiver if archiver else ia.inventory_archiver_factory(tmk, catalog=catalog)

    generator = NormalizedInventoryGenerator(archiver, **config)

    if _type == 'bevsites':
        generator.mpk_column_names = ['sku', 'size', 'item_size', 'botpercase']
        generator.price_column_name = ['price_1', 'price_2']
        generator.quantity_column_name = 'stocku'

    return generator
