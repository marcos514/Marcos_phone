#!/usr/bin/env bash

set -e

cp /key/mm_key /key/mm_key_internal
chown -R root:root /key/mm_key_internal
chmod -R 400 /key/mm_key_internal

mkdir -p /mnt/merchant_inventories && \
sshfs "$EXAVAULT_USER"@thirstie-inventory.exavault.com:/ /mnt/merchant_inventories -o IdentityFile=/key/mm_key_internal -o StrictHostKeyChecking=no -o reconnect,ServerAliveInterval=15,ServerAliveCountMax=3

cd /
./wait-for-it.sh configuration:5984 -t 0
cd /extractor_svc
python server.py
