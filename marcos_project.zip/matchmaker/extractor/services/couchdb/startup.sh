#!/usr/bin/env bash

file='/opt/couchdb/data/finished.txt'
if [ ! -f "$file" ]
then
  tar -zvxf /couchData.tar.gz -C /opt/couchdb/data/
  echo "finished!" > /opt/couchdb/data/finished.txt
fi

cp /local.ini /opt/couchdb/etc/local.d/local.ini

/opt/couchdb/bin/couchdb
