#!/bin/bash -l

export LC_ALL=C.UTF-8
export LANG=C.UTF-8

exec "$@"