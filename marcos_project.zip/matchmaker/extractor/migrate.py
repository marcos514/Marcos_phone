import settings
import couchdb
from uuid import uuid4

dbs_to_replicate = ['merchant_configs']
server = couchdb.Server(settings.COUCH_URL)
server.resource.credentials = ('ops', 'i am very thirstie')


def replicate():
    '''
    Creates a 1 time replication document on the servers _replicator db
    Will run locally and on staging but not on production
    '''

    if not settings.UPSTREAM_COUCH_URL:
        return

    db = server['_replicator']

    for db_name in dbs_to_replicate:

        id = uuid4().hex

        db[id] = {
          "source": {
            "headers":  {"Authorization": "Basic b3BzOmkgYW0gdmVyeSB0aGlyc3RpZQ=="},
            "url": f"{settings.UPSTREAM_COUCH_URL}/{db_name}"
          },
          "target": {
            "headers": {"Authorization": "Basic b3BzOmkgYW0gdmVyeSB0aGlyc3RpZQ=="},
            "url": f"http://localhost:5984/{db_name}"
          }
        }




def merchant_slas():
    db = server['merchant_configs']
    for doc in db:
        doc = db[doc]
        try:
            doc["merchant_sla_hours"]
        except KeyError:
            doc["merchant_sla_hours"] = 24
            if doc['tmk'] in ['M4W7RZ', 'MKBBRP']:
                doc["merchant_sla_hours"] = 1
            db.save(doc)


migrations = [
    lambda: merchant_slas()
]

if __name__ == '__main__':
    for migration in migrations:
        migration()
    #disabled, staging now uses continuous replication from
    #replicate()












