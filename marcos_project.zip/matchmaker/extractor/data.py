import json

import requests

from settings import (
    COUCH_URL, AWS_S3_DESTINATION,
    AWS_S3_BUCKET_NAME, AWS_S3_ACCESS_KEY,
    AWS_S3_SECRET_KEY, AWS_S3_HOST
)

import boto3

# generate the catalog
def get_catalog_from_couch():
    r = requests.get(f'{COUCH_URL}/merchant_configs/_all_docs?include_docs=true')
    r = r.json()['rows']
    catalog = {}
    for conf in r:
        catalog[conf['key']] = conf['doc']

    return catalog


# update couchdb merchant's settings
def update_couch_db_settings(tmk, body):
    response = requests.put(f'{COUCH_URL}/merchant_configs/{tmk}', data=json.dumps(body))
    return response

def get_botoS3_client():
    return boto3.client(
        "s3",
        aws_access_key_id=AWS_S3_ACCESS_KEY,
        endpoint_url=AWS_S3_HOST,
        aws_secret_access_key=AWS_S3_SECRET_KEY,
    )


def upload_file_to_s3(location):
    s3_client = get_botoS3_client()
    s3_client.upload_file(location, AWS_S3_BUCKET_NAME, AWS_S3_DESTINATION)
