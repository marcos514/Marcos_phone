import abc
import datetime
from ftplib import FTP
import json
import shutil
import os
import dbfread
import zipfile

import requests
import pandas as pd
from pandas.io.json import json_normalize

import settings
import utils
from data import get_catalog_from_couch

class MerchantInventoryArchiver(abc.ABC):
    def __init__(self, config: dict):
        self.tmk = config["tmk"]
        try:
            self.merchant_settings = config
        except KeyError:
            raise KeyError(f'No configuration found for tmk: {tmk}')
        self.extracted_file = False

    @abc.abstractmethod
    def extract(self):
        pass

    def get_input_file(self):
        files = utils.get_files_with_extension(
            self.merchant_settings['input_file_dir'],
            self.merchant_settings['input_filename_part'],
            self.merchant_settings['input_file_extension'],
        )

        if len(files) > 1:
            if 'match_first_file' not in self.merchant_settings:
                raise EnvironmentError(
                    f'Multiple matching files at integration point for tmk {self.tmk}. Unclear which file to use')

        if len(files) < 1:
            raise FileNotFoundError

        return f'{self.merchant_settings["input_file_dir"]}/{files[0]}'

    def has_new_data(self):
        '''A direct extractor expects a csv that resides in the merchant folder.'''

        try:
            file = self.get_input_file()
        except FileNotFoundError:
            return False

        if not self.merchant_settings.get('ignore_checksum', True):
            return utils.is_new_file(file, self.merchant_settings['input_file_dir'] + '/checksum')
        else:
            return True


    def archive(self):

        if not self.extracted_file:
            raise RuntimeError('Must call extract before calling archive')

        utils.save_checksum(self.extracted_file, self.merchant_settings['input_file_dir'] + '/checksum')
        archive_dir = f'{self.merchant_settings["input_file_dir"]}/Archive'
        filename = os.path.basename(self.extracted_file)
        ts = datetime.datetime.now().strftime('%Y-%m-%d-%H:%M:%S')
        shutil.move(self.extracted_file, f'{archive_dir}/{ts}-{filename}', shutil.copyfile)


class MerchantCsvArchiver(MerchantInventoryArchiver):
    def extract(self):
        self.extracted_file = self.get_input_file()
        d = self.merchant_settings['delimiter'] if 'delimiter' in self.merchant_settings else ','
        encoding = self.merchant_settings['encoding'] if 'encoding' in self.merchant_settings else 'utf-8'
        column_names = self.merchant_settings['column_names'] if 'column_names' in self.merchant_settings else None
        read_bad_lines = self.merchant_settings['read_bad_lines'] if 'read_bad_lines' in self.merchant_settings else True
        df = pd.read_csv(self.extracted_file, sep=d, encoding=encoding, names=column_names, error_bad_lines=read_bad_lines)
        df.dropna(how="all", inplace=True)

        if 'skip_first_data_row' in self.merchant_settings:
            df = df.drop(0)

        if 'convert_null_values' in self.merchant_settings:
            df = df.fillna(0)

        return df


class SocalCsvArchiver(MerchantInventoryArchiver):
    def extract(self):
        self.extracted_file = self.get_input_file()
        file_data = []

        # socal_file will be created in the tmp folder and then change it when there is a new export
        # From this file we get all the information we need.
        # This file fix the headers and remove all the rows that could cause issue in the future
        socal_file = f'/tmp/{self.merchant_settings["socal_file"]}'

        with open(self.extracted_file) as extracted_file:
            with open(socal_file, 'w') as socal_file_writer:
                file_data = extracted_file.read().replace('|', '\t').splitlines(True)
                header = ''
                row_count = len(file_data)
                for index, fd in enumerate(file_data):
                    if index > 3 and (row_count - index) > 2:
                        socal_file_writer.write(fd)
                    elif index == 0:
                        header = fd.replace('\n',',')
                    elif index == 1:
                        socal_file_writer.write(header + fd)
        df = pd.read_csv(socal_file, sep='\t')
        wrong_columns = df.iloc[0:1].values.tolist()[0]
        wrong_columns.pop(0)
        columns = []
        for column in df.columns:
            if 'Unnamed' in columns:
                column = columns.pop(0)
            columns.append(column)
        df.columns = columns
        os.remove(socal_file)
        return df


class BevsitesArchiver(MerchantInventoryArchiver):
    def __init__(self, config):
        super().__init__(config)
        self.merchant_settings['input_filename_part'] = 'RAW'
        self.merchant_settings['input_file_extension'] = '.zip'


    def extract(self):
        file = self.get_input_file()
        self.extracted_file = file

        zip = zipfile.ZipFile(file)
        unziped_raw_file_dir = '/tmp/' + file.replace('.zip', '')
        zip.extractall(unziped_raw_file_dir)
        file = f'{unziped_raw_file_dir}/output.xml'
        df = utils.convert_bevsites_xml_to_df(file)
        shutil.rmtree(unziped_raw_file_dir, True)
        return df

class ZipArchiver(MerchantInventoryArchiver):
    def __init__(self, config):
        super().__init__(config)
        self.merchant_settings['input_file_extension'] = '.zip'

    def extract(self):
        file = self.get_input_file()
        self.extracted_file = file
        output_file = self.merchant_settings['output_file']
        zip = zipfile.ZipFile(file)
        unziped_raw_file_dir = '/tmp/' + file.replace('.zip', '')
        zip.extractall(unziped_raw_file_dir)
        file = f'{unziped_raw_file_dir}/{output_file}'
        df = utils.convert_xml_to_df(file)
        shutil.rmtree(unziped_raw_file_dir, True)
        return df

class FixedWithArchiver(MerchantInventoryArchiver):
    def extract(self):
        file = self.get_input_file()
        self.extracted_file = file
        df = pd.read_fwf(file)
        df = df.drop(0)
        df = df[df["PRICE"].notnull()]

        return df


class WebCsvArchiver(MerchantCsvArchiver):
    def __init__(self, tmk: str):
        super().__init__(tmk)
        self.merchant_settings['input_filename_part'] = 'RAW'
        self.merchant_settings['input_file_extension'] = '.csv'

    def extract(self):
        file = self.get_input_file()
        d = self.merchant_settings['delimiter'] if 'delimiter' in self.merchant_settings else ','
        self.extracted_file = file
        return pd.read_csv(file, delimiter=d)


class DirectArchiver(MerchantInventoryArchiver):
    def __init__(self, config, file):
        super().__init__(config)
        self.file = file

    def extract(self):
        file = self.file
        d = self.merchant_settings['delimiter'] if 'delimiter' in self.merchant_settings else ','
        self.extracted_file = file

        nig_type = self.merchant_settings['nig']
        if nig_type == 'l1':
            encoding = self.merchant_settings['encoding'] if 'encoding' in self.merchant_settings else 'utf-8'
            df = pd.read_csv(self.extracted_file, sep=d, encoding=encoding)
            df.dropna(how="all", inplace=True)

            if 'skip_first_data_row' in self.merchant_settings:
                df = df.drop(0)

            if 'convert_null_values' in self.merchant_settings:
                df = df.fillna(0)
        elif nig_type == 'bevsites':
            zip = zipfile.ZipFile(file)
            unziped_raw_file_dir = file.replace('.zip', '')
            zip.extractall(unziped_raw_file_dir)
            file = f'{unziped_raw_file_dir}/output.xml'
            df = utils.convert_xml_to_df(file)
            shutil.rmtree(unziped_raw_file_dir, True)
        elif nig_type == 'dbf':
            db = dbfread.DBF(file,  ignore_missing_memofile=True)
            df = pd.DataFrame(iter(db))
        else:
            df = pd.read_csv(file, delimiter=d)

        return df

    def has_new_data(self):
        return True

class LiquorPosArchiver(MerchantInventoryArchiver):
    def extract(self):
        _file = self.get_input_file()
        self.extracted_file = _file
        with open(_file) as data_file:
            json_file = json.load(data_file)
        df = json_normalize(json_file)
        return df


class DBFArchiver(MerchantInventoryArchiver):
    def extract(self):
        file = self.get_input_file()
        self.extracted_file = file
        db = dbfread.DBF(file,  ignore_missing_memofile=True)
        df = pd.DataFrame(iter(db))
        return df


class ExcelArchiver(MerchantInventoryArchiver):
    def extract(self):
        self.extracted_file = self.get_input_file()
        column_names = self.merchant_settings.get('column_names', None)
        df = pd.read_excel(self.extracted_file, names=column_names)
        df.dropna(how="all", inplace=True)

        if 'skip_first_data_row' in self.merchant_settings:
            df = df.drop(0)

        if 'convert_null_values' in self.merchant_settings:
            df = df.fillna(0)

        return df


def inventory_archiver_factory(tmk, catalog=None):

    if catalog is None:
        catalog = get_catalog_from_couch()

    config = catalog[tmk]
    _type = config['nig']

    if _type == 'l1':
        extractor = MerchantCsvArchiver(config)
    elif _type == 'l1_with_ftp':
        extractor = WebCsvArchiver(config)
    elif _type == 'fixed_width':
        extractor = FixedWithArchiver(config)
    elif _type == 'bevsites':
        extractor = BevsitesArchiver(config)
    elif _type == 'dbf':
        extractor = DBFArchiver(config)
    elif _type == 'excel':
        extractor = ExcelArchiver(config)
    elif _type == 'mirror':
        mirrored_tmk = config['depends_on']
        extractor = inventory_archiver_factory(mirrored_tmk)
    elif _type == 'liquor_pos':
        extractor = LiquorPosArchiver(config)
    elif _type == 'zip':
        extractor = ZipArchiver(config)
    elif _type == 'socal':
        extractor = SocalCsvArchiver(config)

    return extractor
