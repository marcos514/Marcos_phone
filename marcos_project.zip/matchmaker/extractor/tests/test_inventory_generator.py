import os
import unittest
from glob import glob
import settings
import numpy as np
import pandas as pd

from inventory_generators import inventory_generator_factory


# constants
dir = os.path.dirname(os.path.realpath(__file__))
input_file_1 = f'{dir}/test_files/input/1/ThirstieRAW.csv'
input_file_2 = f'{dir}/test_files/input/2/SecondRAW.csv'
output_folder = f'{os.path.dirname(os.path.realpath(__file__))}/test_files/output'

settings.MERCHANT_INVENTORY_DIR = dir

catalog = {
    'ABCDEF': {
        "tmk": "ABCDEF",
        "input_file_extension": ".csv",
        'input_file_dir': f'{dir}/test_files/input',
        'output_file_dir': f'{dir}/test_files/output',
        'input_filename_part': 'Thirstie',
        'nig': 'l1',
        "price_column_name": "Web Price",
        "quantity_column_name": "QOH",
        "mpk_column_names": [
            "SKU Number",
            "UPC_code",
            "Description"
        ],
        "test": True
    },
    'MWZZ69': {
        "tmk": "MWZZ69",
        "input_file_extension": ".csv",
        'input_file_dir': f'{dir}/test_files/input',
        'output_file_dir': f'{dir}/test_files/output',
        'input_filename_part': 'Thirstie'
    },
    'bevsites': {
        "tmk": "bevsites",
        "input_file_extension": ".zip",
        'input_file_dir': f"{dir}/test_files/bevsites",
        'output_file_dir': output_folder,
        'nig': 'bevsites',
        'test': True

    }
}

class TestM1Merchant(unittest.TestCase):

    def setUp(self):
        catalog['ABCDEF']['input_file_dir'] = f'{dir}/test_files/input/1'
        catalog['ABCDEF']['output_file_dir'] = f'{dir}/test_files/output'
        catalog['ABCDEF']['input_filename_part'] = 'RAW'
        catalog['ABCDEF']['price_column_name'] = 'Web Price'

    def test_l1_multi_price(self):
        catalog['ABCDEF']['input_file_dir'] = f'{dir}/test_files/input/3'
        catalog['ABCDEF']['price_column_name'] = ['Web Price', 'Web Price 2']
        catalog['ABCDEF']['input_filename_part'] = 'RAW'
        adaptor   = inventory_generator_factory('ABCDEF', catalog=catalog)
        csvs = adaptor.generate()
        n_file = pd.read_csv(csvs[0])
        self.assertAlmostEqual(n_file['price'][0], 217.)
        self.assertAlmostEqual(n_file['price'][1], 10.99)

    def test_output_invalid_rows_csv(self):
        catalog['ABCDEF']['input_file_dir'] = f'{dir}/test_files/input/4'
        catalog['ABCDEF']['price_column_name'] = 'Web Price'
        catalog['ABCDEF']['input_filename_part'] = 'RAW'
        adaptor = inventory_generator_factory('ABCDEF', catalog=catalog)
        csvs = adaptor.generate()
        invalid_rows_file = pd.read_csv(csvs[1])
        self.assertEqual(invalid_rows_file['price'][0], '$9.99;')

    def test_li(self):

        adaptor   = inventory_generator_factory('ABCDEF', catalog=catalog)
        csvs = adaptor.generate()

        self.assertEqual(len(csvs), 1)
        n_file = pd.read_csv(csvs[0])
        unique = n_file['tmk'].unique()
        self.assertTrue(len(unique) == 1)
        self.assertTrue(unique[0], 'M4W7RZ')

        original = pd.read_csv(input_file_1)

        original_data = n_file.as_matrix(columns=["price", "quantity"])
        n_data = original.as_matrix(columns=["Web Price", "QOH"])
        self.assertTrue(np.allclose(n_data, original_data))

    def test_markup_option(self):
        catalog['ABCDEF']['merchant_price_markup'] = .1
        adaptor = inventory_generator_factory('ABCDEF', catalog=catalog)

        csvs = adaptor.generate()

        self.assertEqual(len(csvs), 1)
        n_file = pd.read_csv(csvs[0])
        unique = n_file['tmk'].unique()
        self.assertTrue(len(unique) == 1)
        self.assertTrue(unique[0], 'M4W7RZ')

        original = pd.read_csv(input_file_1)
        original_data = n_file.as_matrix(columns=["price"])
        n_data = original.as_matrix(columns=["Web Price"])
        n_data += n_data * .1

        self.assertTrue(np.allclose(n_data, original_data, atol=2))
        del catalog['ABCDEF']['merchant_price_markup']


    def test_l1_deterministic(self):
        adaptor = inventory_generator_factory('ABCDEF', catalog=catalog)
        csvs = adaptor.generate()
        first_tmks = pd.read_csv(csvs[0]).sort_values('mpk').as_matrix(["tmk", "mpk", "price", "quantity"])

        catalog['ABCDEF']['input_file_dir'] = f'{dir}/test_files/input/2'
        adaptor = inventory_generator_factory('ABCDEF', catalog=catalog)
        csvs = adaptor.generate()
        second_tmks = pd.read_csv(csvs[0]).sort_values('mpk').as_matrix(["tmk","mpk","price","quantity"])

        self.assertTrue(np.all(np.equal(first_tmks, second_tmks)))

    def test_bevsites_archiver(self):
        generator = inventory_generator_factory('bevsites', catalog=catalog)
        generator.generate()


    def tearDown(self):
        for i in glob(output_folder + "/*"):
            os.remove(i)


if __name__ == '__main__':
    unittest.main()
