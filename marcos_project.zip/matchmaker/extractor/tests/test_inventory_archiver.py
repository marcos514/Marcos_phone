import os
import unittest
import unittest.mock as mock
from glob import glob
import inventory_archivers as ie
import settings
from data import get_catalog_from_couch
import utils
import pandas as pd

dir = os.path.dirname(os.path.realpath(__file__))

catalog = {
    'ABCDEF': {
        "tmk": "ABCDEF",
        "input_file_extension": ".csv",
        'input_file_dir': f'{dir}/test_files/input',
        'output_file_dir': f'{dir}/test_files/output',
        'input_filename_part': 'Thirstie'
    },
    'MWZZ69': {
        "tmk": "MWZZ69",
        "input_file_extension": ".csv",
        'input_file_dir': f'{dir}/test_files/input',
        'output_file_dir': f'{dir}/test_files/output',
        'input_filename_part': 'Thirstie'
    },
    'bevsites': {
        "tmk": "ABCDEF",
        "input_file_extension": ".zip",
        'input_file_dir': f"{dir}/test_files/bevsites",
        'output_file_dir': f'{dir}/test_files/output',
        'input_filename_part': 'bevsites'
    },
    'liquorpos': {
        "tmk": "MWZZ69",
        "input_file_extension": ".dbf",
        'input_file_dir': f'{dir}/test_files/dbf',
        'output_file_dir': f'{dir}/test_files/output',
        'input_filename_part': 'LIQCODE'
    }
}

# constants
input_file_1 = f'{dir}/test_files/input/1/ThirstieRAW.csv'
input_file_2 = f'{dir}/test_files/input/2/SecondRAW.csv'
output_folder = f'{os.path.dirname(os.path.realpath(__file__))}/test_files/output'
settings.MERCHANT_INVENTORY_DIR = dir


class TestArchivers(unittest.TestCase):

    def setUp(self):
        catalog['ABCDEF']['input_file_dir'] = f'{dir}/test_files/input'
        catalog['ABCDEF']['output_file_dir'] = f'{dir}/test_files/output'
        catalog['ABCDEF']['input_filename_part'] = 'Thirstie'

        catalog['MWZZ69']['input_file_dir'] = f'{dir}/test_files/input'
        catalog['MWZZ69']['output_file_dir'] = f'{dir}/test_files/output'

    def test_csv_extractor_checksum(self):
        catalog['ABCDEF']['input_file_dir'] = f'{dir}/test_files/input/1'
        catalog['ABCDEF']['ignore_checksum'] = False

        checksum = f"{catalog['ABCDEF']['input_file_dir']}/checksum"
        if os.path.isfile(checksum):
            os.remove(checksum)

        extractor = ie.MerchantCsvArchiver(catalog['ABCDEF'])
        assert extractor.has_new_data() == True

        utils.save_checksum(input_file_1, checksum)
        assert extractor.has_new_data() == False

        data = extractor.extract()
        assert isinstance(data, pd.DataFrame)
        os.remove(checksum)


    def testBevsitesArchiver(self):
        extractor = ie.BevsitesArchiver(catalog['bevsites'])
        assert extractor.has_new_data() == True

    def testDBFExtractor(self):
        extractor = ie.DBFArchiver(catalog['liquorpos'])
        df = extractor.extract()
        x = 1

    def tearDown(self):
        for i in glob(output_folder + "/*"):
            os.remove(i)


if __name__ == '__main__':
    unittest.main()
