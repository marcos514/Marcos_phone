
import os
from distutils.util import strtobool


APP_DIR = os.path.dirname(os.path.abspath(__file__))

BEVSITES_FTP_URL = 'ftp6.zinergy.net'
BEVSITES_FTP_USER = 'thirstiedata'
BEVSITES_FTP_PASSWORD = 'thirdta815'

MATCHMAKER_USERNAME = 'ops'
MATCHMAKER_PASSWORD = 'i am very thirstie'
MATCHMAKER_URL = os.environ.get('MATCHMAKER_URL', 'https://next.matchmaker.thirstie.com')


COUCH_URL = os.environ.get('COUCH_URL', 'http://localhost:8887')
UPSTREAM_COUCH_URL = os.environ.get('UPSTREAM_COUCH_URL', 'https://next.matchmaker.thirstie.com:6984')


MERCHANT_INVENTORY_DIR = os.environ.get('MERCHANT_INVENTORY_DIR', '/mnt/merchant_inventories')
MERCHANT_BACKUPS_DIR = os.environ.get('MERCHANT_BACKUPS_DIR', '/')


ENVIRONMENT_NAME = os.environ.get('ENVIRONMENT_NAME', 'local')
SLACK_URL = os.environ.get('SLACK_URL', 'https://hooks.slack.com/services/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')

LOG_TO_SLACK = strtobool(os.environ.get('LOG_TO_SLACK', 'False'))

LOGGING_LEVEL = 'INFO'

# Aws connection settings
AWS_S3_ACCESS_KEY = os.environ.get('S3_ACCESS_KEY')
AWS_S3_SECRET_KEY = os.environ.get('S3_SECRET_KEY')
AWS_S3_HOST = os.environ.get('S3_HOST')
AWS_S3_BUCKET_NAME = "mmbackups"
AWS_S3_DESTINATION = f'backups/{ENVIRONMENT_NAME}/'

##################
# LOCAL SETTINGS #
##################

# DO NOT PLACE ANYTHING BELOW THIS!!!!!!!
# Allow any settings to be defined in local_settings.py, which should be
# ignored in your version control system, allowing for settings to be
# defined per machine.
try:
    from local_settings import *  # NOQA
except ImportError as e:
    if "local_settings" not in str(e):
        raise e
