#!/usr/bin/env bash

DB_USER=root
DB_PASSWORD=root
DB_HOST=reports_db
DB_NAME=reports_db
MIGRATIONS_DIRECTORY=/src/migrations



cd /
./wait-for-it.sh $DB_HOST:3306 -t 0
cd "$MIGRATIONS_DIRECTORY"
yoyo apply --database mysql+mysqldb://$DB_USER:$DB_PASSWORD@$DB_HOST/$DB_NAME


mkdir -p /mnt/reports
echo ${S3_ACCESS_KEY}:${S3_SECRET_KEY} > ${HOME}/.passwd-s3fs
chmod 600 ${HOME}/.passwd-s3fs
s3fs mmbackups:/reports/${TORNADO_ENVIRONMENT} /mnt/reports -o passwd_file=${HOME}/.passwd-s3fs -o url=${S3_HOST} -o use_path_request_style -o multipart_size=100 -o parallel_count=30

python /src/server.py
