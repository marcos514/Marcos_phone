import os
from distutils.util import strtobool
'''
All Configs use os.environ.get with sensible default values specified.

The default values are meant for local development,
while any production instance should have an appropriately provisioned server.

Using environment variables for configs is recommended by https://12factor.net/config
'''

# TORNADO CONFIGURATIONS
TORNADO_LISTEN_PORT = int(os.environ.get('TORNADO_LISTEN_PORT', 6000))
TORNADO_DEBUG = bool(strtobool(os.environ.get('TORNADO_DEBUG', 'False')))

# DATABASE CONFIGURATIONS
DB_NAME = os.environ.get('DB_NAME', 'reports_db')
DB_HOST = os.environ.get('DB_HOST', '127.0.0.1')
DB_PORT = int(os.environ.get('DB_PORT', 3306))
DB_USER = os.environ.get('DB_USER', 'root')
DB_PASS = os.environ.get('DB_PASS', 'root')

# EXTERNAL SERVICES
ENVIRONMENT = os.environ.get('TORNADO_ENVIRONMENT', 'development')
MAPPING_API = os.environ.get('MAPPING_API', 'http://localhost:8885/m')
INVENTORY_API = os.environ.get('INVENTORY_API', 'http://localhost:8885/i')
THIRSTIE_API = os.environ.get('THIRSTIE_URL', 'https://api.next.thirstie.com')

# REPORT CONFIGURATIONS
REPORT_DESTINATION = '/mnt/reports'
