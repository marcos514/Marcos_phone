from datetime import datetime
from tornado import gen
from config import ENVIRONMENT
from services import (
    get_inventory,
    get_products_data,
    get_mappings,
    get_merchants,
    get_all_mappings
)
from util import (
    write_csv,
    save_report
)


class AbstractReportGenerator():
    _report_type = ''

    def __init__(self):
        date = datetime.now()
        environment = "" if ENVIRONMENT == 'production' else ENVIRONMENT
        self.filename = '{}_{}_{}.csv'.format(
            date, self._report_type, environment
        )

    @gen.coroutine
    def do_report(self):
        yield self.generate()
        self.persist()

    @gen.coroutine
    def generate(self):
        pass

    def persist(self):
        write_csv(self.report, self.fieldnames, self.filename)
        save_report(self.filename, self._report_type)


class MasterNFileReportGenerator(AbstractReportGenerator):
    _report_type = 'master_n_file'

    @gen.coroutine
    def generate(self):
        # get tmks
        merchants = yield get_merchants()
        tmks = [m['tmk'] for m in merchants]

        # get inventory and mappings data
        mappings, inventory = yield [
            get_mappings(tmks), get_inventory(tmks)
        ]

        # get catalog data
        tpks = [mapping['tpk'] for mapping in mappings]
        products_data = yield get_products_data(tpks)

        mappings = [
            dict(mapping, **inv)
            for mapping in mappings for inv in inventory
            if inv["tmk"] == mapping["tmk"] and inv["mpk"] == mapping["mpk"]
        ]

        report = [
            {
                'tmk': inv['tmk'],
                'tpk': mapping['tpk'],
                'mpk': mapping['mpk'],
                'name': product['product_line']['name'],
                'type': product['product_line'].get(
                    'product_type', {}
                ).get('display_name'),
                'size': product['container_size']["formatted"],
                'price': inv['price'],
                'quantity': inv['quantity'],
                'enabled': mapping["enabled"],
                'exists': inv['active'] == '1'
            }
            for mapping in mappings
            for product in products_data['items']
            if product["tpk"] == mapping["tpk"]
            for inv in inventory
            if inv["tmk"] == mapping["tmk"] and inv["mpk"] == mapping["mpk"]
        ]

        self.report = report
        self.fieldnames = list(report[0].keys()) if report else []


class RAWMasterNFileReportGenerator(AbstractReportGenerator):
    _report_type = 'raw_master_n_file'

    @gen.coroutine
    def generate(self):
        # get tmks
        merchants = yield get_merchants()
        tmks = [m['tmk'] for m in merchants]

        # get inventories
        report = yield get_inventory(tmks)

        self.report = report
        self.fieldnames = list(report[0].keys()) if report else []


class AllMappingsReportGenerator(AbstractReportGenerator):
    _report_type = 'all_mappings'

    @gen.coroutine
    def generate(self):
        report = yield get_all_mappings()
        self.report = report
        self.fieldnames = list(report[0].keys()) if report else []


class ReportGeneratorFactory():
    _available_reports = {
        'master_n_file': MasterNFileReportGenerator,
        'raw_master_n_file': RAWMasterNFileReportGenerator,
        'all_mappings': AllMappingsReportGenerator
    }

    @classmethod
    def get_report_generator(cls, report_type):
        report_generator_class = cls._available_reports.get(
            report_type, None
        )
        return report_generator_class() if report_generator_class else None
