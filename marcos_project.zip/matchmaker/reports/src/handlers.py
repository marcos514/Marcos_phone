import json
from datetime import datetime

from MySQLdb import DatabaseError
from tornado import gen
from tornado.web import RequestHandler
from tornado.ioloop import IOLoop

from db import Database
from util import read_report, delete_report
from reports import ReportGeneratorFactory


class BaseRequestHandler(RequestHandler):
    def prepare(self):
        super(BaseRequestHandler, self).prepare()


class JsonApplicationRequestHandler(BaseRequestHandler):
    """
    Our json request handler extends tornado's Request handler and does some basic things specific to json endpoints
    """

    def prepare(self):

        super(JsonApplicationRequestHandler, self).prepare()

        content_type = self.request.headers.get('Content-Type', '')

        allowed_types = [
            'application/json; charset=utf-8',
            'application/json;charset=utf-8',
            'application/json'
        ]

        if str(content_type).lower() in allowed_types and self.request.body:
            self.json_body = json.loads(self.request.body.decode('utf-8'))
        else:
            self.json_body = None

        self.set_default_headers()

    def set_default_headers(self):
        self.add_header('Content-Type', 'application/json; charset=UTF-8')
        self.add_header('Access-Control-Allow-Origin', '*')

    def write_error(self, status_code, **kwargs):
        self.set_status(status_code)
        reason = kwargs['reason'] if 'reason' in kwargs else self._reason
        self.finish({"code": status_code, "message": reason})

    def write_json(self, chunk):
        self.set_header('Content-Type', 'application/json; charset=UTF-8')
        super(JsonApplicationRequestHandler, self).write(json.dumps(chunk, sort_keys=True))


class CSVWriter(object):

    @gen.coroutine
    def write_csv(self, data_file):
        self.write(data_file)
        yield self.flush()
        self.finish()


class GenerateReportHandler(JsonApplicationRequestHandler):
    @gen.coroutine
    def get(self, report_type):
        report_generator = ReportGeneratorFactory.get_report_generator(
            report_type
        )

        if not report_generator:
            self.set_status(404)
            self.write_json({'success': False})
            return

        # run async
        IOLoop.current().spawn_callback(report_generator.do_report)

        self.write_json({'success': True})
        return


class ReportHandler(JsonApplicationRequestHandler):
    @gen.coroutine
    @Database
    def delete(self, report_id, db):
        sql = '''
            SELECT * FROM reports
            WHERE id = %s
        '''
        cursor = db.fetchone(sql, [report_id])

        if not cursor:
            self.set_status(404)
            self.write_json({'success': False})
            return

        filename = cursor['filename']
        delete_report(filename)

        self.write_json({'success': True})
        return


class DownloadReportHandler(JsonApplicationRequestHandler, CSVWriter):
    @gen.coroutine
    @Database
    def get(self, report_id, db):
        sql = '''
            SELECT * FROM reports
            WHERE id = %s and date_deleted IS NULL;
        '''
        cursor = db.fetchone(sql, [report_id])

        if not cursor:
            self.set_status(404)
            self.write_json({'success': False})
            return

        filename = cursor['filename']
        data_file = read_report(filename)
        self.set_header('Content-Type', 'text/csv')
        self.set_header('Content-Disposition', 'attachment; filename={0}'.format(filename))
        self.write_csv(data_file)
        return


class ReportListHandler(JsonApplicationRequestHandler):
    @gen.coroutine
    @Database
    def get(self, db):
        sql = '''
            SELECT r.*,
            rt.description report_type_description,
            rt.name report_type_name FROM reports AS r
            LEFT JOIN report_type as rt ON rt.id = r.report_type_id
            WHERE r.date_deleted IS NULL
        '''
        reports = db.fetchall(sql)
        for report in reports:
            report['date_generated'] = str(report['date_generated'])
            report['date_deleted'] = str(report['date_deleted'])
        self.write_json(reports)
        return
