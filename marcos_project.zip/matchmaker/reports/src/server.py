import sys
import tornado.ioloop
import tornado.options as options
from tornado.web import RequestHandler

import config
from handlers import (
    GenerateReportHandler,
    DownloadReportHandler,
    ReportHandler,
    ReportListHandler
)

reports_ascii = r'''
 /$$$$$$$                                            /$$
| $$__  $$                                          | $$
| $$  \ $$  /$$$$$$   /$$$$$$   /$$$$$$   /$$$$$$  /$$$$$$    /$$$$$$$
| $$$$$$$/ /$$__  $$ /$$__  $$ /$$__  $$ /$$__  $$|_  $$_/   /$$_____/
| $$__  $$| $$$$$$$$| $$  \ $$| $$  \ $$| $$  \__/  | $$    |  $$$$$$
| $$  \ $$| $$_____/| $$  | $$| $$  | $$| $$        | $$ /$$ \____  $$
| $$  | $$|  $$$$$$$| $$$$$$$/|  $$$$$$/| $$        |  $$$$/ /$$$$$$$/
|__/  |__/ \_______/| $$____/  \______/ |__/         \___/  |_______/
                    | $$
                    | $$
                    |__/
'''


class HelloWorld(RequestHandler):
    def get(self):
        self.write(f"<pre>{reports_ascii}</pre>")


routes = [
    (r'/?', HelloWorld),
    (r"/generate/(?P<report_type>[\w,]+)/?", GenerateReportHandler),
    (r"/download/(?P<report_id>[\w,]+)/?", DownloadReportHandler),
    (r"/report/(?P<report_id>[\w,]+)/?", ReportHandler),
    (r"/reports/?", ReportListHandler),
]


def make_app(debug=False):
    return tornado.web.Application(routes, debug=debug)


if __name__ == "__main__":
    # enable pretty logging
    options.parse_command_line()

    app = make_app(config.TORNADO_DEBUG)
    app.listen(config.TORNADO_LISTEN_PORT)
    print(reports_ascii, file=sys.stderr)
    print(f"Running on port {config.TORNADO_LISTEN_PORT}", file=sys.stderr)
    tornado.ioloop.IOLoop.current().start()
