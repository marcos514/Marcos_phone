"""
Initial db structure
"""
from yoyo import step

__depends__ = {}

steps = [
    step("""
    -- ----------------------------
    -- Table structure for report_type
    -- ----------------------------

    CREATE TABLE IF NOT EXISTS `report_type` (
      `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
      `name` varchar(255) NOT NULL,
      `description` varchar(255) NOT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

    INSERT INTO `report_type` (`name`, `description`) VALUES ('master_n_file', 'Master N-File');
    INSERT INTO `report_type` (`name`, `description`) VALUES ('raw_master_n_file', 'RAW Master N-File');
    INSERT INTO `report_type` (`name`, `description`) VALUES ('all_mappings', 'All Merchant Mappings');

    -- ----------------------------
    -- Table structure for reports
    -- ----------------------------

    CREATE TABLE IF NOT EXISTS `reports` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `report_type_id` int(11) NOT NULL,
      `filename` varchar(255) NOT NULL,
      `date_generated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `date_deleted` datetime,
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """),
]
