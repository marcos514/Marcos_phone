import csv
from datetime import datetime
import os
from config import (
    REPORT_DESTINATION
)
from db import Database


def get_report_path(filename):
    return '/'.join([REPORT_DESTINATION, filename])


def write_csv(items, fieldnames, filename):
    path = get_report_path(filename)
    with open(path, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for item in items:
            writer.writerow(item)


def read_report(filename):
    path = get_report_path(filename)
    with open(path, 'r') as report:
        return report.read()


@Database
def save_report(filename, report_type, db):
    '''
    Save new report
    '''
    sql = "SELECT id FROM report_type WHERE name = %s"
    report_type = db.fetchone(sql, [report_type])
    sql = 'INSERT INTO reports (report_type_id, filename) VALUES (%s, %s);'
    db.execute(sql, (report_type['id'], filename))


@Database
def delete_report(filename, db):
    '''
    Delete a report
    '''
    # remove report from local system
    path = get_report_path(filename)
    os.remove(path)

    # mark as deleted on db
    date = datetime.now()
    sql = '''
        UPDATE reports
        SET date_deleted = %s
        WHERE filename = %s
    '''
    db.execute(sql, [date, filename])
