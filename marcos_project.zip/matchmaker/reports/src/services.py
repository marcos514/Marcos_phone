'''
Helper functions to perform various network requests
'''
from datetime import datetime
import json
import time
from tornado import gen
from tornado.httpclient import AsyncHTTPClient
from config import (
    MAPPING_API, INVENTORY_API, THIRSTIE_API, ENVIRONMENT
)

# Raise maximum response size accepted by the client to
# 200MB (see TH-493)
AsyncHTTPClient.configure(None, max_body_size=200 * 1024 ** 2)
# create async client
client = AsyncHTTPClient()


@gen.coroutine
def get_products_data(tpks):
    # get products data from catalog api
    # TODO timeout is increased because catalog service
    # last ~110 secs to complete
    request_config = {
        'method': 'POST',
        'headers': {
            'Content-Type': 'application/json; charset=UTF-8'
        },
        'body': json.dumps({'tpks': tpks}),
        'connect_timeout': 120.0,
        'request_timeout': 120.0
    }

    url = f'{THIRSTIE_API}/c/v2/products/data/'
    response = yield client.fetch(url, **request_config)
    return json.loads(response.body)


@gen.coroutine
def get_inventory(tmks):
    # get the latest inventory for given tmks
    url = '{0}/merchants/{1}/inventory'.format(
        INVENTORY_API,
        ','.join(tmks)
    )
    response = yield client.fetch(url, raise_error=False)
    return json.loads(response.body)


@gen.coroutine
def get_mappings(tmks):
    # get merchant mappings for given tmks
    url = '{0}/merchants/mappings/{1}'.format(
        MAPPING_API,
        ','.join(tmks)
    )
    response = yield client.fetch(url,  raise_error=False)
    return json.loads(response.body)

@gen.coroutine
def get_merchants():
    # get merchants tmks
    url = '{0}/merchants'.format(MAPPING_API)
    response = yield client.fetch(url,  raise_error=False)
    return json.loads(response.body)


@gen.coroutine
def get_all_mappings():
    # get all mappings
    url = '{0}/mappings'.format(MAPPING_API)
    response = yield client.fetch(url,  raise_error=False)
    return json.loads(response.body)


@gen.coroutine
def get_products():
    # get master product list
    url = '{0}/products'.format(MAPPING_API)
    response = yield client.fetch(url,  raise_error=False)
    return json.loads(response.body)
