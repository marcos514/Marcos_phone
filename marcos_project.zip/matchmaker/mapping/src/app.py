from flask import Flask
app = Flask(__name__)

import config
from blueprints import mappings, merchants, products


'''
 (r"/merchant/?", MerchantHandler),
 (r"/merchant/(?P<tmk>[\w]+)/?", MerchantHandler),
 (r"/merchants", MerchantsHandler),

 (r"/product/(.+)", ProductHandler),
 (r"/product", ProductHandler),
 (r"/products", ProductsHandler),
 (r"/merchant/(?P<tmk>[\w]+)/mappings/?", MerchantMappingsHandler),
 (r"/merchant/(?P<tmk>[\w]+)/mapping/(?P<tpk>[\w]+)/?", MerchantMappingsHandler)
'''


app.register_blueprint(mappings.mappings)
app.register_blueprint(products.products)
app.register_blueprint(merchants.merchants)

if __name__ == '__main__':
    configuration = {
        'host': '0.0.0.0',
        'port': config.FLASK_PORT,
        'debug': config.FLASK_DEBUG
    }
    app.run(**configuration)
