# An opaque Data class with Base encoding and decoding functionality
# -----------------------------------------------------------------------------
# A collection of classes for storing binary data and converting it into
# various base-encoded strings for text representations useful for
# over-the-wire transmission.
#
# Includes implementations of Base16, Doug Crockford's Base32, Flickr's
# Base58, and Base64 encodings.
#
# Documentation at http://github.com/brendn/Trilobyte
#
# Version 0.6
#
# Written by Brendan Berg
# Copyright Plus or Minus Five, 2012

from __future__ import division
from math import log, ceil
import re
import sys


if sys.version_info < (3,):
    integer_types = (int, long,)
    bytes_type = (str,)
    bytes_t = lambda ch: chr(ch)
else:
    integer_types = (int,)
    bytes_type = (bytes,)
    bytes_t = lambda ch: bytes([ch])


class Data(object):
    '''The `Data` class is an opaque data object that uses a byte string as a
    backing store. The class provides functions to manipulate data objects and
    generate string representations

    '''

    def __init__(self, string, encoding=None):
        if encoding:
            self.bytes = encoding.decode(string)
        else:
            if isinstance(string, str):
                self.bytes = string.encode('ascii')
            elif isinstance(string, bytes_type):
                self.bytes = string
            elif isinstance(string, integer_types):
                num = string
                if num < 0:
                    raise ValueError('Data constructor requires a positive integer')
                byteLen = int(ceil(num.bit_length() / 8))
                self.bytes = ''.join(chr(num >> (8 * i) & 0xFF) for i in reversed(range(byteLen)))
            else:
                raise TypeError('Data constructor requires a byte string, int, or long')

    def stringWithEncoding(self, encoding, **kwargs):
        return encoding.encode(self.bytes, **kwargs)

    def hex(self):
        return self.stringWithEncoding(Base16)

    def __str__(self):
        return self.stringWithEncoding(Base64)

    def __repr__(self):
        encoded = self.stringWithEncoding(Base64)
        if '\n' in encoded:
            return "Data('''{0}''', Base64)".format(encoded)
        else:
            return "Data('{0}', Base64)".format(encoded)

    def __add__(self, other):
        return Data(self.bytes + other.bytes)

    __concat__ = __add__

    def __iadd__(self, other):
        self.bytes += other.bytes
        return self

    def __contains__(self, item):
        return item.bytes in self.bytes

    def __eq__(self, other):
        return self.bytes == other.bytes

    def __len__(self):
        return len(self.bytes)

    def __getitem__(self, key):
        return Data(self.bytes[key])

    def __setitem__(self, key, value):
        if isinstance(key, slice):
            start, stop, step = key.indices(len(self.bytes))

            if step != 1:
                raise TypeError('cannot modify data contents with a stride')

            self.bytes = self.bytes[:start] + value.bytes + self.bytes[stop:]
        elif isinstance(key, int):
            self.bytes = self.bytes[:key] + value.bytes + self.bytes[key+1:]
        else:
            raise TypeError('data indices must be integers or slices')


class Encoding(object):
    '''The `Encoding` class is an abstract base for various encoding types.
    It provides generic left-to-right bitwise conversion algorithms for its
    subclasses. At a minimum, a subclass must override the `alphabet` and
    `base` class properties.

    Attempting to instantiate an encoding object will result in a
    `NotImplementedError`:

    >>> Encoding()
    Traceback (most recent call last):
        ...
    NotImplementedError: Encoding classes cannot be instantiated. ...
    '''

    alphabet = ''
    base = 0
    replacements = {}

    def __init__(self):
        raise NotImplementedError(
            'Encoding classes cannot be instantiated. Use '
            'Data.stringWithEncoding(Encoding) instead.'
        )

    @classmethod
    def decode(clz, string, alphabet=None, ignoreinvalidchars=False):
        if not alphabet:
            alphabet = clz.alphabet

        width = int(log(clz.base, 2))

        bytes = b''
        window = 0
        winOffset = 16 - width

        for ch in clz._canonicalRepr(string):
            try:
                window |= (alphabet.index(ch) << winOffset)
            except ValueError:
                raise ValueError('Illegal character in input string')
            winOffset -= width

            if winOffset <= (8 - width):
                bytes += bytes_t((window & 0xFF00) >> 8)
                window = (window & 0xFF) << 8
                winOffset += 8

        if window:
            # The padding was wrong, so we throw a tantrum
            raise ValueError('Illegal input string')

        # We assembled the byte string in reverse because it's faster
        # to append to a string than to prepend in Python. Reversing a
        # string, on the other hand is Super Fast (TM).
        return bytes

    @classmethod
    def encode(clz, byteString, alphabet=None, linelength=64, lineseparator='\r\n'):
        if not alphabet:
            alphabet = clz.alphabet

        width = int(log(clz.base, 2))
        string = ''
        lineCharCount = 0

        window = 0

        maskOffset = 8 - width
        mask = (2 ** width - 1) << maskOffset

        for ch in byteString:
            if sys.version_info < (3,):
                window |= ord(ch)
            else:
                window |= ch

            while maskOffset >= 0:
                string += alphabet[(window & mask) >> maskOffset]
                lineCharCount += 1

                if linelength and lineCharCount == linelength:
                    string += lineseparator
                    lineCharCount = 0

                if maskOffset - width >= 0:
                    mask >>= width
                    maskOffset -= width
                else:
                    break

            window &= 0xFF
            window <<= 8
            mask <<= 8 - width
            maskOffset += 8 - width

        if maskOffset > 8 - width:
            # If there are unencoded characters to the right of the mask, shift
            # the mask all the way right and shift the window the remainder of
            # the mask width to encode a zero-padded character at the end.
            string += alphabet[(window & mask) >> maskOffset]

        return string

    @classmethod
    def _canonicalRepr(clz, string):
        for k, v in clz.replacements.items():
            string = string.replace(k, v)

        return string


class Base16(Encoding):
    '''
    Encoder class for your friendly neighborhood hexidecimal numbers.
    '''

    alphabet = '0123456789ABCDEF'
    base = 16

    # Discard hyphens, spaces, carriage returns, and new lines from input.
    replacements = {
        '-': '',
        ' ': '',
        '\r': '',
        '\n': '',
        'I': '1',
        'L': '1',
        'O': '0',
        'S': '5',
    }

    @classmethod
    def _canonicalRepr(clz, string):
        return super(Base16, clz)._canonicalRepr(string.upper())


class CheckedBase32(Encoding):
    r'''
    Encoder class for Doug Crockford's Base32 encoding, but with an additional
    checksum digit. (See the `Base32` class above for more discussion of the
    particular properties of Crockford Base32.)

    The checksum is a Base-32 implementation of the [Damm Algorithm][1], which
    uses a [32 x 32 quasigroup matrix][2] described on StackOverflow.

    [1]: https://en.wikipedia.org/wiki/Damm_algorithm
    [2]: http://stackoverflow.com/questions/23431621/extending-the-damm-algorithm-to-base-32

    >>> a = Data('', CheckedBase32)
    >>> a.hex()
    ''

    >>> b = Data('ABCDEF', CheckedBase32)
    >>> b.stringWithEncoding(Base64)
    'UtjX'

    >>> c = Data('UtjX', Base64)
    >>> c.stringWithEncoding(CheckedBase32)
    'ABCDEF'

    >>> d = Data('ABCDE0', CheckedBase32)
    Traceback (most recent call last):
        ...
    ValueError: Invalid checksum
    '''

    _check_table = [
        [ 0,  2,  4,  6,  8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30,
            3,  1,  7,  5, 11,  9, 15, 13, 19, 17, 23, 21, 27, 25, 31, 29],
        [ 2,  0,  6,  4, 10,  8, 14, 12, 18, 16, 22, 20, 26, 24, 30, 28,
            1,  3,  5,  7,  9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31],
        [ 4,  6,  0,  2, 12, 14,  8, 10, 20, 22, 16, 18, 28, 30, 24, 26,
            7,  5,  3,  1, 15, 13, 11,  9, 23, 21, 19, 17, 31, 29, 27, 25],
        [ 6,  4,  2,  0, 14, 12, 10,  8, 22, 20, 18, 16, 30, 28, 26, 24,
            5,  7,  1,  3, 13, 15,  9, 11, 21, 23, 17, 19, 29, 31, 25, 27],
        [ 8, 10, 12, 14,  0,  2,  4,  6, 24, 26, 28, 30, 16, 18, 20, 22,
           11,  9, 15, 13,  3,  1,  7,  5, 27, 25, 31, 29, 19, 17, 23, 21],
        [10,  8, 14, 12,  2,  0,  6,  4, 26, 24, 30, 28, 18, 16, 22, 20,
            9, 11, 13, 15,  1,  3,  5,  7, 25, 27, 29, 31, 17, 19, 21, 23],
        [12, 14,  8, 10,  4,  6,  0,  2, 28, 30, 24, 26, 20, 22, 16, 18,
           15, 13, 11,  9,  7,  5,  3,  1, 31, 29, 27, 25, 23, 21, 19, 17],
        [14, 12, 10,  8,  6,  4,  2,  0, 30, 28, 26, 24, 22, 20, 18, 16,
           13, 15,  9, 11,  5,  7,  1,  3, 29, 31, 25, 27, 21, 23, 17, 19],
        [16, 18, 20, 22, 24, 26, 28, 30,  0,  2,  4,  6,  8, 10, 12, 14,
           19, 17, 23, 21, 27, 25, 31, 29,  3,  1,  7,  5, 11,  9, 15, 13],
        [18, 16, 22, 20, 26, 24, 30, 28,  2,  0,  6,  4, 10,  8, 14, 12,
           17, 19, 21, 23, 25, 27, 29, 31,  1,  3,  5,  7,  9, 11, 13, 15],
        [20, 22, 16, 18, 28, 30, 24, 26,  4,  6,  0,  2, 12, 14,  8, 10,
           23, 21, 19, 17, 31, 29, 27, 25,  7,  5,  3,  1, 15, 13, 11,  9],
        [22, 20, 18, 16, 30, 28, 26, 24,  6,  4,  2,  0, 14, 12, 10,  8,
           21, 23, 17, 19, 29, 31, 25, 27,  5,  7,  1,  3, 13, 15,  9, 11],
        [24, 26, 28, 30, 16, 18, 20, 22,  8, 10, 12, 14,  0,  2,  4,  6,
           27, 25, 31, 29, 19, 17, 23, 21, 11,  9, 15, 13,  3,  1,  7,  5],
        [26, 24, 30, 28, 18, 16, 22, 20, 10,  8, 14, 12,  2,  0,  6,  4,
           25, 27, 29, 31, 17, 19, 21, 23,  9, 11, 13, 15,  1,  3,  5,  7],
        [28, 30, 24, 26, 20, 22, 16, 18, 12, 14,  8, 10,  4,  6,  0,  2,
           31, 29, 27, 25, 23, 21, 19, 17, 15, 13, 11,  9,  7,  5,  3,  1],
        [30, 28, 26, 24, 22, 20, 18, 16, 14, 12, 10,  8,  6,  4,  2,  0,
           29, 31, 25, 27, 21, 23, 17, 19, 13, 15,  9, 11,  5,  7,  1,  3],
        [ 3,  1,  7,  5, 11,  9, 15, 13, 19, 17, 23, 21, 27, 25, 31, 29,
            0,  2,  4,  6,  8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30],
        [ 1,  3,  5,  7,  9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31,
            2,  0,  6,  4, 10,  8, 14, 12, 18, 16, 22, 20, 26, 24, 30, 28],
        [ 7,  5,  3,  1, 15, 13, 11,  9, 23, 21, 19, 17, 31, 29, 27, 25,
            4,  6,  0,  2, 12, 14,  8, 10, 20, 22, 16, 18, 28, 30, 24, 26],
        [ 5,  7,  1,  3, 13, 15,  9, 11, 21, 23, 17, 19, 29, 31, 25, 27,
            6,  4,  2,  0, 14, 12, 10,  8, 22, 20, 18, 16, 30, 28, 26, 24],
        [11,  9, 15, 13,  3,  1,  7,  5, 27, 25, 31, 29, 19, 17, 23, 21,
            8, 10, 12, 14,  0,  2,  4,  6, 24, 26, 28, 30, 16, 18, 20, 22],
        [ 9, 11, 13, 15,  1,  3,  5,  7, 25, 27, 29, 31, 17, 19, 21, 23,
           10,  8, 14, 12,  2,  0,  6,  4, 26, 24, 30, 28, 18, 16, 22, 20],
        [15, 13, 11,  9,  7,  5,  3,  1, 31, 29, 27, 25, 23, 21, 19, 17,
           12, 14,  8, 10,  4,  6,  0,  2, 28, 30, 24, 26, 20, 22, 16, 18],
        [13, 15,  9, 11,  5,  7,  1,  3, 29, 31, 25, 27, 21, 23, 17, 19,
           14, 12, 10,  8,  6,  4,  2,  0, 30, 28, 26, 24, 22, 20, 18, 16],
        [19, 17, 23, 21, 27, 25, 31, 29,  3,  1,  7,  5, 11,  9, 15, 13,
           16, 18, 20, 22, 24, 26, 28, 30,  0,  2,  4,  6,  8, 10, 12, 14],
        [17, 19, 21, 23, 25, 27, 29, 31,  1,  3,  5,  7,  9, 11, 13, 15,
           18, 16, 22, 20, 26, 24, 30, 28,  2,  0,  6,  4, 10,  8, 14, 12],
        [23, 21, 19, 17, 31, 29, 27, 25,  7,  5,  3,  1, 15, 13, 11,  9,
           20, 22, 16, 18, 28, 30, 24, 26,  4,  6,  0,  2, 12, 14,  8, 10],
        [21, 23, 17, 19, 29, 31, 25, 27,  5,  7,  1,  3, 13, 15,  9, 11,
           22, 20, 18, 16, 30, 28, 26, 24,  6,  4,  2,  0, 14, 12, 10,  8],
        [27, 25, 31, 29, 19, 17, 23, 21, 11,  9, 15, 13,  3,  1,  7,  5,
           24, 26, 28, 30, 16, 18, 20, 22,  8, 10, 12, 14,  0,  2,  4,  6],
        [25, 27, 29, 31, 17, 19, 21, 23,  9, 11, 13, 15,  1,  3,  5,  7,
           26, 24, 30, 28, 18, 16, 22, 20, 10,  8, 14, 12,  2,  0,  6,  4],
        [31, 29, 27, 25, 23, 21, 19, 17, 15, 13, 11,  9,  7,  5,  3,  1,
           28, 30, 24, 26, 20, 22, 16, 18, 12, 14,  8, 10,  4,  6,  0,  2],
        [29, 31, 25, 27, 21, 23, 17, 19, 13, 15,  9, 11,  5,  7,  1,  3,
           30, 28, 26, 24, 22, 20, 18, 16, 14, 12, 10,  8,  6,  4,  2,  0]
    ]
    alphabet = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'
    base = 32
    replacements = {
        '-': '',
        ' ': '',
        '\r': '',
        '\n': '',
        'I': '1',
        'L': '1',
        'O': '0'
    }

    @classmethod
    def _canonicalRepr(clz, string):
        '''
        return the canonical base-32 string
        '''
        return super(CheckedBase32, clz)._canonicalRepr(string.upper())

    @classmethod
    def _next_intermediate(clz, digit, inter):
        '''
        return the next intermediate digit in calculating the checksum

        The Damm Algorithm ...
        '''
        return clz._check_table[inter][digit]

    @classmethod
    def _check_digit(clz, digits):
        '''
        Return the check digit for a sequence of digits
        '''
        inter = 0
        for digit in digits:
            inter = clz._next_intermediate(digit, inter)
        return inter

    @classmethod
    def _decompose(clz, string):
        '''
        Return the integer values for each encoded character of the input string
        '''
        return [clz.alphabet.index(ch) for ch in clz._canonicalRepr(string)]

    @classmethod
    def check_char(clz, string):
        '''
        Return the check character (the base-32 encoded check digit) for a
        given input string
        '''
        return clz.alphabet[clz._check_digit(clz._decompose(string))]

    @classmethod
    def validate(clz, string):
        '''
        Return true if the check digti (the string's terminal character) is
        correct for the given input string
        '''
        return clz._check_digit(clz._decompose(string)) == 0

    @classmethod
    def decode(clz, string):
        '''
        Return the decoded byte string represented by the base-32 input string,
        or raise a ValueError if the checksum is incorrect
        '''
        if not clz.validate(string):
            raise ValueError('Invalid checksum')

        string = clz._canonicalRepr(string[:-1])
        return super(CheckedBase32, clz).decode(string)

    @classmethod
    def encode(clz, byteString):
        '''
        Return the base-32 encoded string representation of the input bytes,
        with the Damm checksum digit as the terminal character
        '''
        result = super(CheckedBase32, clz).encode(byteString)
        return result + clz.check_char(result)


class Base64(Encoding):
    '''
    Encoder class for a flexible Base 64 encoding.
    '''

    alphabet = (
        'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    )
    base = 64
    replacements = {
        '\r': '',
        '\n': '',
        ' ': '',
        '=': ''
    }

    @classmethod
    def encode(clz, byteString, **kwargs):
        if 'alphabet' not in kwargs:
            highIndexChars = kwargs.get('highindexchars', '+/')
            kwargs['alphabet'] = clz.alphabet[:-2] + highIndexChars

        string = super(Base64, clz).encode(byteString, **kwargs)
        padding = '=' * (4 - ((len(string) % 4) or 4))
        return string + padding



if __name__ == '__main__':
    import doctest

    options = doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE

    doctest.testmod(optionflags=options)
