'''
Transform the mapping object for the response.
'''
from distutils.util import strtobool

def mapping_transform(data_dict, db=False):
    # transforms the mapping object to the result
    # here, we only change the active key to a boolean
    enabled = str(data_dict.get('enabled', False))
    enabled = bool(strtobool(enabled))
    if db:
        enabled = 1 if enabled else 0
    data_dict['enabled'] = enabled
    return data_dict
