'''
Transform the merchant object for the response.
'''

def merchant_transform(data_dict, db=False):
    # transforms the merchant object to the result
    enabled = data_dict.get('enabled', False)
    if db:
        enabled = 1 if enabled else 0
    else:
        enabled = bool(enabled)
    return {
        'tmk': data_dict.get('tmk', None),
        'name': data_dict.get('name', None),
        'enabled': enabled
    }
