'''
Transforms for products
'''

def mpl_transform(data_dict, db=False):
    # transform for the master product list
    enabled = data_dict.get('enabled', True)
    if type(enabled) == str:
        enabled = enabled.lower() == 'true'
    if db:
        enabled = 1 if enabled else 0
    else:
        enabled = bool(enabled)
    return {
        'tpk': data_dict.get('tpk', None),
        'enabled': enabled
    }
