import csv
import services
import random
from MySQLdb import DatabaseError
from flask import Blueprint, abort, jsonify, request, make_response
from transforms.merchant import merchant_transform
from util import Data, CheckedBase32

merchants = Blueprint('merchants', __name__)

@merchants.route('/merchants', methods=['POST'])
@services.json_responder
def import_merchants():
    if 'upload' not in request.files:
        abort(404)

    data = services.load_csv_or_abort(request.files['upload'], set(('tmk','enabled','name')))

    @services.loads(data)
    def merchant_row_updater(row: dict, cursor):
        sql = "INSERT INTO merchants (tmk, name, enabled) VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE name=VALUES(name),enabled=VALUES(enabled);"
        row = {k.lower(): v for k, v in row.items()}
        cursor.execute(sql, (row['tmk'], row['name'], row['enabled']))
    try:
        merchant_row_updater()
    except DatabaseError:
        abort(make_response(jsonify(message=f"{e.args[1]}"), 400))

    return {"success": "true"}

@merchants.route('/merchants', methods=['GET'])
@services.json_responder
@services.database
def get_merchants(db):
    sql = "SELECT * FROM merchants"

    limit, offset = request.args.get("limit", None), request.args.get("offset", None)
    if limit or offset:
        sql += f" LIMIT {int(limit) if limit else 18446744073709551610}  OFFSET {int(offset) if offset else 0}"

    merchants = list(db.fetchall(sql))
    merchants = list(map(lambda m: merchant_transform(m), merchants))
    return merchants

# Merchant Routes
@merchants.route('/merchant/<tmk>', methods=['POST', 'PUT'])
@services.json_responder
@services.database
def merchant_updater(db, tmk):
    # request data
    columns = ['tmk', 'name', 'enabled']
    request_data = request.get_json(force=True)
    merchant_obj = merchant_transform(request_data, db=True)

    # for PUT, make sure the TMK exists
    if request.method == 'PUT':
        # make sure the TMK exists
        merchant = db.fetchone('SELECT * FROM merchants WHERE tmk = "{0}"'.format(tmk))
        if not merchant or merchant['tmk'] != tmk:
            abort(404)

    # create/update the entry in the DB
    data = tuple(merchant_obj.get(i, None) for i in columns)
    sql = "INSERT INTO merchants (tmk, name, enabled) VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE name=VALUES(name),enabled=VALUES(enabled);"
    db.execute(sql, data)
    return {'merchant': request_data}

@merchants.route('/merchant/<tmk>', methods=['GET'])
@services.database
@services.json_responder
def validate_merchant(db, tmk):
    merchant = db.fetchone('SELECT * FROM merchants WHERE tmk = "{0}"'.format(tmk))
    if not merchant:
        abort(404)
    return merchant_transform(merchant)

@merchants.route('/merchants/generate', methods=['GET'])
@services.json_responder
def new_tmk():
    # The TMK value is the Base32 encoded representation of a random
    # integer between 10,485,760 and 11,010,047 followed by a
    # check digit (for a range in Base32 from M0000Z to MZZZY9)
    tmk_bytes = int.to_bytes(random.randint(0xA00000, 0xA7FFFF), 3, byteorder='big')
    return {'tmk': Data(tmk_bytes).stringWithEncoding(CheckedBase32)}
