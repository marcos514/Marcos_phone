import csv, re
from flask import Blueprint, abort, request, make_response, jsonify
import services
import urllib.request
import config
from transforms.mapping import mapping_transform
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from MySQLdb import DatabaseError
import json


mappings = Blueprint('mappings', __name__)


def trigger_offering_upload(tmk):
    return urllib.request.urlopen('{0}/{1}'.format(config.INVENTORY_TRIGGER, tmk)).read()

@mappings.route('/mappings', methods=['GET'])
@services.database
@services.json_responder
def get_all_mappings(db):
    # get request args
    csv = request.args.get('csv', 'false').lower() == 'true'

    sql = "SELECT * FROM mappings"

    mappings = list(db.fetchall(sql))
    mappings = list(map(lambda m: mapping_transform(m), mappings))
    if csv:
        fieldnames = [('TMK', str), ('TPK', str), ('MPK', str), ('Enabled', bool), ('Delete', str)]
        output = services.return_csv(mappings, fieldnames)
        filename = f'attachment; filename=all_mappings_{datetime.now():%Y-%m-%dT%H_%M}.csv'
        output.headers['Content-Disposition'] = filename
        return output
    return mappings

@mappings.route('/merchants/mappings/<tmks>', methods=['GET'])
@services.database
@services.json_responder
def get_full_merchants_mappings(db, tmks):
    # get request args
    csv = request.args.get('csv', 'false').lower() == 'true'

    merchants = tmks.split(",")
    sql = "SELECT * FROM mappings WHERE tmk in %s"
    cursor = list(db.fetchall(sql, [merchants]))

    mappings = list(map(mapping_transform, cursor))
    if csv:
        fieldnames = [('TMK', str), ('TPK', str), ('MPK', str), ('Enabled', bool), ('Delete', str)]
        output = services.return_csv(mappings, fieldnames)
        filename = f'attachment; filename={tmk}_map_{datetime.now():%Y-%m-%dT%H_%M}.csv'
        output.headers['Content-Disposition'] = filename
        return output
    return mappings

@mappings.route('/merchant/<tmk>/mappings', methods=['GET'])
@services.database
@services.json_responder
def get_mappings(db, tmk):
    # get request args
    csv = request.args.get('csv', 'false').lower() == 'true'
    limit, offset = request.args.get("limit", None), request.args.get("offset", None)

    sql = "SELECT * FROM mappings WHERE tmk = %s"
    if limit or offset:
        sql += f" LIMIT {int(limit) if limit else 18446744073709551610}  OFFSET {int(offset) if offset else 0}"

    mappings = list(db.fetchall(sql, [tmk]))
    mappings = list(map(lambda m: mapping_transform(m), mappings))
    if csv:
        fieldnames = [('TMK', str), ('TPK', str), ('MPK', str), ('Enabled', bool), ('Delete', str)]
        output = services.return_csv(mappings, fieldnames)
        filename = f'attachment; filename={tmk}_map_{datetime.now():%Y-%m-%dT%H_%M}.csv'
        output.headers['Content-Disposition'] = filename
        return output
    return mappings

@mappings.route('/metadata/<tmks>', methods=['GET'])
@services.database
@services.json_responder
def get_mapping_metadata(db, tmks):
    merchants = tmks.split(',')
    sum_clauses = []
    active_clauses = []
    for tmk in merchants:
        sum_clauses.append(f'SUM(CASE tmk WHEN %s THEN 1 ELSE 0 END) AS %s')
        active_clauses.append(f'SUM(CASE WHEN tmk = %s && enabled = 1 THEN 1 ELSE 0 END) AS %s')

    total_qry = f"SELECT {', '.join(sum_clauses)} FROM mappings"
    active_qry = f"SELECT {', '.join(active_clauses)} FROM mappings"

    arg = sorted(merchants * 2)
    totals = db.fetchall(total_qry, arg)[0]
    active = db.fetchall(active_qry, arg)[0]
    for tmk in merchants:
        totals[tmk] = int(totals[tmk])
        active[tmk] = int(active[tmk])
    return {'total_mappings': totals, 'active_mappings': active}

@mappings.route('/merchant/<tmk>/mappings/<mapping_id>', methods=['PUT'])
@services.database
@services.json_responder
def update_mappings(db, tmk, mapping_id):
    # request data
    columns = ['id', 'tmk', 'mpk', 'tpk', 'enabled']
    enabled = request.get_json(force=True)

    # make sure the TMK exists
    merchant = db.fetchone('SELECT * FROM merchants WHERE tmk = %s', [tmk])
    if not merchant or merchant['tmk'] != tmk:
        abort(404)

    # create/update the mapping record
    sql = 'UPDATE mappings SET enabled = %s WHERE id = %s'
    db.execute(sql, (enabled, mapping_id))

    # returns mapping_obj (used by the frontend)
    return {'mapping': mapping_id}

@mappings.route('/merchant/<tmk>/mappings', methods=['POST'])
@services.database
@services.json_responder
def import_mappings(db, tmk):
    # check if file exists and is a csv
    p_csv = request.files.get('upload', None)
    if not p_csv or not re.search(r"\.csv$", p_csv.filename, re.IGNORECASE):
        abort(make_response(jsonify(message='Please supply a .csv file'), 400))

    # get the entire mpl and list of mappings
    products = set([r['tpk'] for r in db.fetchall('SELECT * FROM products')])
    data = services.load_csv_or_abort(p_csv, set(('tmk','enabled','mpk','tpk')))

    def validate_row(row: dict):
        if row['tmk'] != tmk:
            abort(make_response(jsonify(message=f"Row validation failed: TMK {row['tmk']} does not match {tmk}"), 400))
        if row['tpk'] not in products:
            abort(make_response(jsonify(message=f"Row validation failed: TPK {row['tpk']} is not in MPL"), 400))

    @services.loads(data)
    def update_product_row(row: dict, cursor) -> int:
        row = {k.lower(): v for k, v in row.items()}
        validate_row(row)
        if row.get('delete', '').lower() == 'yes':
            sql = 'DELETE FROM mappings WHERE tmk = %s AND tpk = %s AND mpk = %s'
            cursor.execute(sql, (tmk, row['tpk'], row['mpk']))
        else:
            sql = 'INSERT INTO mappings (tmk, mpk, tpk, enabled) VALUES (%s, %s, %s, %s) ON DUPLICATE KEY UPDATE enabled=VALUES(enabled), mpk=VALUES(mpk);'
            row = mapping_transform(row, db=True)
            cursor.execute(sql, (tmk, row['mpk'], row['tpk'], row['enabled']))
    try:
        update_product_row()
    except DatabaseError as e:
        abort(make_response(jsonify(message=f"{e.args[1]}"), 400))

    # trigger uploader
    executor = ThreadPoolExecutor(max_workers=1)
    executor.submit(trigger_offering_upload,tmk)

    return {"success": "true"}
