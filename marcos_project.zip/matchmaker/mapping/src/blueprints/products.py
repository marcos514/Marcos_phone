'''
Handlers for the Master Product List
'''
from flask import Blueprint, jsonify, abort, request, make_response
from transforms.product import mpl_transform
from datetime import datetime
import services
import csv
import db
import re
from MySQLdb import DatabaseError

products = Blueprint('products', __name__)


@products.route('/products', methods=['GET'])
@services.json_responder
@services.database
def get_products(db):
    sql = "SELECT * FROM products"
    limit, offset = request.args.get("limit", None), request.args.get("offset", None)
    if limit or offset:
        sql += f" LIMIT {int(limit) if limit else 18446744073709551610}  OFFSET {int(offset) if offset else 0}"
    products = list(db.fetchall(sql))
    products = list(map(lambda p: mpl_transform(p), products))
    csv = request.args.get('csv', 'false').lower() == 'true'
    if csv:
        fieldnames = [('Enabled', bool), ('TPK', str)]
        output = services.return_csv(products, fieldnames)
        filename = 'attachment; filename=MPL_{:%Y-%m-%dT%H_%M}.csv'.format(datetime.now())
        output.headers['Content-Disposition'] = filename
        return output
    return products


@products.route('/products', methods=['POST'])
@services.json_responder
@services.database
def import_products(db):
    # check if file exists and is a csv
    p_csv = request.files.get('upload', None)
    if not p_csv or not re.search(r"\.csv$", p_csv.filename, re.IGNORECASE):
        abort(make_response(jsonify(message='Please supply a .csv file'), 400))

    data = services.load_csv_or_abort(request.files['upload'], set(('tpk','enabled')))

    @services.loads(data)
    def product_row_updater(row: dict, cursor) -> int:
        sql = "INSERT INTO products (tpk, enabled) VALUES (%s, %s) ON DUPLICATE KEY UPDATE enabled=VALUES(enabled);"
        row = {k.lower(): v for k, v in row.items()}
        row = mpl_transform(row, db=True)
        cursor.execute(sql, (row['tpk'], row['enabled']))
    try:
        product_row_updater()
    except Exception as e:
        abort(make_response(jsonify(message=f"{e.args[1]}"), 400))

    return {'success':'OK'}

@products.route('/product/<tpk>', methods=['PUT'])
@services.json_responder
@services.database
def update_product_enabled(db, tpk):
    enabled = request.get_json(force=True)
    sql = 'UPDATE products SET enabled = %s WHERE tpk = %s'
    db.execute(sql, ( enabled, tpk ))
    product = {'tpk': tpk, 'enabled': enabled}
    return {'product': product}
