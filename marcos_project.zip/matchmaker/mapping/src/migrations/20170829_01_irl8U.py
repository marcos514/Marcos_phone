"""

"""

from yoyo import step

__depends__ = {'20170823_01_QCPrI'}

steps = [
    step("ALTER TABLE products DROP COLUMN name")
]
