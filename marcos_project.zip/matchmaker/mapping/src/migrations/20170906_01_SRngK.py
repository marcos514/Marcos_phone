"""

"""

from yoyo import step

__depends__ = {'20170829_01_irl8U'}

steps = [
    step("ALTER TABLE `mappings` ADD COLUMN `enabled` tinyint(3) unsigned NOT NULL DEFAULT '1' AFTER `tpk`")
]
