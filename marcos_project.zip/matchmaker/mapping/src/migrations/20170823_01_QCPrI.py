"""

"""

from yoyo import step

__depends__ = {}

steps = [
    step("""
-- ----------------------------
-- Table structure for mappings
-- ----------------------------

CREATE TABLE `mappings`  (
  `id` int(255) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tmk` char(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'thirstie merchant key',
  `mpk` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'the merchant sku for the product',
  `tpk` char(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'thirstie product key',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `unique_constraint`(`tmk`, `mpk`, `tpk`) USING BTREE COMMENT 'only one mapping per product per merchant'
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for merchants
-- ----------------------------

CREATE TABLE `merchants`  (
  `tmk` char(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'thirstie merchant key, needs to be 6 chars',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'the thirstie merchant name for convenience',
  `created_date` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'when this merchant was first uploaded',
  `updated_date` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `enabled` tinyint(255) NOT NULL DEFAULT 1,
  PRIMARY KEY (`tmk`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for products
-- ----------------------------

CREATE TABLE `products`  (
  `tpk` char(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(255) NOT NULL DEFAULT 1,
  PRIMARY KEY (`tpk`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;


""")
]
