"""

"""

from yoyo import step

__depends__ = {'20170906_01_SRngK'}

steps = [
    step("""
        ALTER TABLE mappings DROP INDEX unique_constraint;
        ALTER TABLE mappings ADD CONSTRAINT unique_constraint UNIQUE (tmk, mpk, tpk);
    """)
]
