import csv
from db import Database
from flask import Response, jsonify, abort, make_response
from io import StringIO
from typing import Callable, Iterable
from functools import wraps
from operator import add
import urllib.request
import json
import config

def loads(file: Iterable[dict]):
    '''
    Updloader decorates a function and passes it to transactional uploader
    :param file:
    :return:
    '''
    def decorator(f: Callable):
        @wraps(f)
        def wrapper():
            return transactional_uploader(file, f)
        return wrapper
    return decorator

def transactional_uploader(file: Iterable[dict], rowAction: Callable[[dict, object], int]):
    '''
    CSV uploader iterates over a csv and calls a callback for each row with a dictionary of that row and a mysql cursor
    :param file: csv.DictReader of csv
    :param rowAction: A callable function that takes a dictionary as the first object and an object as the second object
    :return: None
    '''
    with Database() as db:
        d = db.connection
        auto_commit_value = d.get_autocommit()
        d.autocommit(False)
        cursor = d.cursor()
        for row in file:
            rowAction(row, cursor)
        d.commit()
        d.autocommit(auto_commit_value)

def return_csv(data, fieldnames):
    def create_line(header_row, dict_of_row):
        result = []
        for i in header_row:
            # each object is a tuple with the fieldname and its type
            field, _type = i
            val = dict_of_row.get(field.lower(), '')
            # everything needs to be a str before being written to csv
            result.append(str(_type(val)))
        return result

    # return csv
    def generate_csv(header_row):
        line = StringIO()
        writer = csv.writer(line)
        # write header row
        if header_row:
            writer.writerow([i[0] for i in header_row])
            line.seek(0)
            yield line.read()
            line.truncate(0)
            line.seek(0)
        for row in data:
            writer.writerow(create_line(header_row, row))
            line.seek(0)
            yield line.read()
            line.truncate(0)
            line.seek(0)
    return Response(generate_csv(fieldnames), mimetype='text/csv')

def json_responder(f: Callable):
    '''
        A decorator that converts the output of a function to json and applies the access-control header

        example:
        @mappings.route('/merchant/<tmk>/mappings', methods=['GET'])
        @json_response
        def get_mappings(tmk):
            mappings = db.fetchall("SELECT * FROM mappings WHERE tmk = %s;", [tmk])
            return mappings

        The returned object 'mappings' will be converted to json
    '''
    @wraps(f)
    def wrapper(*args, **keywords):
        obj = f(*args, **keywords)
        # for Response flask objects, we just return those raw
        if type(obj) is Response:
            return obj
        response = jsonify(obj)
        response.headers['Access-Control-Allow-Origin'] = '*'
        return response
    return wrapper

def database(f: Callable):
    '''
        A decorator that injects the database into the function
    '''
    @wraps(f)
    def wrapper(**keywords):
        with Database() as db:
            response = f(db, **keywords)
        return response
    return wrapper

def load_csv_or_abort(csv_file, required_fields: set = None)-> csv.DictReader:
    '''
    Loads a csv by trying multiple encodings, raises HTTPException if it fails
    :return:
    '''
    # parse the file
    try:
        lines = str(csv_file.read(), 'utf-8').replace('\0', '').splitlines()
    except UnicodeDecodeError:
        try:
            lines = str(csv_file.read(), 'latin-1').splitlines()
        except:
            abort(make_response(jsonify(message="Invalid csv file, encoding not recognized. Please use utf 8."), 400))
    except:
        abort(make_response(jsonify(message="Invalid csv file, could not decode."), 400))

    if not lines:
        abort(make_response(jsonify(message="Empty file, no rows found"), 400))

    lines[0] = lines[0].replace('\ufeff', '')

    file = csv.DictReader(lines)

    if not required_fields:
        return file

    fields = set(list(map(lambda x: x.lower().strip(), file.fieldnames)))
    missing_fields = required_fields - (required_fields & fields)
    if missing_fields:
        abort(make_response(jsonify(message=f"CSV is missing the required fields: {str(missing_fields)}"), 400))

    return file

def get_merchants_inventory(tmks):
    inventory_response = urllib.request.urlopen(
        '{0}/merchants/{1}/inventory/'.format(config.INVENTORY_API, tmks)).read()

    merchants_inventory = json.loads(inventory_response)
    return merchants_inventory
