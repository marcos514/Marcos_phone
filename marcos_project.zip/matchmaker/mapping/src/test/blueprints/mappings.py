from app import app
import unittest
import config
from io import BytesIO
import json
from db import Database

class MappingsTestCase(unittest.TestCase):


    def setUp(self):
        if config.DB_NAME.find("_test") < 0:
            config.DB_NAME += "_test"
        self.db = Database().__enter__()
        database = self.db.fetchone("select database() as db")
        self.assertTrue("_test" in database['db'], 'Attempted to use application database in test!!!!!')
        app.testing = True
        self.client = app.test_client()
        self.db.execute("TRUNCATE TABLE mappings;")
        self.db.execute("TRUNCATE TABLE products;")
        self.db.execute('INSERT INTO products (tpk) VALUES ("ABCDEFGHI")')

    def test_uploading_mappings_csv(self):
        res = self.client.post('/merchant/ABCDEF/mappings', content_type='multipart/form-data',
                               data={'upload': (BytesIO(b'tmk,enabled,mpk,tpk\nABCDEF,True,1111,ABCDEFGHI'),
                                    'product_upload.csv')})
        mappings = self.db.fetchall("SELECT * FROM mappings;")
        self.assertEqual(len(mappings), 1)
        self.assertEqual(mappings[0], {'id': 1, 'tmk': 'ABCDEF', 'mpk': '1111', 'tpk': 'ABCDEFGHI', 'enabled': 1})
        self.assertEqual(res.status_code, 200)

    def test_uploading_mappings_csv_bad_merchant(self):
        res = self.client.post('/merchant/ABCDEF/mappings', content_type='multipart/form-data',
                               data={'upload': (BytesIO(b'tmk,enabled,mpk,tpk\nABCDE,True,1111,ABCDEFGHI'),
                                    'product_upload.csv')})
        self.assertEqual(res.status_code, 400, "A request with a bad merchant should have failed")

        res = self.client.post('/merchant/ABCDEFG/mappings', content_type='multipart/form-data',
                               data={'upload': (BytesIO(b'tmk,enabled,mpk,tpk\nABCDEFG,True,1111,ABCDEFGHI'),
                                                'product_upload.csv')})
        self.assertEqual(res.status_code, 400, "A request with a bad merchant should have failed")

    def test_get_mappings(self):
        self.db.execute("INSERT IGNORE INTO mappings (tmk, mpk, tpk) VALUES (%s, %s, %s);", ('ABCDEF', '1111', 'ABCDEFGHI'))
        res = self.client.get('/merchant/ABCDEF/mappings')
        data = json.loads(res.data.decode('utf-8'))
        self.assertEqual(res.status_code, 200)
        self.assertEqual(data,[{'enabled': True, 'id': 1, 'mpk': '1111', 'tmk': 'ABCDEF', 'tpk': 'ABCDEFGHI'}])




if __name__ == '__main__':
    unittest.main()
