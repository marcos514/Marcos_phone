import os
from app import app
import unittest
import config
from db import Database
from io import BytesIO
import json
import datetime

class MerchantsTestCase(unittest.TestCase):


    def setUp(self):
        if config.DB_NAME.find("_test") < 0:
            config.DB_NAME += "_test"
        self.db = Database().__enter__()
        database = self.db.fetchone("select database() as db")
        self.assertTrue("_test" in database['db'], 'Attempted to use application database in test!!!!!')
        app.testing = True
        self.client = app.test_client()

    def test_uploading_merchant_csv(self):
        self.db.execute("TRUNCATE TABLE merchants;")
        res = self.client.post('/merchants',content_type='multipart/form-data',
                               data={'upload': (BytesIO(b'tmk,name,enabled\nAAAAAA, A merchant, 1'),
                                    'merchant_upload.csv')})
        merchants = self.db.fetchall("SELECT * FROM merchants;")
        self.assertEqual(len(merchants), 1)
        self.assertEqual(merchants[0]['tmk'], 'AAAAAA')
        self.assertEqual(res.status_code, 200)


    def test_get_merchants(self):
        self.db.execute("TRUNCATE TABLE merchants;")
        self.db.execute("INSERT  INTO merchants (tmk, name, enabled) VALUES (%s, %s, %s);", ('AAAAAA', 'A merchant', 1))
        res = self.client.get('/merchants')
        data = json.loads(res.data.decode('utf-8'))
        self.assertEqual(res.status_code, 200)
        self.assertEqual(data[0]['tmk'], 'AAAAAA')
        self.db.execute("INSERT  INTO merchants (tmk, name, enabled) VALUES (%s, %s, %s);", ('AAAAAB', 'A merchant', 1))
        self.db.execute("INSERT  INTO merchants (tmk, name, enabled) VALUES (%s, %s, %s);", ('AAAAAC', 'A merchant', 1))
        res = self.client.get('/merchants?limit=2')
        data = json.loads(res.data.decode('utf-8'))
        self.assertEqual(len(data),2)


    def test_get_merchant(self):
        self.db.execute("TRUNCATE TABLE merchants;")
        self.db.execute("INSERT  INTO merchants (tmk, name, enabled) VALUES (%s, %s, %s);", ('AAAAAA', 'A merchant', 1))
        res = self.client.get('/merchant/AAAAAA')
        data = json.loads(res.data.decode('utf-8'))
        self.assertEqual(res.status_code, 200)
        self.assertEqual(data['tmk'], 'AAAAAA')



if __name__ == '__main__':
    unittest.main()
