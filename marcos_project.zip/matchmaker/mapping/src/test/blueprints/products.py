from app import app
import unittest
import config
from db import Database
from io import BytesIO
import json

class ProductsTestCase(unittest.TestCase):


    def setUp(self):
        if config.DB_NAME.find("_test") < 0:
            config.DB_NAME += "_test"

        self.db = Database().__enter__()
        database = self.db.fetchone("select database() as db")
        self.assertTrue("_test" in database['db'], 'Attempted to use application database in test!!!!!')
        app.testing = True
        self.client = app.test_client()

    def test_uploading_products_csv(self):
        self.db.execute("TRUNCATE TABLE products;")
        res = self.client.post('/products', content_type='multipart/form-data',
                               data={'upload': (BytesIO(b'tpk,enabled\nABCDEFGHI, 1'),
                                    'product_upload.csv')})
        products = self.db.fetchall("SELECT * FROM products;")
        self.assertEqual(len(products), 1)
        self.assertEqual(products[0]['tpk'], 'ABCDEFGHI')
        self.assertEqual(res.status_code, 200)

    def seedProduct(self):
        self.db.execute("TRUNCATE TABLE products;")
        self.db.execute("INSERT INTO products (tpk, enabled) VALUES (%s, %s) ON DUPLICATE KEY UPDATE enabled=VALUES(enabled);",
            ('ABCDEFGHI', 1))

    def test_get_products(self):
        self.seedProduct()
        res = self.client.get('/products')
        data = json.loads(res.data.decode('utf-8'))
        self.assertEqual(res.status_code, 200)
        self.assertEqual(data[0]['tpk'], 'ABCDEFGHI')


if __name__ == '__main__':
    unittest.main()
