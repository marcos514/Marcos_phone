#!/usr/bin/env bash

DB_USER=root
DB_PASSWORD=root
DB_HOST=mapping_db
DB_NAME=mapping_db
MIGRATIONS_DIRECTORY=/src/migrations



cd /
./wait-for-it.sh $DB_HOST:3306 -t 0
cd "$MIGRATIONS_DIRECTORY"
yoyo apply --database mysql+mysqldb://$DB_USER:$DB_PASSWORD@$DB_HOST/$DB_NAME
yoyo apply --database mysql+mysqldb://$DB_USER:$DB_PASSWORD@$DB_HOST/"$DB_NAME"_test
cd /src
python app.py
