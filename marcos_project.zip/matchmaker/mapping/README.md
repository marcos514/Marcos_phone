# Mapping Service

The Mapping service provides an api for loading master product data and matching it to merchant inventory.

## Integration

The service provides the following http routes:

| Route | Method | Parameters  |Description |
--------|--------|---------------|---|
|/products|GET   |{limit(optional): int, offset(optional):int}| Get the master product list|
|/products|POST  |{'upload':csv_file}| Post a csv of the master product list.|
|/merchants|GET | {limit(optional): int, offset(optional):int}| Get a list of the merchants|
|/merchants|POST |{'upload':csv_file} | Post a csv of the merchants|
|/merchant/{tmk}/mappings|GET | {limit(optional): int, offset(optional):int}| Get a list of the mappings for the given merchant|
|/merchant/{tmk}/mappings|POST |{'upload':csv_file} | Post a complete list of merchant mappings|
|/ingestions/{tmks} | GET |{tmks} a comma seperated list of tmks| Gets metadata about the last ingestion for the list of given merchants]|


## Development

A Makefile is provided for documentation and for easily running useful tasks. Please see the Makefile for information about the underlying process.

| Commands | Description|
--------------------|-------------
|`make new_migration (-name="my migration")`|Creates a new migration, optionally supply a short name for the migration|
|`make apply_migrations`| Applies the migrations to the standard and testing database. The docker database must have been brought up at least once for the databases to exist. Note: the python docker-conatainer will apply migrations on startup|
|`make` test| Runs the tests for this service inside the container|



