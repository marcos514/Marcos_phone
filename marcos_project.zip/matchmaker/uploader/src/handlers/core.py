import json
import re
import functools
import decimal
from tornado.web import RequestHandler


def cross_origin(wrapped):
    @functools.wraps(wrapped)
    def wrapper(self, *args, **kwargs):
        origin = self.request.headers.get('Origin', None)

        if not origin:
            return wrapped(self, *args, **kwargs)

        pattern = getattr(self, '_origin_pattern', None)

        if not pattern:
            pattern = re.compile(r'https?://([^/]+)/?')
            self._origin_pattern = pattern

        match = pattern.match(origin)

        if match:
            host_origin = match.groups()[0]
            allowed_origin = False

            for rexp in self.ALLOWED_ORIGINS:
                # TODO: Cache the compiled exprs
                r = re.compile(rexp)
                if r.match(host_origin):
                    allowed_origin = True
                    break

            if not allowed_origin:
                self.set_status(405)
                return

            method_list = self.get_implemented_methods()

            self.set_header('Access-Control-Allow-Origin', origin)
            self.set_header('Access-Control-Allow-Credentials', 'true')
            self.set_header('Access-Control-Allow-Methods', ', '.join(method_list))
            self.set_header('Access-Control-Allow-Headers', (
                'Origin, Content-Type, Accept, Accept-Encoding, Authorization' +
                'If-Modified-Since, Cookie, X-Xsrftoken, Etag'))
            self.set_header('Access-Control-Expose-Headers', (
                'Content-Disposition, Location'))

        return wrapped(self, *args, **kwargs)
    return wrapper


class CoreRequestHandler(RequestHandler):
    """Handles CORS requests. Can also write JSON responses"""

    ALLOWED_ORIGINS = [r'.*']

    def __init__(self, *args, **kwargs):
        super(CoreRequestHandler, self).__init__(*args, **kwargs)

    def prepare(self):
        "Prepare the request"
        content_type = self.request.headers.get('Content-Type')

        allowed_types = [
            'application/json; charset=utf-8',
            'application/json;charset=utf-8',
            'application/json'
        ]
        if str(content_type).lower() in allowed_types and self.request.body:
            self.json_body = json.loads(self.request.body.decode('utf-8'),
                parse_float=decimal.Decimal)

    def get_implemented_methods(self):
        method_list = ['OPTIONS']

        # We look up each supported HTTP method in both the base class
        # and the subclass, and compare their function objects. If they
        # don't match, the subclass must have defined an overriding
        # method, so we add the method to the allowed methods header.

        for method in self.SUPPORTED_METHODS:
            # N.B. We're relying on the SUPPORTED_METHODS property
            # defined in the tornado.web.RequestHandler class.
            override = getattr(self, method.lower())
            base_impl = getattr(BaseRequestHandler, method.lower())

            if override.__code__ is not base_impl.__code__:
                method_list.append('{0}'.format(method))

        return method_list

    def write_json(self, obj):
        self.set_header('Content-Type', 'application/json; charset=UTF-8')
        self.write(json.dumps(obj, sort_keys=True))

    @cross_origin
    def options(self, *args, **kwargs):
        self.set_header('Allow', ','.join(self.get_implemented_methods()))
