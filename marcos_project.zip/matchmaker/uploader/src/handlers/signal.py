# This receives a trigger from the inventory/mapping services
import json
from tornado import gen
from tornado.httpclient import HTTPError
from handlers.core import CoreRequestHandler, cross_origin
from handlers.urls import THIRSTIE_API_URL
from services import get_merchant, generate_offerings, post_offerings, post_evergreen_offerings, log_event


class SignalHandler(CoreRequestHandler):
    """
        This will get triggered whenever the mappings change
        for a particular merchant or an inventory is uploaded.
    """
    @cross_origin
    @gen.coroutine
    def get(self, tmk):
        # get query args
        preview = self.get_query_argument('preview', 'false').lower() == 'true'
        preview_evergreen = self.get_query_argument('preview_evergreen', 'false').lower() == 'true'

        # check if merchant is enabled and exists
        try:
            response = yield get_merchant(tmk)
            merchant = json.loads(response.body)
            if not merchant['enabled']:
                log_event(merchant, f'TMK <{tmk}> disabled', 'warning')
                self.set_status(400)
                self.write_json({'error': f'TMK <{tmk}> disabled'})
                return

            # generate offerings to be created from merchant's inventory and mappings
            generated_result = yield generate_offerings(tmk)
        except HTTPError as e:
            self.set_status(e.code)
            self.write(e.response.body)
            return

        # make sure there are offerings to be created
        stock_behaviors, offerings, bad_mpks = generated_result
        if not offerings and not preview:
            msg = f'The mappings for {tmk} do not match the inventory MPKs (broh) :rick:'
            dis_msg = f'Check Master Product List and mappings for {tmk} for disabled mappings'
            if bad_mpks:
                final_msg = msg + '\n' + dis_msg
            else:
                final_msg = dis_msg
            log_event(merchant, final_msg, 'error')
            self.set_status(400)
            self.write_json({'message': final_msg})
            return

        # if preview, return generated offerings else create remote offerings
        if preview or not THIRSTIE_API_URL:
            self.write_json(offerings)
        elif preview_evergreen:
            self.write_json(stock_behaviors)
        else:
            try:
                if stock_behaviors:
                    _response = yield post_evergreen_offerings(tmk, stock_behaviors)
                    _result = json.loads(_response.body)
                    log_event(merchant, f'Stock behaviors update response: {_result}')
                response = yield post_offerings(tmk, offerings)
                results = json.loads(response.body)
                log_event(merchant, fields=results)
                if bad_mpks:
                    log_event(merchant, f'The following MPKs DNE in the inventory of {tmk}: [{", ".join(bad_mpks)}]', 'warning')
                self.write_json(results)
            except HTTPError as e:
                log_event(merchant, f'Offering Uploader failed for merchant {tmk}', 'error')
                self.set_status(e.code)
                self.write(e.response.body)
