'''
Provides the urls for the network calls depending upon the environment
'''
import os

ENVIRONMENT = os.environ.get('TORNADO_ENVIRONMENT', 'development')
MAPPING_API = os.environ.get('MAPPING_API', 'http://localhost:8885/m')
INVENTORY_API = os.environ.get('INVENTORY_API', 'http://localhost:8885/i')

PROXY_AUTH_TOKEN = os.environ.get('PROXY_AUTH_TOKEN', 'b3BzOmkgYW0gdmVyeSB0aGlyc3RpZQ==')
CATALOG_CREDS = {
    'email': os.environ.get('CATALOG_CREDS_EMAIL', None),
    'password': os.environ.get('CATALOG_CREDS_PASSWORD', None)
}
ADMIN_BASIC_AUTH = os.environ.get('ADMIN_BASIC_AUTH', None)

SLACK_URL = os.environ.get('SLACK_URL', None)
THIRSTIE_API_URL = os.environ.get('THIRSTIE_API_URL')
