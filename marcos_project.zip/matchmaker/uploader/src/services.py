'''
Helper functions to perform various network requests
'''
import json, time
from datetime import datetime
from tornado import gen
from tornado.httpclient import AsyncHTTPClient
from handlers.urls import (
    MAPPING_API, INVENTORY_API, THIRSTIE_API_URL,
    SLACK_URL, ENVIRONMENT, CATALOG_CREDS,
    ADMIN_BASIC_AUTH
)


# create async client
client = AsyncHTTPClient()

# logging methods
@gen.coroutine
def log_event(merchant, message='', message_type='success', fields={}):
    # log an event to Slack
    color_map = {'success': '#26c13b', 'error': '#ba1414', 'warning': '#f7dc11'}
    request_config = {
        'method': 'POST',
        'headers': { 'Content-Type': 'application/json' },
        'body': json.dumps({'attachments': [{
            'color': color_map.get(message_type, '#91918e'),
            'pretext': f'{ENVIRONMENT.title()}: Upload summary for _{merchant["name"]}_ (*{merchant["tmk"]}*)',
            'title': message_type.title(),
            'text': message,
            'fields': [{'title': k.title(), 'value': fields[k], 'short': True} for k in fields],
            'mrkdwn_in': ['pretext'],
            'ts': int(time.mktime(datetime.now().timetuple())),
            'fallback': f'{ENVIRONMENT.title()}: Upload summary for {merchant["name"]} {merchant["tmk"]}'
        }]})
    }
    yield client.fetch(SLACK_URL, **request_config)

# uploader methods
@gen.coroutine
def get_merchant(tmk):
    # get the merchant
    url = '{0}/merchant/{1}'.format(MAPPING_API, tmk)
    response = yield client.fetch(url, raise_error=True)
    return response

@gen.coroutine
def get_products():
    # get the master product list
    url = '{}/products'.format(MAPPING_API)
    response = yield client.fetch(url, raise_error=False)
    return response

@gen.coroutine
def get_mappings(tmk):
    # get the latest mappings for a merchant
    url = '{0}/merchant/{1}/mappings'.format(MAPPING_API, tmk)
    response = yield client.fetch(url, raise_error=False)
    return response

@gen.coroutine
def get_inventory(tmk):
    # get the latest inventory for a merchant
    url = '{0}/merchant/{1}/inventory'.format(INVENTORY_API, tmk)
    response = yield client.fetch(url,  raise_error=False)
    return response

@gen.coroutine
def generate_offerings(tmk):
    # get the MPL, latest merchant mappings, and latest merchant inventory
    products, mappings, inventory = yield [get_products(), get_mappings(tmk), get_inventory(tmk)]

    #if any of these raised an exception, raise one
    for response in [products, mappings, inventory]:
        response.rethrow()

    '''
    This is a filter. We get the active products from the MPL,
    then filter the merchant mappings for the merchant by a) its existence in the MPL
    and b) if it's active. Then, we filter the merchant inventory by checking if its
    MPK is in the filtered mappings
    '''
    mpl = {i['tpk']: i for i in json.loads(products.body) if i['enabled']}
    mappings = {i['mpk']: i for i in json.loads(mappings.body) if i['enabled'] and i['tpk'] in mpl}
    inventory = {i['mpk']: i for i in json.loads(inventory.body) if i['mpk'] in mappings}

    # create offerings dictionary
    offerings = []
    stock_behaviors = []
    bad_mpks = set()
    for mpk in mappings:
        inv = inventory.get(mpk, None)
        if not inv:
            bad_mpks.add(mpk)
        else:
            if inv['evergreen'] != None:
                stock_behaviors.append({
                    'product_key': mappings[mpk]['tpk'],
                    'price': inv['price'],
                    'merchant_sku': inv['msku'],
                    'stock_behavior': 'NextDay' if inv['active'] and inv['evergreen'] else 'Fluctuates'
                })
                if not inv['evergreen']:
                    offerings.append({
                        'tpk': mappings[mpk]['tpk'],
                        'price': inv['price'],
                        'quantity': inv['quantity'],
                        'merchant_sku': inv['msku'],
                        'exists': inv['active']
                    })
            else:
                offerings.append({
                    'tpk': mappings[mpk]['tpk'],
                    'price': inv['price'],
                    'quantity': inv['quantity'],
                    'merchant_sku': inv['msku'],
                    'exists': inv['active']
                })

    return stock_behaviors, offerings, bad_mpks

@gen.coroutine
def post_offerings(tmk, offerings: dict):
    # post the offerings to the catalog service
    token = yield get_catalog_token()
    request_config = {
        'method': 'POST',
        'headers': {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json; charset=UTF-8'
        },
        'body': json.dumps(offerings)
    }
    url = f'{THIRSTIE_API_URL}/c/v2/merchants/{tmk}/offerings'
    response = yield client.fetch(url, **request_config)
    return response

@gen.coroutine
def post_evergreen_offerings(tmk, stock_behaviors: dict):
    # post stock behvaiors to the catalog service
    token = yield get_catalog_token()
    payload = { 'items': stock_behaviors }
    request_config = {
        'method': 'POST',
        'headers': {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json; charset=UTF-8'
        },
        'body': json.dumps(payload)
    }
    url = f'{THIRSTIE_API_URL}/c/v2/merchants/{tmk}/product_stock_behaviors'
    response = yield client.fetch(url, **request_config)
    return response

@gen.coroutine
def get_catalog_token():
    # login with catalog service and returns a session token
    request_config = {
        'method': 'POST',
        'headers': {
            'Content-Type': 'application/json; charset=UTF-8',
            'Authorization': f'Basic {ADMIN_BASIC_AUTH}'
        },
        'body': json.dumps(CATALOG_CREDS)
    }
    url = f'{THIRSTIE_API_URL}/a/v2/sessions'
    response = yield client.fetch(url, **request_config)
    credentials = json.loads(response.body)
    return credentials['token']

