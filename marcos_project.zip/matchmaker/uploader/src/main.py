import os, sys
import signal
import tornado.options as options
from tornado.web import Application
from tornado.httpserver import HTTPServer
from tornado.ioloop import IOLoop
from handlers.signal import SignalHandler
from datetime import datetime
from distutils.util import strtobool

# get port and debug status from os environment
TORNADO_LISTEN_PORT = os.environ.get('TORNADO_LISTEN_PORT', 9000)
TORNADO_DEBUG       = bool(strtobool(os.environ.get('TORNADO_DEBUG', 'False')))

# shutdown cleanly
def shutdown():
    print('\n> Caught CTRL-C. Shutting down...')
    IOLoop.instance().stop()

def create_application(debug=False):
    # creates the tornado Application
    handlers = [(r"/v2/trigger/(?P<tmk>[\w]+)/?", SignalHandler)]
    return Application(handlers, debug=debug)

if __name__ == '__main__':
    # enable pretty logging
    options.parse_command_line()

    # start application
    app = create_application(TORNADO_DEBUG)
    server = HTTPServer(app)
    server.listen(TORNADO_LISTEN_PORT)
    ioloop = IOLoop.instance()

    time = datetime.now()
    print('''
 /$$   /$$           /$$                           /$$
| $$  | $$          | $$                          | $$
| $$  | $$  /$$$$$$ | $$  /$$$$$$   /$$$$$$   /$$$$$$$  /$$$$$$   /$$$$$$
| $$  | $$ /$$__  $$| $$ /$$__  $$ |____  $$ /$$__  $$ /$$__  $$ /$$__  $$
| $$  | $$| $$  \ $$| $$| $$  \ $$  /$$$$$$$| $$  | $$| $$$$$$$$| $$  \__/
| $$  | $$| $$  | $$| $$| $$  | $$ /$$__  $$| $$  | $$| $$_____/| $$
|  $$$$$$/| $$$$$$$/| $$|  $$$$$$/|  $$$$$$$|  $$$$$$$|  $$$$$$$| $$
 \______/ | $$____/ |__/ \______/  \_______/ \_______/ \_______/|__/
          | $$
          | $$
          |__/
    ''', file=sys.stderr)
    print('> Python {}'.format(sys.version.replace('\n', '')), file=sys.stderr)
    print('> [{0}/{1}/{2} {3}:{4}:{5}]'.format(
        time.month, time.day, time.year, time.hour,
        '{:02d}'.format(time.minute), '{:02d}'.format(time.second)
    ), file=sys.stderr)
    print(f'> Listening on port {TORNADO_LISTEN_PORT}', file=sys.stderr)

    if TORNADO_DEBUG:
        print('> Starting in debug mode', file=sys.stderr)

    print('> Use CTRL-C to exit\n', file=sys.stderr)
    sys.stderr.flush()

    signal.signal(signal.SIGINT, lambda sig, frame: ioloop.add_callback_from_signal(shutdown))
    ioloop.start()
