'''
Test for the offering uploader. These can be run inside the docker container
by:
    1) docker exec -it <imageID> bash
    2) navigate to tests folder and run
        python -m tornado.testing <Tests>
'''


from io import StringIO

import unittest.mock
from unittest.mock import patch

import tornado.testing
from tornado.concurrent import Future
from tornado.httpclient import HTTPResponse, HTTPRequest
from tornado.testing import AsyncHTTPTestCase

from main import create_application

def set_future_value(mock: unittest.mock.Mock, value):
    immediate = Future()
    immediate.set_result(value)
    mock.return_value = immediate

class TestUploader(AsyncHTTPTestCase):
    # REQUIRED: this override creates the test cases
    def get_app(self):
        return create_application()

    def test_no_merchant(self):
        #should return a 404
        response = self.fetch('/v2/trigger')
        self.assertEqual(response.code, 404)

    @patch('handlers.signal.get_merchant')
    def test_disabled_merchant(self, mock):
        merchant_response = HTTPResponse(HTTPRequest(''), 200, buffer=StringIO('{"enabled": false,"name": "A test merchant","tmk": "AMERCH"}'))
        immediate = Future()
        immediate.set_result(merchant_response)
        mock.return_value = immediate
        response = self.fetch('/v2/trigger/NOMERCH')
        self.assertEqual(response.code, 400)

    # @patch('services.get_merchant')
    # @patch('services.generate_offerings')
    # @patch('services.post_offerings')
    # def test_generate_offerings(self, *args):
    #
    #
    #   TODO finish this
    #     mock_responses = [
    #         HTTPResponse(HTTPRequest(''), 200, buffer=StringIO('{"enabled": false,"name": "A test merchant","tmk": "AMERCH"}')),
    #         HTTPResponse(HTTPRequest(''), 200, buffer=StringIO('{"enabled": false,"name": "A test merchant","tmk": "AMERCH"}')),
    #         HTTPResponse(HTTPRequest(''), 200, buffer=StringIO('"created": "<x> offering(s)","skipped": "<y> offering(s)"'))
    #     ]
    #
    #     list(map(set_future_value, args, reversed(mock_responses)))



if __name__ == '__main__':
    tornado.testing.main()
