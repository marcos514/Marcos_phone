import unittest
import services
import tornado
from unittest import TestCase
from unittest.mock import patch, Mock
from tornado.ioloop import IOLoop
from tornado.concurrent import Future
from tornado.httpclient import HTTPRequest, HTTPResponse, HTTPError
from io import StringIO


def set_future_value(mock: Mock, value):
    immediate = Future()
    immediate.set_result(value)
    mock.return_value = immediate

def run_sync(f):
    return IOLoop.current().run_sync(f)


merchant = StringIO("""
            {
              "enabled": true,
              "name": "A test merchant",
              "tmk": "AMERCH"
            }
""")
products = StringIO("""
[
      {
        "enabled": 1,
        "tpk": "ENABLED11"
      },
      {
        "enabled": 2,
        "tpk": "ENABLED22"
      },
      {
        "enabled": 0,
        "tpk": "DISABLED1"
      }
]
""")
mappings = StringIO("""
[
  {
    "enabled": true,
    "id": 97,
    "mpk": "1",
    "tmk": "AMERCH",
    "tpk": "ENABLED11"
  },
  {
    "enabled": true,
    "id": 51,
    "mpk": "2",
    "tmk": "AMERCH",
    "tpk": "ENABLED22"
  }
]
""")
inventory = StringIO("""
[
    {
        "active": true, "date_added": "2017-09-01 21:39:15",
        "date_updated": "2017-09-01 22:30:49", "id": "6524",
        "last_ingestion_id": "22", "mpk": "1", "price": "1.99",
        "quantity": "1", "tmk": "AMERCH", "msku": "ABCITSEASYAS123",
        "evergreen": false
    },
    {
        "active": true, "date_added": "2017-09-01 21:39:15",
        "date_updated": "2017-09-01 22:30:49", "id": "6524",
        "last_ingestion_id": "22", "mpk": "2", "price": "1.99",
        "quantity": "2", "tmk": "AMERCH", "msku": null,
        "evergreen": false
    },
    {
        "active": true, "date_added": "2017-09-01 21:39:15",
        "date_updated": "2017-09-01 22:30:49", "id": "6524",
        "last_ingestion_id": "22", "mpk": "3", "price": "1.99",
        "quantity": "3", "tmk": "AMERCH", "msku": null,
        "evergreen": false
    }
]
""")

class TestServices(TestCase):

    @patch('services.get_merchant')
    @patch('services.get_products')
    @patch('services.get_mappings')
    @patch('services.get_inventory')
    def test_generate_offerings(self, *args):
        mock_responses = [
            HTTPResponse(HTTPRequest(''), 200, buffer=merchant),
            HTTPResponse(HTTPRequest(''), 200, buffer=products),
            HTTPResponse(HTTPRequest(''), 200, buffer=mappings),
            HTTPResponse(HTTPRequest(''), 200, buffer=inventory)
        ]

        list(map(set_future_value, args, reversed(mock_responses)))
        stock_behaviors, offerings, bad_mpks = run_sync(lambda : services.generate_offerings('AAAA'))
        result = [
            {'tpk': 'ENABLED11', 'exists': True, 'price': '1.99', 'quantity': '1', 'merchant_sku': 'ABCITSEASYAS123'},
            {'tpk': 'ENABLED22', 'exists': True, 'price': '1.99', 'quantity': '2', 'merchant_sku': None}
        ]
        self.assertEqual(offerings, result)

    @patch('services.get_products')
    @patch('services.get_mappings')
    @patch('services.get_inventory')
    def test_fetch_exception_is_thrown(self, *args):
        mock_responses = [
            HTTPResponse(HTTPRequest(''), 404, buffer=products),
            HTTPResponse(HTTPRequest(''), 200, buffer=mappings),
            HTTPResponse(HTTPRequest(''), 200, buffer=inventory)
        ]

        list(map(set_future_value, args, reversed(mock_responses)))

        try:
            data = run_sync(lambda: services.generate_offerings('AAAA'))
            self.assertTrue(False)
        except HTTPError:
            self.assertTrue(True)


if __name__ == '__main__':
    unittest.main()
