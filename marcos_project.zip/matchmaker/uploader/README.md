# Uploader Service

The uploader service aggregates data from the mapping and inventory services and uploads them to the catalog service.

## Integration

The service provides the following http routes:

| Route | Method | Parameters  |Description |
--------|--------|---------------|---|
|/v2/trigger/{tmk}|GET|preview=true(optional)|Triggers the upload process for the given merchant. An optional 'preview' parameter can be added to see what output will be sent to the catalog.|


## Development

A Makefile is provided for documentation and for easily running useful tasks. Please see the Makefile for information about the underlying process.

| Commands | Description|
--------------------|-------------
|`make test`| Runs all the tests|


##Testing 

Run `make test` or bash into the Docker container and run:

`python -m tornado.test.runtests test_trigger.py`

To do an individual test, run:

`python -m tornado.testing test_trigger.TestUploader.<name_of_test>`
